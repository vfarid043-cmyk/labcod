import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 })
    }

    const { pageHtml, formHtml } = await request.json()

    if (!pageHtml || !formHtml) {
      return NextResponse.json({ error: "HTML da página e formulário são obrigatórios" }, { status: 400 })
    }

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "API Key da OpenAI não configurada" }, { status: 500 })
    }

    console.log("[v0] Iniciando inserção inteligente com IA...")

    const compressHtml = (html: string) => {
      return html
        .replace(/<!--[\s\S]*?-->/g, "") // Remove comentários HTML
        .replace(/\s+/g, " ") // Substitui múltiplos espaços por um único
        .replace(/>\s+</g, "><") // Remove espaços entre tags
        .trim()
    }

    const compressedPageHtml = compressHtml(pageHtml)
    const compressedFormHtml = compressHtml(formHtml)

    console.log("[v0] HTML original:", pageHtml.length, "chars")
    console.log("[v0] HTML comprimido:", compressedPageHtml.length, "chars")

    const systemPrompt = `Você é especialista em HTML. TAREFA: Inserir formulário em página HTML.

REGRAS:
1. Retorne a página HTML COMPLETA (<!DOCTYPE html> até </html>)
2. Insira o formulário onde havia o antigo (procure divs vazias, main, section)
3. Se não achar local, insira em <main>, <section> ou <body>
4. NÃO modifique o resto da página
5. Retorne APENAS o HTML, sem markdown ou explicações`

    const userPrompt = `Página HTML limpa:
${compressedPageHtml}

Formulário para inserir:
${compressedFormHtml}

Retorne a página HTML COMPLETA com formulário inserido.`

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini", // Mudado para gpt-4o-mini (mais eficiente)
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.1,
        max_tokens: 16000,
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("[v0] Erro da OpenAI:", errorData)
      throw new Error(errorData.error?.message || "Erro ao processar com IA")
    }

    const data = await response.json()
    let finalHtml = data.choices[0]?.message?.content || ""

    // Remove markdown code blocks se existirem
    if (finalHtml.includes("```")) {
      finalHtml = finalHtml.replace(/```html\n?/g, "").replace(/```\n?/g, "")
    }

    finalHtml = finalHtml.trim()

    console.log("[v0] Formulário inserido com IA com sucesso!")
    console.log("[v0] Tamanho final:", finalHtml.length, "caracteres")

    return NextResponse.json({
      finalHtml,
      success: true,
    })
  } catch (error) {
    console.error("[v0] Erro ao inserir formulário:", error)
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "Erro ao processar com IA",
      },
      { status: 500 },
    )
  }
}
