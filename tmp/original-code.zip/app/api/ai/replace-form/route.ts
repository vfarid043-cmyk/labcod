import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

function removeFormsWithRegex(html: string): string {
  let cleaned = html

  // Remove modals e popups (estruturas comuns)
  cleaned = cleaned.replace(
    /<div[^>]*class=["'][^"']*(modal|popup|overlay|lightbox)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    "",
  )

  // Remove formulários e todo seu conteúdo
  cleaned = cleaned.replace(/<form[\s\S]*?<\/form>/gi, "")

  // Remove scripts relacionados a formulários e modals
  cleaned = cleaned.replace(/<script[^>]*>[\s\S]*?(modal|popup|form|submit)[\s\S]*?<\/script>/gi, "")

  // Remove overlays fixos
  cleaned = cleaned.replace(
    /<div[^>]*style=["'][^"']*position:\s*fixed[^"']*z-index[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    "",
  )

  // Remove estilos inline de z-index alto (geralmente overlays)
  cleaned = cleaned.replace(/style=["'][^"']*z-index:\s*\d{3,}[^"']*["']/gi, "")

  return cleaned
}

function findBestFormLocation(html: string): { before: string; after: string } {
  const patterns = [
    /<main[^>]*>/i,
    /<div[^>]*class=["'][^"']*container[^"']*["'][^>]*>/i,
    /<section[^>]*>/i,
    /<article[^>]*>/i,
    /<div[^>]*class=["'][^"']*content[^"']*["'][^>]*>/i,
    /<body[^>]*>/i,
  ]

  for (const pattern of patterns) {
    const match = html.match(pattern)
    if (match && match.index !== undefined) {
      const insertPosition = match.index + match[0].length
      return {
        before: html.substring(0, insertPosition),
        after: html.substring(insertPosition),
      }
    }
  }

  const bodyMatch = html.match(/<body[^>]*>/i)
  if (bodyMatch && bodyMatch.index !== undefined) {
    const insertPosition = bodyMatch.index + bodyMatch[0].length
    return {
      before: html.substring(0, insertPosition),
      after: html.substring(insertPosition),
    }
  }

  const middle = Math.floor(html.length / 2)
  return {
    before: html.substring(0, middle),
    after: html.substring(middle),
  }
}

async function validateWithAI(html: string, openaiApiKey: string): Promise<string> {
  try {
    const systemPrompt = `Você é um especialista em HTML. Revise rapidamente este HTML e:
1. Confirme que todos os formulários foram removidos
2. Se encontrar algum formulário restante, remova-o
3. Retorne o HTML limpo

Seja RÁPIDO. Retorne apenas o HTML, sem explicações.`

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${openaiApiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Revise este HTML:\n\n${html.substring(0, 50000)}` },
        ],
        temperature: 0.1,
        max_tokens: 8000,
      }),
    })

    if (!response.ok) {
      console.log("[v0] IA validation falhou, usando regex apenas")
      return html
    }

    const data = await response.json()
    let validated = data.choices[0]?.message?.content || html

    if (validated.includes("```")) {
      validated = validated.replace(/```html\n?/g, "").replace(/```\n?/g, "")
    }

    return validated.trim()
  } catch (error) {
    console.error("[v0] Erro na validação com IA:", error)
    return html
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 })
    }

    const { originalHtml, replacementForm, useAI = false } = await request.json()

    if (!originalHtml || !replacementForm) {
      return NextResponse.json(
        { error: "HTML original e formulário de substituição são obrigatórios" },
        { status: 400 },
      )
    }

    console.log("[v0] Iniciando processamento rápido com regex...")
    console.log("[v0] Tamanho do HTML original:", originalHtml.length, "caracteres")

    let cleanedHtml = removeFormsWithRegex(originalHtml)
    console.log("[v0] Formulários removidos com regex")
    console.log("[v0] Tamanho após limpeza:", cleanedHtml.length, "caracteres")

    if (useAI && process.env.OPENAI_API_KEY) {
      console.log("[v0] Validando com IA...")
      cleanedHtml = await validateWithAI(cleanedHtml, process.env.OPENAI_API_KEY)
      console.log("[v0] Validação com IA concluída")
    }

    const { before, after } = findBestFormLocation(cleanedHtml)
    const finalHtml = before + "\n\n" + replacementForm + "\n\n" + after

    console.log("[v0] Formulário injetado com sucesso!")
    console.log("[v0] Tamanho final:", finalHtml.length, "caracteres")

    return NextResponse.json({
      processedHtml: finalHtml,
      formsFound: "Formulários removidos e substituído com sucesso",
      success: true,
      method: useAI ? "regex + IA" : "regex",
    })
  } catch (error) {
    console.error("[v0] Error in form replacement:", error)
    return NextResponse.json({ error: "Erro ao processar formulário" }, { status: 500 })
  }
}
