import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function DELETE(request: Request) {
  try {
    const supabase = await createClient()

    // Get the current user
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const formId = searchParams.get("id")

    if (!formId) {
      return NextResponse.json({ error: "ID do formulário é obrigatório" }, { status: 400 })
    }

    // Delete the saved form
    const { error } = await supabase.from("saved_forms").delete().eq("id", formId).eq("user_id", user.id)

    if (error) {
      console.error("Erro ao deletar formulário:", error)
      return NextResponse.json({ error: "Erro ao deletar formulário" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Projeto deletado com sucesso!",
    })
  } catch (error) {
    console.error("Erro ao processar requisição:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
