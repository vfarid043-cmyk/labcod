import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { projectName, formConfig } = body

    if (!projectName || !formConfig) {
      return NextResponse.json({ error: "Nome do projeto e configuração são obrigatórios" }, { status: 400 })
    }

    const supabase = await createClient()

    // Get the current user
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 })
    }

    // Save the form to the database
    const { data, error } = await supabase
      .from("saved_forms")
      .insert({
        user_id: user.id,
        project_name: projectName,
        form_config: formConfig,
      })
      .select()
      .single()

    if (error) {
      console.error("Erro ao salvar formulário:", error)
      return NextResponse.json({ error: "Erro ao salvar formulário" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      data,
      message: "Projeto salvo com sucesso!",
    })
  } catch (error) {
    console.error("Erro ao processar requisição:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
