import type React from "react"
import type { Metadata } from "next"
import { Space_Grotesk, DM_Sans } from "next/font/google"
import "./globals.css"

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-space-grotesk",
})

const dmSans = DM_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-dm-sans",
})

export const metadata: Metadata = {
  title: "FormBuilder Pro - Gerador Profissional de Formulários",
  description: "Gerador profissional de formulários de alta conversão com personalização avançada",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className={`dark ${spaceGrotesk.variable} ${dmSans.variable} antialiased`}>
      <head>
        <style>{`
html {
  font-family: ${dmSans.style.fontFamily};
  --font-sans: var(--font-dm-sans);
  --font-serif: var(--font-space-grotesk);
}
        `}</style>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                const originalError = console.error;
                const originalWarn = console.warn;
                
                console.error = function(...args) {
                  const message = args[0]?.toString() || '';
                  if (message.includes('ResizeObserver loop completed with undelivered notifications') ||
                      message.includes('ResizeObserver loop limit exceeded')) {
                    return;
                  }
                  originalError.apply(console, args);
                };
                
                console.warn = function(...args) {
                  const message = args[0]?.toString() || '';
                  if (message.includes('ResizeObserver loop completed with undelivered notifications') ||
                      message.includes('ResizeObserver loop limit exceeded')) {
                    return;
                  }
                  originalWarn.apply(console, args);
                };

                // Captura global de erros
                window.addEventListener('error', function(e) {
                  if (e.message && (e.message.includes('ResizeObserver loop completed with undelivered notifications') ||
                      e.message.includes('ResizeObserver loop limit exceeded'))) {
                    e.stopImmediatePropagation();
                    e.preventDefault();
                    return false;
                  }
                }, true);
                
                window.addEventListener('unhandledrejection', function(e) {
                  if (e.reason && e.reason.message && 
                      (e.reason.message.includes('ResizeObserver loop completed with undelivered notifications') ||
                       e.reason.message.includes('ResizeObserver loop limit exceeded'))) {
                    e.preventDefault();
                    return false;
                  }
                });

                // Substituição completa do ResizeObserver
                const originalResizeObserver = window.ResizeObserver;
                window.ResizeObserver = class extends originalResizeObserver {
                  constructor(callback) {
                    const wrappedCallback = (entries, observer) => {
                      window.requestAnimationFrame(() => {
                        try {
                          callback(entries, observer);
                        } catch (error) {
                          // Suprimir completamente erros de ResizeObserver
                          if (error.message && (error.message.includes('ResizeObserver loop completed with undelivered notifications') ||
                              error.message.includes('ResizeObserver loop limit exceeded'))) {
                            return;
                          }
                          console.error('ResizeObserver error:', error);
                        }
                      });
                    };
                    super(wrappedCallback);
                  }
                };

                // Interceptar addEventListener para filtrar erros
                const originalAddEventListener = EventTarget.prototype.addEventListener;
                EventTarget.prototype.addEventListener = function(type, listener, options) {
                  if (type === 'error' && listener && typeof listener === 'function') {
                    const wrappedListener = function(e) {
                      if (e.message && (e.message.includes('ResizeObserver loop completed with undelivered notifications') ||
                          e.message.includes('ResizeObserver loop limit exceeded'))) {
                        return;
                      }
                      return listener.call(this, e);
                    };
                    return originalAddEventListener.call(this, type, wrappedListener, options);
                  }
                  return originalAddEventListener.call(this, type, listener, options);
                };
                
                // Suprimir erros no processo de renderização
                const originalThrow = Error.prototype.constructor;
                Error.prototype.constructor = function(message) {
                  if (typeof message === 'string' && 
                      (message.includes('ResizeObserver loop completed with undelivered notifications') ||
                       message.includes('ResizeObserver loop limit exceeded'))) {
                    return {};
                  }
                  return originalThrow.call(this, message);
                };
              })();
            `,
          }}
        />
      </head>
      <body className="bg-slate-950 text-slate-100">{children}{/* v0 – built-with badge */}
  <div dangerouslySetInnerHTML={{ __html: `<div id="v0-built-with-button-17b584da-971c-4b95-8789-7b3b96eda1ca" style="
border: 1px solid hsl(0deg 0% 100% / 12%);
position: fixed;
bottom: 24px;
right: 24px;
z-index: 1000;
background: #121212;
color: white;
padding: 8px 12px;
border-radius: 8px;
font-weight: 400;
font-size: 14px;
box-shadow: 0 2px 8px rgba(0,0,0,0.12);
letter-spacing: 0.02em;
transition: all 0.2s;
display: flex;
align-items: center;
gap: 4px;
font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
">
<a
  href="https://v0.app/chat/api/open/built-with-v0/b_ePT4VdNF0Tl?ref=YOJH0V"
  target="_blank"
  rel="noopener"
  style="
    color: inherit;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 4px;
  "
>
  Built with
  <svg
    fill="currentColor"
    viewBox="0 0 147 70"
    xmlns="http://www.w3.org/2000/svg"
    style="width: 20px; height: 20px;"
  >
    <path d="M56 50.2031V14H70V60.1562C70 65.5928 65.5928 70 60.1562 70C57.5605 70 54.9982 68.9992 53.1562 67.1573L0 14H19.7969L56 50.2031Z" />
    <path d="M147 56H133V23.9531L100.953 56H133V70H96.6875C85.8144 70 77 61.1856 77 50.3125V14H91V46.1562L123.156 14H91V0H127.312C138.186 0 147 8.81439 147 19.6875V56Z" />
  </svg>
</a>

<button
  onclick="document.getElementById('v0-built-with-button-17b584da-971c-4b95-8789-7b3b96eda1ca').style.display='none'"
  onmouseenter="this.style.opacity='1'"
  onmouseleave="this.style.opacity='0.7'"
  style="
    background: none;
    border: none;
    color: white;
    cursor: pointer;
    padding: 2px;
    margin-left: 4px;
    border-radius: 2px;
    display: flex;
    align-items: center;
    opacity: 0.7;
    transition: opacity 0.2s;
    transform: translateZ(0);
  "
  aria-label="Close"
>
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M18 6L6 18M6 6l12 12"/>
  </svg>
</button>

<span style="
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
">
  v0
</span>
</div>` }} />
</body>
    </html>
  )
}
