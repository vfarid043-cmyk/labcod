import FormGeneratorClient from "@/components/form-generator-client"

export default function FormGenerator() {
  return <FormGeneratorClient />
}
