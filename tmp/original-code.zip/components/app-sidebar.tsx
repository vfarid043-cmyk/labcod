"use client"

import { SidebarFooter } from "@/components/ui/sidebar"
import { User, LogOut } from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
} from "@/components/ui/sidebar"

interface AppSidebarProps {
  activeTab: "config" | "preview" | "code"
  onTabChange: (tab: "config" | "preview" | "code") => void
  handleLogout: () => void
  isLoggingOut: boolean
}

export function AppSidebar({ activeTab, onTabChange, handleLogout, isLoggingOut }: AppSidebarProps) {

  return (
    <Sidebar className="border-r border-slate-800/50 bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950">
      <SidebarHeader className="border-b border-slate-800/50 p-6">
        <div className="flex items-center gap-3">
          <div className="relative rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-cyan-500 p-2.5 shadow-lg shadow-indigo-500/25">
            <User className="h-5 w-5 text-white" />
            <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-cyan-500 blur-md opacity-50 animate-pulse" />
          </div>
          <div>
            <h2 className="font-bold text-lg bg-gradient-to-r from-indigo-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
              FormBuilder Pro
            </h2>
            <p className="text-xs text-slate-500 font-medium">Edição Enterprise</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="px-3 py-4">
        <SidebarGroup>
          <SidebarGroupLabel className="text-[10px] font-bold uppercase tracking-widest text-slate-500 px-3 mb-2">
            Modo
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => {}}
                  isActive={true}
                  className="group relative overflow-hidden rounded-lg data-[active=true]:bg-gradient-to-r data-[active=true]:from-indigo-600 data-[active=true]:to-purple-600 data-[active=true]:text-white data-[active=true]:shadow-lg data-[active=true]:shadow-indigo-500/25 hover:bg-slate-800/50 transition-all duration-200"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 opacity-0 group-hover:opacity-10 transition-opacity" />
                  <User className="h-4 w-4 relative z-10" />
                  <span className="relative z-10 font-medium">Gerador de Formulários</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup className="mt-6">
          <SidebarGroupLabel className="text-[10px] font-bold uppercase tracking-widest text-slate-500 px-3 mb-2">
            Workspace
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => onTabChange("config")}
                  isActive={activeTab === "config"}
                  className="group relative overflow-hidden rounded-lg data-[active=true]:bg-gradient-to-r data-[active=true]:from-indigo-600 data-[active=true]:to-purple-600 data-[active=true]:text-white data-[active=true]:shadow-lg data-[active=true]:shadow-indigo-500/25 hover:bg-slate-800/50 transition-all duration-200"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 opacity-0 group-hover:opacity-10 transition-opacity" />
                  <User className="h-4 w-4 relative z-10" />
                  <span className="relative z-10 font-medium">Configuração</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => onTabChange("preview")}
                  isActive={activeTab === "preview"}
                  className="group relative overflow-hidden rounded-lg data-[active=true]:bg-gradient-to-r data-[active=true]:from-indigo-600 data-[active=true]:to-purple-600 data-[active=true]:text-white data-[active=true]:shadow-lg data-[active=true]:shadow-indigo-500/25 hover:bg-slate-800/50 transition-all duration-200"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 opacity-0 group-hover:opacity-10 transition-opacity" />
                  <User className="h-4 w-4 relative z-10" />
                  <span className="relative z-10 font-medium">Visualização</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => onTabChange("code")}
                  isActive={activeTab === "code"}
                  className="group relative overflow-hidden rounded-lg data-[active=true]:bg-gradient-to-r data-[active=true]:from-indigo-600 data-[active=true]:to-purple-600 data-[active=true]:text-white data-[active=true]:shadow-lg data-[active=true]:shadow-indigo-500/25 hover:bg-slate-800/50 transition-all duration-200"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 opacity-0 group-hover:opacity-10 transition-opacity" />
                  <User className="h-4 w-4 relative z-10" />
                  <span className="relative z-10 font-medium">Exportar Código</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup className="mt-6">
          <SidebarGroupLabel className="text-[10px] font-bold uppercase tracking-widest text-slate-500 px-3 mb-2">
            Gerenciar
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              <SidebarMenuItem>
                <SidebarMenuButton className="group relative overflow-hidden rounded-lg hover:bg-slate-800/50 transition-all duration-200">
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 opacity-0 group-hover:opacity-10 transition-opacity" />
                  <User className="h-4 w-4 relative z-10" />
                  <span className="relative z-10 font-medium">Formulários Salvos</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton className="group relative overflow-hidden rounded-lg hover:bg-slate-800/50 transition-all duration-200">
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 opacity-0 group-hover:opacity-10 transition-opacity" />
                  <User className="h-4 w-4 relative z-10" />
                  <span className="relative z-10 font-medium">Modelos</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>


    </Sidebar>
  )
}
