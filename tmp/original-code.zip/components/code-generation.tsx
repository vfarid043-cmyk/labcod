"use client"

import type { FormConfig } from "@/types/form-config"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Copy, Download, Eye, FileCode, Globe, Server } from "lucide-react"
import { generateFormHTML, generateThankYouPage, generateSendOrderPHP } from "@/lib/code-generators"
import { useState } from "react"

interface CodeGenerationProps {
  config: FormConfig
}

export function CodeGeneration({ config }: CodeGenerationProps) {
  const [copiedTab, setCopiedTab] = useState<string | null>(null)

  const formHTML = generateFormHTML(config)
  const thankYouHTML = generateThankYouPage(config)
  const sendOrderPHP = generateSendOrderPHP(config)

  const copyToClipboard = async (text: string, tab: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedTab(tab)
      setTimeout(() => setCopiedTab(null), 2000)
    } catch (err) {
      console.error("Failed to copy text: ", err)
    }
  }

  const downloadFile = (content: string, filename: string) => {
    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const downloadAll = () => {
    const thankYouFilename = config.platform === "DR_CASH" ? "thank-you.html" : "success.html"
    const phpFilename =
      config.platform === "NETVORK" ||
      config.platform === "WEBVORK" ||
      config.platform === "TERRA_LEADS" ||
      config.platform === "SHAKES_PRO" ||
      config.platform === "CPAGETTI"
        ? "order.php"
        : config.platform === "LIMONAD"
          ? "lemon.php"
          : config.platform === "TRAFFIC_LIGHT"
            ? "send-lead.php"
            : "sendorder.php"

    downloadFile(formHTML, "index.html")
    downloadFile(thankYouHTML, thankYouFilename)
    downloadFile(sendOrderPHP, phpFilename)
  }

  const previewFormHTML = () => {
    const blob = new Blob([formHTML], { type: "text/html" })
    const url = URL.createObjectURL(blob)
    window.open(url, "_blank")
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  }

  const previewThankYouPage = () => {
    const blob = new Blob([thankYouHTML], { type: "text/html" })
    const url = URL.createObjectURL(blob)
    window.open(url, "_blank")
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  }

  return (
    <Card className="h-fit bg-gradient-to-b from-slate-900/40 to-slate-900/20 border-slate-800/50 shadow-2xl backdrop-blur-md">
      <CardHeader className="p-6 border-b border-slate-800/50 bg-gradient-to-r from-slate-900/50 to-slate-800/30">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="h-1 w-8 rounded-full bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 shadow-lg shadow-purple-500/25" />
              <CardTitle className="text-2xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-rose-400 bg-clip-text text-transparent">
                Exportar Código
              </CardTitle>
            </div>
            <p className="text-sm text-slate-400">Baixe ou copie seu código gerado</p>
          </div>
          <Button
            onClick={downloadAll}
            size="sm"
            className="gap-2 btn-primary bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 hover:from-green-500 hover:via-emerald-500 hover:to-teal-500 text-white shadow-lg shadow-green-500/30 font-semibold"
          >
            <Download className="w-4 h-4" />
            Baixar Tudo
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-4 sm:p-6">
        <Tabs defaultValue="form" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-slate-800/50 p-1 rounded-lg border border-slate-700/50">
            <TabsTrigger
              value="form"
              className="flex items-center gap-1 text-xs sm:text-sm text-slate-400 data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-indigo-600 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-200"
            >
              <Globe className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Formulário HTML</span>
              <span className="sm:hidden">HTML</span>
            </TabsTrigger>
            <TabsTrigger
              value="thanks"
              className="flex items-center gap-1 text-xs sm:text-sm text-slate-400 data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-600 data-[state=active]:to-emerald-600 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-200"
            >
              <FileCode className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Página Obrigado</span>
              <span className="sm:hidden">Obrigado</span>
            </TabsTrigger>
            <TabsTrigger
              value="php"
              className="flex items-center gap-1 text-xs sm:text-sm text-slate-400 data-[state=active]:bg-gradient-to-r data-[state=active]:from-violet-600 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-200"
            >
              <Server className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Processador PHP</span>
              <span className="sm:hidden">PHP</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="form" className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-slate-200 flex items-center gap-2">
                <Globe className="w-4 h-4 text-purple-400" />
                index.html
              </h3>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={previewFormHTML}
                  className="gap-2 bg-slate-800/50 border-slate-700/50 text-slate-300 hover:bg-slate-800/70 hover:text-white hover:border-indigo-500/30 transition-all duration-200"
                >
                  <Eye className="w-4 h-4" />
                  Visualizar
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(formHTML, "form")}
                  className="gap-2 bg-slate-800/50 border-slate-700/50 text-slate-300 hover:bg-slate-800/70 hover:text-white hover:border-indigo-500/30 transition-all duration-200"
                >
                  <Copy className="w-4 h-4" />
                  {copiedTab === "form" ? "Copiado!" : "Copiar"}
                </Button>
              </div>
            </div>
            <div className="bg-slate-950 text-slate-100 p-4 rounded-lg overflow-auto max-h-96 text-sm border border-slate-700/50 shadow-inner">
              <pre className="whitespace-pre-wrap">{formHTML}</pre>
            </div>
          </TabsContent>

          <TabsContent value="thanks" className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-slate-200 flex items-center gap-2">
                <FileCode className="w-4 h-4 text-green-400" />
                {config.platform === "DR_CASH" ? "thank-you.html" : "success.html"}
              </h3>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={previewThankYouPage}
                  className="gap-2 bg-slate-800/50 border-slate-600/50 text-slate-300 hover:bg-slate-700/50 hover:text-white"
                >
                  <Eye className="w-4 h-4" />
                  Preview
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(thankYouHTML, "thanks")}
                  className="gap-2 bg-slate-800/50 border-slate-600/50 text-slate-300 hover:bg-slate-700/50 hover:text-white"
                >
                  <Copy className="w-4 h-4" />
                  {copiedTab === "thanks" ? "Copiado!" : "Copiar"}
                </Button>
              </div>
            </div>
            <div className="bg-slate-950 text-slate-100 p-4 rounded-lg overflow-auto max-h-96 text-sm border border-slate-700/50 shadow-inner">
              <pre className="whitespace-pre-wrap">{thankYouHTML}</pre>
            </div>
          </TabsContent>

          <TabsContent value="php" className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-slate-200 flex items-center gap-2">
                <Server className="w-4 h-4 text-violet-400" />
                {config.platform === "NETVORK" ||
                config.platform === "WEBVORK" ||
                config.platform === "TERRA_LEADS" ||
                config.platform === "SHAKES_PRO" ||
                config.platform === "CPAGETTI"
                  ? "order.php"
                  : config.platform === "LIMONAD"
                    ? "lemon.php"
                    : config.platform === "TRAFFIC_LIGHT"
                      ? "send-lead.php"
                      : "sendorder.php"}
              </h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(sendOrderPHP, "php")}
                className="gap-2 bg-slate-800/50 border-slate-600/50 text-slate-300 hover:bg-slate-700/50 hover:text-white"
              >
                <Copy className="w-4 h-4" />
                {copiedTab === "php" ? "Copiado!" : "Copiar"}
              </Button>
            </div>
            <div className="bg-slate-950 text-slate-100 p-4 rounded-lg overflow-auto max-h-96 text-sm border border-slate-700/50 shadow-inner">
              <pre className="whitespace-pre-wrap">{sendOrderPHP}</pre>
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-6 p-4 bg-slate-800/30 rounded-lg border border-purple-500/20">
          <h4 className="font-semibold text-slate-200 mb-3 flex items-center gap-2">
            <FileCode className="w-4 h-4 text-purple-400" />
            Instruções de Configuração:
          </h4>
          <ol className="text-sm text-slate-400 space-y-2 list-decimal list-inside">
            <li>Faça upload dos três arquivos para seu servidor web</li>
            <li>Certifique-se de que o PHP está habilitado em sua hospedagem</li>
            <li>Teste o formulário enviando um pedido de teste</li>
            <li>Verifique se os pedidos estão sendo enviados para sua plataforma</li>
          </ol>
        </div>
      </CardContent>
    </Card>
  )
}
