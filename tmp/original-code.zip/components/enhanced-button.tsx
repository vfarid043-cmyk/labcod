import { Button } from "@/components/ui/button"
import { type ButtonProps } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface EnhancedButtonProps extends ButtonProps {
  variant?: "default" | "outline" | "ghost" | "link" | "destructive" | "secondary" | "gradient"
}

export function EnhancedButton({ 
  className, 
  variant = "default", 
  children, 
  ...props 
}: EnhancedButtonProps) {
  if (variant === "gradient") {
    return (
      <Button
        className={cn(
          "btn-primary bg-gradient-to-r from-indigo-600 to-cyan-600 text-white hover:from-indigo-500 hover:to-cyan-500 border-0 shadow-lg shadow-indigo-500/25",
          className
        )}
        {...props}
      >
        {children}
      </Button>
    )
  }

  return (
    <Button
      variant={variant}
      className={cn(
        variant === "default" && "btn-primary bg-indigo-600 hover:bg-indigo-700 text-white",
        className
      )}
      {...props}
    >
      {children}
    </Button>
  )
}
