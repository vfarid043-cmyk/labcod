"use client"

import type { FormConfig } from "@/types/form-config"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { countryConfigs } from "@/lib/country-configs"
import React from "react"

interface FormConfigurationProps {
  config: FormConfig
  onChange: (config: FormConfig) => void
}

const debounce = (func: Function, wait: number) => {
  let timeout: NodeJS.Timeout
  return function executedFunction(...args: any[]) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

export function FormConfiguration({ config, onChange }: FormConfigurationProps) {
  const updateConfig = (updates: Partial<FormConfig>) => {
    onChange({ ...config, ...updates })
  }

  const updateThankYou = (updates: Partial<FormConfig["thankYou"]>) => {
    onChange({
      ...config,
      thankYou: { ...config.thankYou, ...updates },
    })
  }

  const handleCountryChange = React.useCallback(
    debounce((countryCode: string) => {
      console.log("[v0] Country change initiated:", countryCode)
      const countryConfig = countryConfigs[countryCode]
      if (countryConfig) {
        const thankYouLanguage = countryConfig.language.thankYouPage || {
          title: countryConfig.language.headline,
          message: "Your order has been successfully processed.",
          buttonText: "Back to Site",
          finalText: "Important: Keep your phone nearby. We will contact you within 24 hours to confirm your order.",
          upsellTitle: "Special Offer!",
          upsellMessage: "Take advantage of this exclusive offer...",
          upsellButtonText: "I WANT IT",
        }

        updateConfig({
          country: countryCode,
          currency: countryConfig.currency,
          phonePlaceholder: countryConfig.phoneExample,
          primaryColor: countryConfig.defaultColor,
          buttonColor: countryConfig.defaultColor,
          headline: countryConfig.language.headline,
          namePlaceholder: countryConfig.language.namePlaceholder,
          ctaText: countryConfig.language.ctaText,
          availabilityText: countryConfig.language.availabilityText,
          securityText: countryConfig.language.securityText,
          disclaimerText: countryConfig.language.disclaimerText,
          thankYou: {
            ...config.thankYou,
            title: thankYouLanguage.title,
            message: thankYouLanguage.message,
            buttonText: thankYouLanguage.buttonText,
            finalText: thankYouLanguage.finalText,
            upsellTitle: thankYouLanguage.upsellTitle,
            upsellMessage: thankYouLanguage.upsellMessage,
            upsellButtonText: thankYouLanguage.upsellButtonText,
          },
        })
        console.log("[v0] Country configuration updated successfully")
      }
    }, 150),
    [updateConfig],
  )

  return (
    <Card className="h-fit bg-gradient-to-b from-slate-900/40 to-slate-900/20 border-slate-800/50 shadow-2xl backdrop-blur-md">
      <CardHeader className="p-6 border-b border-slate-800/50 bg-gradient-to-r from-slate-900/50 to-slate-800/30">
        <CardTitle className="text-2xl font-bold bg-gradient-to-r from-indigo-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
          Configuração do Formulário
        </CardTitle>
        <p className="text-sm text-slate-400 mt-1">Personalize as configurações do seu formulário</p>
      </CardHeader>
      <CardContent className="space-y-6 p-6">
        {/* Core Settings */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800/50">
            <div className="h-1 w-8 rounded-full bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600 shadow-lg shadow-indigo-500/25" />
            <h3 className="font-semibold text-base text-slate-100">Configurações da Plataforma</h3>
          </div>

          <div className="space-y-2">
            <Label htmlFor="platform" className="text-slate-300 text-sm font-medium">
              Plataforma
            </Label>
            <Select value={config.platform} onValueChange={(value) => updateConfig({ platform: value })}>
              <SelectTrigger className="bg-slate-800/50 border-slate-700/50 text-slate-100 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 hover:bg-slate-800/70 hover:border-indigo-500/30 transition-all duration-200">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="DR_CASH" className="text-white uppercase">
                  DR CASH
                </SelectItem>
                <SelectItem value="ADCOMBO" className="text-white uppercase">
                  ADCOMBO
                </SelectItem>
                <SelectItem value="NETVORK" className="text-white uppercase">
                  NETVORK
                </SelectItem>
                <SelectItem value="WEBVORK" className="text-white uppercase">
                  WEBVORK
                </SelectItem>
                <SelectItem value="LIMONAD" className="text-white uppercase">
                  LIMONAD
                </SelectItem>
                <SelectItem value="TRAFFIC_LIGHT" className="text-white uppercase">
                  TRAFFIC LIGHT
                </SelectItem>
                <SelectItem value="TERRA_LEADS" className="text-white uppercase">
                  TERRA LEADS
                </SelectItem>
                <SelectItem value="SHAKES_PRO" className="text-white uppercase">
                  SHAKES PRO
                </SelectItem>
                <SelectItem value="CPAGETTI" className="text-white uppercase">
                  CPAGETTI
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="apiKey" className="text-slate-300 text-sm font-medium">
              Chave API
            </Label>
            <Input
              id="apiKey"
              value={config.apiKey}
              onChange={(e) => updateConfig({ apiKey: e.target.value })}
              placeholder="Digite sua chave API"
              className="bg-slate-800/50 border-slate-700/50 text-slate-100 placeholder:text-slate-500 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 hover:bg-slate-800/70 hover:border-indigo-500/30 transition-all duration-200"
            />
          </div>

          {config.platform === "TERRA_LEADS" && (
            <div className="space-y-2">
              <Label htmlFor="userId" className="text-slate-300 text-sm font-medium">
                ID do Usuário
              </Label>
              <Input
                id="userId"
                value={config.userId || ""}
                onChange={(e) => updateConfig({ userId: e.target.value })}
                placeholder="Digite seu ID de usuário"
                className="bg-slate-800/50 border-slate-700/50 text-slate-100 placeholder:text-slate-500 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 hover:bg-slate-800/70 hover:border-indigo-500/30 transition-all duration-200"
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="offerId" className="text-slate-300 text-sm font-medium">
              ID da Oferta
            </Label>
            <Input
              id="offerId"
              value={config.offerId}
              onChange={(e) => updateConfig({ offerId: e.target.value })}
              placeholder="Digite o ID da oferta"
              className="bg-slate-800/50 border-slate-700/50 text-slate-100 placeholder:text-slate-500 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 hover:bg-slate-800/70 hover:border-indigo-500/30 transition-all duration-200"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="domain" className="text-slate-300 text-sm font-medium">
              Domínio
            </Label>
            <Input
              id="domain"
              value={config.domain}
              onChange={(e) => updateConfig({ domain: e.target.value })}
              placeholder="obrigado.exemplo.com"
              className="bg-slate-800/50 border-slate-700/50 text-slate-100 placeholder:text-slate-500 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 hover:bg-slate-800/70 hover:border-indigo-500/30 transition-all duration-200"
            />
            <p className="text-xs text-slate-500">
              {config.platform === "SHAKES_PRO"
                ? "Domínio onde o order.php será hospedado (ex: seusite.com)"
                : "Domínio para redirecionamento após envio do formulário"}
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="country" className="text-slate-300 text-sm font-medium">
              País
            </Label>
            <Select value={config.country} onValueChange={handleCountryChange}>
              <SelectTrigger className="bg-slate-800/50 border-slate-700/50 text-slate-100 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 hover:bg-slate-800/70 hover:border-indigo-500/30 transition-all duration-200">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700 max-h-60">
                <SelectItem value="RO" className="text-white">
                  🇷🇴 ROMÊNIA
                </SelectItem>
                <SelectItem value="BR" className="text-white">
                  🇧🇷 BRASIL
                </SelectItem>
                <SelectItem value="PT" className="text-white">
                  🇵🇹 PORTUGAL
                </SelectItem>
                <SelectItem value="ES" className="text-white">
                  🇪🇸 ESPANHA
                </SelectItem>
                <SelectItem value="IT" className="text-white">
                  🇮🇹 ITÁLIA
                </SelectItem>
                <SelectItem value="FR" className="text-white">
                  🇫🇷 FRANÇA
                </SelectItem>
                <SelectItem value="DE" className="text-white">
                  🇩🇪 ALEMANHA
                </SelectItem>
                <SelectItem value="PL" className="text-white">
                  🇵🇱 POLÔNIA
                </SelectItem>
                <SelectItem value="CZ" className="text-white">
                  🇨🇿 REPÚBLICA TCHECA
                </SelectItem>
                <SelectItem value="HU" className="text-white">
                  🇭🇺 HUNGRIA
                </SelectItem>
                <SelectItem value="BG" className="text-white">
                  🇧🇬 BULGÁRIA
                </SelectItem>
                <SelectItem value="GR" className="text-white">
                  🇬🇷 GRÉCIA
                </SelectItem>
                <SelectItem value="HR" className="text-white">
                  🇭🇷 CROÁCIA
                </SelectItem>
                <SelectItem value="SK" className="text-white">
                  🇸🇰 ESLOVÁQUIA
                </SelectItem>
                <SelectItem value="SI" className="text-white">
                  🇸🇮 ESLOVÊNIA
                </SelectItem>
                <SelectItem value="LT" className="text-white">
                  🇱🇹 LITUÂNIA
                </SelectItem>
                <SelectItem value="LV" className="text-white">
                  🇱🇻 LETÔNIA
                </SelectItem>
                <SelectItem value="EE" className="text-white">
                  🇪🇪 ESTÔNIA
                </SelectItem>
                <SelectItem value="MX" className="text-white">
                  🇲🇽 MÉXICO
                </SelectItem>
                <SelectItem value="CO" className="text-white">
                  🇨🇴 COLÔMBIA
                </SelectItem>
                <SelectItem value="PE" className="text-white">
                  🇵🇪 PERU
                </SelectItem>
                <SelectItem value="CL" className="text-white">
                  🇨🇱 CHILE
                </SelectItem>
                <SelectItem value="AR" className="text-white">
                  🇦🇷 ARGENTINA
                </SelectItem>
                <SelectItem value="TR" className="text-white">
                  🇹🇷 TURQUIA
                </SelectItem>
                <SelectItem value="TH" className="text-white">
                  🇹🇭 TAILÂNDIA
                </SelectItem>
                <SelectItem value="VN" className="text-white">
                  🇻🇳 VIETNÃ
                </SelectItem>
                <SelectItem value="ID" className="text-white">
                  🇮🇩 INDONÉSIA
                </SelectItem>
                <SelectItem value="MY" className="text-white">
                  🇲🇾 MALÁSIA
                </SelectItem>
                <SelectItem value="PH" className="text-white">
                  🇵🇭 FILIPINAS
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Separator className="bg-slate-700/50" />

        {/* Visual Settings */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800/50">
            <div className="h-1 w-8 rounded-full bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 shadow-lg shadow-cyan-500/25" />
            <h3 className="font-semibold text-base text-slate-100">Configurações Visuais</h3>
          </div>

          <div className="space-y-2">
            <Label htmlFor="headline" className="text-slate-300">
              Título Principal
            </Label>
            <Input
              id="headline"
              value={config.headline}
              onChange={(e) => updateConfig({ headline: e.target.value })}
              className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>

          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            <div className="space-y-2">
              <Label htmlFor="oldPrice" className="text-slate-300">
                Preço Antigo
              </Label>
              <Input
                id="oldPrice"
                value={config.oldPrice}
                onChange={(e) => updateConfig({ oldPrice: e.target.value })}
                className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="newPrice" className="text-slate-300">
                Preço Novo
              </Label>
              <Input
                id="newPrice"
                value={config.newPrice}
                onChange={(e) => updateConfig({ newPrice: e.target.value })}
                className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            <div className="space-y-2">
              <Label htmlFor="currency" className="text-slate-300">
                Moeda
              </Label>
              <Input
                id="currency"
                value={config.currency}
                onChange={(e) => updateConfig({ currency: e.target.value })}
                className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="discount" className="text-slate-300">
                Desconto %
              </Label>
              <Input
                id="discount"
                value={config.discount}
                onChange={(e) => updateConfig({ discount: e.target.value })}
                className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="ctaText" className="text-slate-300">
              Texto do Botão
            </Label>
            <Input
              id="ctaText"
              value={config.ctaText}
              onChange={(e) => updateConfig({ ctaText: e.target.value })}
              className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="namePlaceholder" className="text-slate-300">
              Placeholder do Nome
            </Label>
            <Input
              id="namePlaceholder"
              value={config.namePlaceholder}
              onChange={(e) => updateConfig({ namePlaceholder: e.target.value })}
              className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phonePlaceholder" className="text-slate-300">
              Placeholder do Telefone
            </Label>
            <Input
              id="phonePlaceholder"
              value={config.phonePlaceholder}
              onChange={(e) => updateConfig({ phonePlaceholder: e.target.value })}
              className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="availabilityText" className="text-slate-300">
              Texto de Disponibilidade
            </Label>
            <Input
              id="availabilityText"
              value={config.availabilityText}
              onChange={(e) => updateConfig({ availabilityText: e.target.value })}
              className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="securityText" className="text-slate-300">
              Texto de Segurança
            </Label>
            <Input
              id="securityText"
              value={config.securityText}
              onChange={(e) => updateConfig({ securityText: e.target.value })}
              className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="disclaimerText" className="text-slate-300">
              Texto de Aviso
            </Label>
            <Input
              id="disclaimerText"
              value={config.disclaimerText}
              onChange={(e) => updateConfig({ disclaimerText: e.target.value })}
              className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>
        </div>

        <Separator className="bg-slate-700/50" />

        {/* Colors */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800/50">
            <div className="h-1 w-8 rounded-full bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 shadow-lg shadow-pink-500/25" />
            <h3 className="font-semibold text-base text-slate-100">Esquema de Cores</h3>
          </div>

          <div className="grid grid-cols-3 gap-3 sm:gap-4">
            <div className="space-y-2">
              <Label htmlFor="primaryColor" className="text-slate-300 text-xs">
                Primária
              </Label>
              <div className="flex gap-2">
                <Input
                  id="primaryColor"
                  type="color"
                  value={config.primaryColor}
                  onChange={(e) => updateConfig({ primaryColor: e.target.value })}
                  className="h-10 w-12 p-1 cursor-pointer bg-slate-800/50 border-slate-600/50"
                />
                <Input
                  value={config.primaryColor}
                  onChange={(e) => updateConfig({ primaryColor: e.target.value })}
                  className="flex-1 text-xs bg-slate-800/50 border-slate-600/50 text-slate-100"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="buttonColor" className="text-slate-300 text-xs">
                Botão
              </Label>
              <div className="flex gap-2">
                <Input
                  id="buttonColor"
                  type="color"
                  value={config.buttonColor}
                  onChange={(e) => updateConfig({ buttonColor: e.target.value })}
                  className="h-10 w-12 p-1 cursor-pointer bg-slate-800/50 border-slate-600/50"
                />
                <Input
                  value={config.buttonColor}
                  onChange={(e) => updateConfig({ buttonColor: e.target.value })}
                  className="flex-1 text-xs bg-slate-800/50 border-slate-600/50 text-slate-100"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="backgroundColor" className="text-slate-300 text-xs">
                Fundo
              </Label>
              <div className="flex gap-2">
                <Input
                  id="backgroundColor"
                  type="color"
                  value={config.backgroundColor}
                  onChange={(e) => updateConfig({ backgroundColor: e.target.value })}
                  className="h-10 w-12 p-1 cursor-pointer bg-slate-800/50 border-slate-600/50"
                />
                <Input
                  value={config.backgroundColor}
                  onChange={(e) => updateConfig({ backgroundColor: e.target.value })}
                  className="flex-1 text-xs bg-slate-800/50 border-slate-600/50 text-slate-100"
                />
              </div>
            </div>
          </div>
        </div>

        <Separator className="bg-slate-700/50" />

        {/* Button Settings */}
        <div className="space-y-3 sm:space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-700/50">
            <div className="h-1 w-8 rounded-full bg-gradient-to-r from-green-600 to-emerald-600" />
            <h3 className="font-semibold text-base text-slate-100">Button Settings</h3>
          </div>

          <div className="space-y-2">
            <Label htmlFor="buttonBorderRadius" className="text-slate-300">
              Borda Arredondada
            </Label>
            <Select
              value={config.buttonBorderRadius}
              onValueChange={(value) => updateConfig({ buttonBorderRadius: value })}
            >
              <SelectTrigger className="bg-slate-800/50 border-slate-600/50 text-slate-100 focus:border-purple-500 focus:ring-purple-500/20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-600">
                <SelectItem value="none">Sem Arredondamento</SelectItem>
                <SelectItem value="sm">Pequeno</SelectItem>
                <SelectItem value="md">Médio</SelectItem>
                <SelectItem value="lg">Grande</SelectItem>
                <SelectItem value="full">Completo (Pílula)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="buttonSize" className="text-slate-300">
              Tamanho do Botão
            </Label>
            <Select value={config.buttonSize} onValueChange={(value) => updateConfig({ buttonSize: value })}>
              <SelectTrigger className="bg-slate-800/50 border-slate-600/50 text-slate-100 focus:border-purple-500 focus:ring-purple-500/20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-600">
                <SelectItem value="small">Pequeno</SelectItem>
                <SelectItem value="medium">Médio</SelectItem>
                <SelectItem value="large">Grande</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="buttonWidth" className="text-slate-300">
              Largura do Botão
            </Label>
            <Select value={config.buttonWidth} onValueChange={(value) => updateConfig({ buttonWidth: value })}>
              <SelectTrigger className="bg-slate-800/50 border-slate-600/50 text-slate-100 focus:border-purple-500 focus:ring-purple-500/20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-600">
                <SelectItem value="auto">Automática</SelectItem>
                <SelectItem value="full">Largura Total</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="belowButtonText" className="text-slate-300">
              Texto Abaixo do Botão
            </Label>
            <Input
              id="belowButtonText"
              value={config.belowButtonText}
              onChange={(e) => updateConfig({ belowButtonText: e.target.value })}
              placeholder="Dados 100% seguros"
              className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="belowButtonEmoji" className="text-slate-300">
              Emoji Abaixo do Botão
            </Label>
            <Input
              id="belowButtonEmoji"
              value={config.belowButtonEmoji}
              onChange={(e) => updateConfig({ belowButtonEmoji: e.target.value })}
              placeholder="🔒"
              className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>
        </div>

        <Separator className="bg-slate-700/50" />

        {/* Form Dimensions */}
        <div className="space-y-3 sm:space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-700/50">
            <div className="h-1 w-8 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600" />
            <h3 className="font-semibold text-base text-slate-100">Form Dimensions</h3>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            <div className="space-y-2">
              <Label htmlFor="formWidth" className="text-slate-300">
                Largura (px)
              </Label>
              <Input
                id="formWidth"
                value={config.formWidth}
                onChange={(e) => updateConfig({ formWidth: e.target.value })}
                placeholder="380"
                className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="formMaxWidth" className="text-slate-300">
                Largura Máx
              </Label>
              <Input
                id="formMaxWidth"
                value={config.formMaxWidth}
                onChange={(e) => updateConfig({ formMaxWidth: e.target.value })}
                placeholder="95%"
                className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="formHeight" className="text-slate-300">
              Altura
            </Label>
            <Input
              id="formHeight"
              value={config.formHeight}
              onChange={(e) => updateConfig({ formHeight: e.target.value })}
              placeholder="auto"
              className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>
        </div>

        <Separator className="bg-slate-700/50" />

        {/* Product Image */}
        <div className="space-y-3 sm:space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-700/50">
            <div className="h-1 w-8 rounded-full bg-gradient-to-r from-cyan-600 to-blue-600" />
            <h3 className="font-semibold text-base text-slate-100">Product Image</h3>
          </div>
            <Switch
              checked={config.showProductImage}
              onCheckedChange={(checked) => updateConfig({ showProductImage: checked })}
            />
          </div>

          {config.showProductImage && (
            <>
              <div className="space-y-2">
                <Label htmlFor="productImageUrl" className="text-slate-300">
                  URL da Imagem
                </Label>
                <Input
                  id="productImageUrl"
                  value={config.productImageUrl}
                  onChange={(e) => updateConfig({ productImageUrl: e.target.value })}
                  placeholder="https://exemplo.com/imagem.jpg"
                  className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="productImagePosition" className="text-slate-300">
                  Posição da Imagem
                </Label>
                <Select
                  value={config.productImagePosition}
                  onValueChange={(value) => updateConfig({ productImagePosition: value })}
                >
                  <SelectTrigger className="bg-slate-800/50 border-slate-600/50 text-slate-100 focus:border-purple-500 focus:ring-purple-500/20">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-600">
                    <SelectItem value="top" className="text-white">
                      TOPO
                    </SelectItem>
                    <SelectItem value="left" className="text-white">
                      ESQUERDA (AO LADO DO PREÇO)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </>
          )}
        </div>

        <Separator className="bg-slate-700/50" />

        {/* Countdown */}
        <div className="space-y-3 sm:space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-700/50">
            <div className="h-1 w-8 rounded-full bg-gradient-to-r from-orange-600 to-red-600" />
            <h3 className="font-semibold text-base text-slate-100">Countdown Timer</h3>
          </div>
            <Switch
              checked={config.showCountdown}
              onCheckedChange={(checked) => updateConfig({ showCountdown: checked })}
            />
          </div>

          {config.showCountdown && (
            <>
              <div className="grid grid-cols-3 gap-3 sm:gap-4">
                <div className="space-y-2">
                  <Label htmlFor="countdownHours" className="text-slate-300 text-xs">
                    Horas
                  </Label>
                  <Input
                    id="countdownHours"
                    type="number"
                    min="0"
                    max="23"
                    value={config.countdownHours}
                    onChange={(e) => updateConfig({ countdownHours: Number.parseInt(e.target.value) || 0 })}
                    className="bg-slate-800/50 border-slate-600/50 text-slate-100 focus:border-purple-500 focus:ring-purple-500/20"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="countdownMinutes" className="text-slate-300 text-xs">
                    Minutos
                  </Label>
                  <Input
                    id="countdownMinutes"
                    type="number"
                    min="0"
                    max="59"
                    value={config.countdownMinutes}
                    onChange={(e) => updateConfig({ countdownMinutes: Number.parseInt(e.target.value) || 0 })}
                    className="bg-slate-800/50 border-slate-600/50 text-slate-100 focus:border-purple-500 focus:ring-purple-500/20"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="countdownSeconds" className="text-slate-300 text-xs">
                    Segundos
                  </Label>
                  <Input
                    id="countdownSeconds"
                    type="number"
                    min="0"
                    max="59"
                    value={config.countdownSeconds}
                    onChange={(e) => updateConfig({ countdownSeconds: Number.parseInt(e.target.value) || 0 })}
                    className="bg-slate-800/50 border-slate-600/50 text-slate-100 focus:border-purple-500 focus:ring-purple-500/20"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="countdownColor" className="text-slate-300">
                  Cor do Contador
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="countdownColor"
                    type="color"
                    value={config.countdownColor}
                    onChange={(e) => updateConfig({ countdownColor: e.target.value })}
                    className="h-10 w-12 p-1 cursor-pointer bg-slate-800/50 border-slate-600/50"
                  />
                  <Input
                    value={config.countdownColor}
                    onChange={(e) => updateConfig({ countdownColor: e.target.value })}
                    className="flex-1 bg-slate-800/50 border-slate-600/50 text-slate-100"
                  />
                </div>
              </div>
            </>
          )}
        </div>

        <Separator className="bg-slate-700/50" />

        {/* Social Proof */}
        <div className="space-y-3 sm:space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-700/50">
            <div className="h-1 w-8 rounded-full bg-gradient-to-r from-green-600 to-teal-600" />
            <h3 className="font-semibold text-base text-slate-100">Social Proof</h3>
          </div>

          <div className="space-y-2">
            <Label htmlFor="socialProofPeople" className="text-slate-300">
              Pessoas Visualizando: {config.socialProofPeople}
            </Label>
            <Slider
              value={[config.socialProofPeople]}
              onValueChange={([value]) => updateConfig({ socialProofPeople: value })}
              max={100}
              min={1}
              step={1}
              className="py-2"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="socialProofSales" className="text-slate-300">
              Vendas na Última Hora: {config.socialProofSales}
            </Label>
            <Slider
              value={[config.socialProofSales]}
              onValueChange={([value]) => updateConfig({ socialProofSales: value })}
              max={50}
              min={1}
              step={1}
              className="py-2"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="packagesLeft" className="text-slate-300">
              Pacotes Restantes: {config.packagesLeft}
            </Label>
            <Slider
              value={[config.packagesLeft]}
              onValueChange={([value]) => updateConfig({ packagesLeft: value })}
              max={200}
              min={1}
              step={1}
              className="py-2"
            />
          </div>
        </div>

        <Separator className="bg-slate-700/50" />

        {/* Thank You Page Settings */}
        <div className="space-y-3 sm:space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-700/50">
            <div className="h-1 w-8 rounded-full bg-gradient-to-r from-purple-600 to-pink-600" />
            <h3 className="font-semibold text-base text-slate-100">Thank You Page</h3>
          </div>
            <Switch
              checked={config.thankYou.enabled}
              onCheckedChange={(checked) => updateThankYou({ enabled: checked })}
            />
          </div>

          {config.thankYou.enabled && (
            <>
              <div className="space-y-2">
                <Label htmlFor="thankYouTitle" className="text-slate-300">
                  Título
                </Label>
                <Input
                  id="thankYouTitle"
                  value={config.thankYou.title}
                  onChange={(e) => updateThankYou({ title: e.target.value })}
                  className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="thankYouMessage" className="text-slate-300">
                  Mensagem
                </Label>
                <Textarea
                  id="thankYouMessage"
                  value={config.thankYou.message}
                  onChange={(e) => updateThankYou({ message: e.target.value })}
                  rows={3}
                  className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20 resize-none"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="thankYouButtonText" className="text-slate-300">
                  Texto do Botão
                </Label>
                <Input
                  id="thankYouButtonText"
                  value={config.thankYou.buttonText}
                  onChange={(e) => updateThankYou({ buttonText: e.target.value })}
                  className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="thankYouButtonUrl" className="text-slate-300">
                  URL do Botão
                </Label>
                <Input
                  id="thankYouButtonUrl"
                  value={config.thankYou.buttonUrl}
                  onChange={(e) => updateThankYou({ buttonUrl: e.target.value })}
                  className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 sm:gap-4">
                <div className="space-y-2">
                  <Label htmlFor="thankYouBgColor" className="text-slate-300 text-xs">
                    Cor de Fundo
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="thankYouBgColor"
                      type="color"
                      value={config.thankYou.backgroundColor}
                      onChange={(e) => updateThankYou({ backgroundColor: e.target.value })}
                      className="h-10 w-12 p-1 cursor-pointer bg-slate-800/50 border-slate-600/50"
                    />
                    <Input
                      value={config.thankYou.backgroundColor}
                      onChange={(e) => updateThankYou({ backgroundColor: e.target.value })}
                      className="flex-1 text-xs bg-slate-800/50 border-slate-600/50 text-slate-100"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="thankYouContainerColor" className="text-slate-300 text-xs">
                    Cor do Container
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="thankYouContainerColor"
                      type="color"
                      value={config.thankYou.containerColor}
                      onChange={(e) => updateThankYou({ containerColor: e.target.value })}
                      className="h-10 w-12 p-1 cursor-pointer bg-slate-800/50 border-slate-600/50"
                    />
                    <Input
                      value={config.thankYou.containerColor}
                      onChange={(e) => updateThankYou({ containerColor: e.target.value })}
                      className="flex-1 text-xs bg-slate-800/50 border-slate-600/50 text-slate-100"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 sm:gap-4">
                <div className="space-y-2">
                  <Label htmlFor="thankYouTitleColor" className="text-slate-300 text-xs">
                    Cor do Título
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="thankYouTitleColor"
                      type="color"
                      value={config.thankYou.titleColor}
                      onChange={(e) => updateThankYou({ titleColor: e.target.value })}
                      className="h-10 w-12 p-1 cursor-pointer bg-slate-800/50 border-slate-600/50"
                    />
                    <Input
                      value={config.thankYou.titleColor}
                      onChange={(e) => updateThankYou({ titleColor: e.target.value })}
                      className="flex-1 text-xs bg-slate-800/50 border-slate-600/50 text-slate-100"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="thankYouMessageColor" className="text-slate-300 text-xs">
                    Cor da Mensagem
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="thankYouMessageColor"
                      type="color"
                      value={config.thankYou.messageColor}
                      onChange={(e) => updateThankYou({ messageColor: e.target.value })}
                      className="h-10 w-12 p-1 cursor-pointer bg-slate-800/50 border-slate-600/50"
                    />
                    <Input
                      value={config.thankYou.messageColor}
                      onChange={(e) => updateThankYou({ messageColor: e.target.value })}
                      className="flex-1 text-xs bg-slate-800/50 border-slate-600/50 text-slate-100"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 sm:gap-4">
                <div className="space-y-2">
                  <Label htmlFor="thankYouButtonColor" className="text-slate-300 text-xs">
                    Cor do Botão
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="thankYouButtonColor"
                      type="color"
                      value={config.thankYou.buttonColor}
                      onChange={(e) => updateThankYou({ buttonColor: e.target.value })}
                      className="h-10 w-12 p-1 cursor-pointer bg-slate-800/50 border-slate-600/50"
                    />
                    <Input
                      value={config.thankYou.buttonColor}
                      onChange={(e) => updateThankYou({ buttonColor: e.target.value })}
                      className="flex-1 text-xs bg-slate-800/50 border-slate-600/50 text-slate-100"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="thankYouButtonTextColor" className="text-slate-300 text-xs">
                    Cor Texto Botão
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="thankYouButtonTextColor"
                      type="color"
                      value={config.thankYou.buttonTextColor}
                      onChange={(e) => updateThankYou({ buttonTextColor: e.target.value })}
                      className="h-10 w-12 p-1 cursor-pointer bg-slate-800/50 border-slate-600/50"
                    />
                    <Input
                      value={config.thankYou.buttonTextColor}
                      onChange={(e) => updateThankYou({ buttonTextColor: e.target.value })}
                      className="flex-1 text-xs bg-slate-800/50 border-slate-600/50 text-slate-100"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="thankYouButtonSize" className="text-slate-300">
                  Tamanho do Botão
                </Label>
                <Select
                  value={config.thankYou.buttonSize}
                  onValueChange={(value) => updateThankYou({ buttonSize: value })}
                >
                  <SelectTrigger className="bg-slate-800/50 border-slate-600/50 text-slate-100 focus:border-purple-500 focus:ring-purple-500/20">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-600">
                    <SelectItem value="small">Pequeno</SelectItem>
                    <SelectItem value="medium">Médio</SelectItem>
                    <SelectItem value="large">Grande</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator className="bg-slate-700/50" />

              {/* Thank You Image */}
              <div className="space-y-3 sm:space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-slate-300">Mostrar Imagem</Label>
                  <Switch
                    checked={config.thankYou.showImage}
                    onCheckedChange={(checked) => updateThankYou({ showImage: checked })}
                  />
                </div>

                {config.thankYou.showImage && (
                  <div className="space-y-2">
                    <Label htmlFor="thankYouImageUrl" className="text-slate-300">
                      URL da Imagem
                    </Label>
                    <Input
                      id="thankYouImageUrl"
                      value={config.thankYou.imageUrl}
                      onChange={(e) => updateThankYou({ imageUrl: e.target.value })}
                      placeholder="https://exemplo.com/imagem.jpg"
                      className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
                    />
                  </div>
                )}
              </div>

              <Separator className="bg-slate-700/50" />

              {/* Upsell Settings */}
              <div className="space-y-3 sm:space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-slate-300">Mostrar Upsell</Label>
                  <Switch
                    checked={config.thankYou.showUpsell}
                    onCheckedChange={(checked) => updateThankYou({ showUpsell: checked })}
                  />
                </div>

                {config.thankYou.showUpsell && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="upsellTitle" className="text-slate-300">
                        Título do Upsell
                      </Label>
                      <Input
                        id="upsellTitle"
                        value={config.thankYou.upsellTitle}
                        onChange={(e) => updateThankYou({ upsellTitle: e.target.value })}
                        className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="upsellMessage" className="text-slate-300">
                        Mensagem do Upsell
                      </Label>
                      <Textarea
                        id="upsellMessage"
                        value={config.thankYou.upsellMessage}
                        onChange={(e) => updateThankYou({ upsellMessage: e.target.value })}
                        rows={2}
                        className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20 resize-none"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="upsellButtonText" className="text-slate-300">
                        Texto do Botão Upsell
                      </Label>
                      <Input
                        id="upsellButtonText"
                        value={config.thankYou.upsellButtonText}
                        onChange={(e) => updateThankYou({ upsellButtonText: e.target.value })}
                        className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="upsellButtonUrl" className="text-slate-300">
                        URL do Botão Upsell
                      </Label>
                      <Input
                        id="upsellButtonUrl"
                        value={config.thankYou.upsellButtonUrl}
                        onChange={(e) => updateThankYou({ upsellButtonUrl: e.target.value })}
                        className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="upsellPrice" className="text-slate-300">
                        Preço do Upsell
                      </Label>
                      <Input
                        id="upsellPrice"
                        value={config.thankYou.upsellPrice}
                        onChange={(e) => updateThankYou({ upsellPrice: e.target.value })}
                        className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3 sm:gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="upsellButtonColor" className="text-slate-300 text-xs">
                          Cor Botão Upsell
                        </Label>
                        <div className="flex gap-2">
                          <Input
                            id="upsellButtonColor"
                            type="color"
                            value={config.thankYou.upsellButtonColor}
                            onChange={(e) => updateThankYou({ upsellButtonColor: e.target.value })}
                            className="h-10 w-12 p-1 cursor-pointer bg-slate-800/50 border-slate-600/50"
                          />
                          <Input
                            value={config.thankYou.upsellButtonColor}
                            onChange={(e) => updateThankYou({ upsellButtonColor: e.target.value })}
                            className="flex-1 text-xs bg-slate-800/50 border-slate-600/50 text-slate-100"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="upsellBgColor" className="text-slate-300 text-xs">
                          Fundo Upsell
                        </Label>
                        <div className="flex gap-2">
                          <Input
                            id="upsellBgColor"
                            type="color"
                            value={config.thankYou.upsellBackgroundColor}
                            onChange={(e) => updateThankYou({ upsellBackgroundColor: e.target.value })}
                            className="h-10 w-12 p-1 cursor-pointer bg-slate-800/50 border-slate-600/50"
                          />
                          <Input
                            value={config.thankYou.upsellBackgroundColor}
                            onChange={(e) => updateThankYou({ upsellBackgroundColor: e.target.value })}
                            className="flex-1 text-xs bg-slate-800/50 border-slate-600/50 text-slate-100"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <Label className="text-slate-300">Mostrar Imagem Upsell</Label>
                      <Switch
                        checked={config.thankYou.showUpsellImage}
                        onCheckedChange={(checked) => updateThankYou({ showUpsellImage: checked })}
                      />
                    </div>

                    {config.thankYou.showUpsellImage && (
                      <div className="space-y-2">
                        <Label htmlFor="upsellImageUrl" className="text-slate-300">
                          URL Imagem Upsell
                        </Label>
                        <Input
                          id="upsellImageUrl"
                          value={config.thankYou.upsellImageUrl}
                          onChange={(e) => updateThankYou({ upsellImageUrl: e.target.value })}
                          placeholder="https://exemplo.com/upsell.jpg"
                          className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
                        />
                      </div>
                    )}
                  </>
                )}
              </div>

              <Separator className="bg-slate-700/50" />

              {/* Final Text */}
              <div className="space-y-2">
                <Label htmlFor="thankYouFinalText" className="text-slate-300">
                  Texto Final
                </Label>
                <Textarea
                  id="thankYouFinalText"
                  value={config.thankYou.finalText}
                  onChange={(e) => updateThankYou({ finalText: e.target.value })}
                  rows={4}
                  className="bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20 resize-none"
                />
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
