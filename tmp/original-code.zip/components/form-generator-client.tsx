"use client"

import { useRouter } from "next/navigation"
import { useState } from "react"
import { FormConfiguration } from "@/components/form-configuration"
import { FormPreview } from "@/components/form-preview"
import { CodeGeneration } from "@/components/code-generation"
import { FormReplacer } from "@/components/form-replacer"
import type { FormConfig } from "@/types/form-config"
import { Save, FolderOpen, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { SaveProjectDialog } from "@/components/save-project-dialog"
import { SavedFormsDrawer } from "@/components/saved-forms-drawer"
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/app-sidebar"
import { createBrowserClient } from "@/supabase-browser-client"
import { AnimatedBackground } from "@/components/animated-background"
import { LogOut } from "lucide-react"
import { Wand2 } from "lucide-react"
import { FileCode } from "lucide-react"
import { Palette } from "lucide-react"
import { Code2 } from "lucide-react"
import { Zap } from "lucide-react"

const defaultConfig: FormConfig = {
  platform: "DR_CASH",
  apiKey: "",
  offerId: "",
  domain: "",
  userId: "",
  country: "RO",
  headline: "Doar astăzi",
  oldPrice: "298",
  newPrice: "149",
  currency: "RON",
  discount: "50",
  ctaText: "COMANDAȚI CU REDUCERE",
  namePlaceholder: "Numele",
  phonePlaceholder: "+40 123 456 789",
  availabilityText: "Au rămas 80 de pachete",
  securityText: "Datele dvs. sunt protejate!",
  disclaimerText: "* Funcționează asupra mărturiilor în limitele unui canal de distribuție",
  formWidth: "380",
  formMaxWidth: "95%",
  formHeight: "auto",
  buttonBorderRadius: "lg",
  buttonSize: "medium",
  buttonWidth: "full",
  belowButtonText: "Dados 100% seguros",
  belowButtonEmoji: "🔒",
  primaryColor: "#dc3545",
  buttonColor: "#dc3545",
  backgroundColor: "#f8f9fa",
  showProductImage: false,
  productImageUrl: "",
  productImagePosition: "top",
  showCountdown: true,
  countdownHours: 3,
  countdownMinutes: 58,
  countdownSeconds: 23,
  countdownColor: "#dc3545",
  socialProofPeople: 29,
  socialProofSales: 16,
  packagesLeft: 80,
  thankYou: {
    enabled: true,
    title: "Obrigado pela sua compra!",
    message: "Sua compra foi processada com sucesso. Em breve entraremos em contato para confirmar os detalhes.",
    buttonText: "Voltar ao Site",
    buttonUrl: "/",
    backgroundColor: "#f4f4f4",
    containerColor: "#ffffff",
    titleColor: "#4CAF50",
    messageColor: "#666666",
    buttonColor: "#4CAF50",
    buttonTextColor: "#ffffff",
    buttonSize: "medium",
    countdownColor: "#dc3545",
    showImage: false,
    imageUrl: "",
    showUpsell: false,
    upsellTitle: "Oferta Especial!",
    upsellMessage: "Aproveite esta oferta exclusiva por tempo limitado!",
    upsellButtonText: "QUERO APROVEITAR",
    upsellButtonUrl: "",
    upsellPrice: "R$ 97",
    upsellButtonColor: "#ff6b35",
    upsellBackgroundColor: "#ff6b35",
    showUpsellImage: false,
    upsellImageUrl: "",
    finalText:
      "Importante: Mantenha seu telefone por perto. Entraremos em contato em até 24 horas para confirmar sua compra.\n\nDúvidas?\nEntre em contato: suporte@seusite.com",
  },
}

export default function FormGeneratorClient() {
  const [config, setConfig] = useState<FormConfig>(defaultConfig)
  const [activeTab, setActiveTab] = useState<"config" | "preview" | "code">("config")

  const renderContent = () => {
    if (activeTab === "config") {
      return (
        <div className="animate-scale-in">
          <FormConfiguration config={config} onChange={setConfig} />
        </div>
      )
    }

    if (activeTab === "preview") {
      return (
        <div className="animate-scale-in p-6">
          <FormPreview config={config} />
        </div>
      )
    }

    return (
      <div className="animate-scale-in">
        <CodeGeneration config={config} />
      </div>
    )
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
        <AppSidebar activeTab={activeTab} onTabChange={setActiveTab} />
        
        <main className="flex-1 overflow-auto">
          <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b border-slate-800/50 bg-slate-900/80 backdrop-blur-xl supports-[backdrop-filter]:bg-slate-900/60 px-6 animate-slide-in">
            <SidebarTrigger className="text-slate-400 hover:text-slate-100 transition-all duration-200 hover:scale-110" />
            
            <div className="flex items-center gap-3 flex-1">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Sparkles className="h-5 w-5 text-indigo-400 animate-float" />
                  <div className="absolute inset-0 bg-indigo-500 blur-xl opacity-30 animate-pulse" />
                </div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
                  Gerador de Formulários
                </h1>
              </div>
              <div className="hidden md:flex items-center gap-2 ml-4">
                <span className="px-3 py-1 rounded-full bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold">
                  Profissional
                </span>
                <span className="px-3 py-1 rounded-full bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-semibold">
                  Alta Conversão
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <SavedFormsDrawer onLoadForm={setConfig}>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="relative overflow-hidden border-slate-700/50 bg-slate-800/30 text-slate-200 hover:bg-slate-800/50 hover:text-white hover:border-slate-600/50 transition-all duration-200 hover:shadow-lg hover:shadow-indigo-500/10"
                >
                  <FolderOpen className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline font-medium">Carregar</span>
                </Button>
              </SavedFormsDrawer>
              
              <SaveProjectDialog config={config}>
                <Button 
                  size="sm"
                  className="btn-primary bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600 text-white hover:from-indigo-500 hover:via-purple-500 hover:to-cyan-500 border-0 shadow-lg shadow-indigo-500/30 font-semibold"
                >
                  <Save className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">Salvar</span>
                </Button>
              </SaveProjectDialog>
            </div>
          </header>

          <div className="p-6">
            <div className="mx-auto max-w-7xl animate-slide-in">
              {renderContent()}
            </div>
          </div>
        </main>
      </div>
    </SidebarProvider>
  )
}
