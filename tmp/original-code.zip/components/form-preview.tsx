"use client"

import type React from "react"
import type { FormConfig } from "@/types/form-config"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useEffect, useState, useCallback } from "react"
import { countryConfigs } from "@/lib/country-configs"

interface FormPreviewProps {
  config: FormConfig
}

export function FormPreview({ config }: FormPreviewProps) {
  const [timeLeft, setTimeLeft] = useState({
    hours: config.countdownHours,
    minutes: config.countdownMinutes,
    seconds: config.countdownSeconds,
  })
  const [isHovered, setIsHovered] = useState(false)

  const updateCountdown = useCallback(() => {
    setTimeLeft((prev) => {
      let { hours, minutes, seconds } = prev

      if (seconds > 0) {
        seconds--
      } else if (minutes > 0) {
        minutes--
        seconds = 59
      } else if (hours > 0) {
        hours--
        minutes = 59
        seconds = 59
      }

      return { hours, minutes, seconds }
    })
  }, [])

  useEffect(() => {
    if (!config.showCountdown) return

    const timer = setInterval(updateCountdown, 1000)
    return () => clearInterval(timer)
  }, [config.showCountdown, updateCountdown])

  const formStyle: React.CSSProperties = {
    width: `${config.formWidth}px`,
    maxWidth: config.formMaxWidth,
    backgroundColor: config.formBackgroundColor || "white",
    border: "1px solid #e5e7eb",
  }

  const getButtonSizeClass = () => {
    switch (config.buttonSize) {
      case "small":
        return "py-2 px-4 text-sm"
      case "medium":
        return "py-3 px-6 text-base"
      case "large":
        return "py-4 px-8 text-lg"
      case "xl":
        return "py-5 px-10 text-xl"
      default:
        return "py-3 px-6 text-base"
    }
  }

  const getButtonWidthClass = () => {
    switch (config.buttonWidth) {
      case "full":
        return "w-full"
      case "auto":
        return "w-auto mx-auto"
      case "80%":
        return "w-4/5 mx-auto"
      case "60%":
        return "w-3/5 mx-auto"
      default:
        return "w-full"
    }
  }

  const getButtonBorderRadiusClass = () => {
    switch (config.buttonBorderRadius) {
      case "none":
        return "rounded-none"
      case "sm":
        return "rounded-sm"
      case "md":
        return "rounded-md"
      case "lg":
        return "rounded-lg"
      case "xl":
        return "rounded-xl"
      case "full":
        return "rounded-full"
      default:
        return "rounded-lg"
    }
  }

  const getFormHeightStyle = () => {
    if (typeof config.formHeight === "number") {
      return { minHeight: `${config.formHeight}px` }
    }
    return { minHeight: "auto" }
  }

  return (
  <Card className="h-fit bg-slate-900/40 border-slate-700/50 shadow-xl backdrop-blur-sm">
  <CardHeader className="p-6 border-b border-slate-700/50">
    <div className="flex items-center gap-2">
      <div className="h-1 w-8 rounded-full bg-gradient-to-r from-cyan-600 to-indigo-600" />
      <CardTitle className="text-xl font-semibold text-slate-100">Live Preview</CardTitle>
    </div>
    <p className="text-sm text-slate-400 mt-1">See how your form looks in real-time</p>
  </CardHeader>
  <CardContent>
        <div className="bg-gray-50 p-4 rounded">
          <div
            className="mx-auto bg-white rounded p-6 relative"
            style={{
              ...formStyle,
              ...getFormHeightStyle(),
            }}
          >
            {/* Header */}
            <div className="text-center mt-6 mb-4">
              <h2 className="text-lg font-semibold text-gray-900">{config.headline}</h2>
            </div>

            {config.showCountdown && (
              <div className="flex justify-center gap-1 mb-4">
                <div
                  className="px-2 py-1 rounded text-white font-bold text-center"
                  style={{ backgroundColor: config.countdownColor || config.primaryColor }}
                >
                  {String(timeLeft.hours).padStart(2, "0")}
                </div>
                <div
                  className="px-2 py-1 rounded text-white font-bold text-center"
                  style={{ backgroundColor: config.countdownColor || config.primaryColor }}
                >
                  {String(timeLeft.minutes).padStart(2, "0")}
                </div>
                <div
                  className="px-2 py-1 rounded text-white font-bold text-center"
                  style={{ backgroundColor: config.countdownColor || config.primaryColor }}
                >
                  {String(timeLeft.seconds).padStart(2, "0")}
                </div>
              </div>
            )}

            {config.showProductImage && config.productImagePosition === "top" && config.productImageUrl && (
              <div className="flex justify-center mb-4">
                <img
                  src={config.productImageUrl || "/placeholder.svg"}
                  alt="Product"
                  className="max-w-[200px] max-h-[200px] object-contain rounded"
                />
              </div>
            )}

            <div
              className={`mb-4 px-2 ${config.showProductImage && config.productImagePosition === "left" && config.productImageUrl ? "flex items-center gap-4" : ""}`}
            >
              {config.showProductImage && config.productImagePosition === "left" && config.productImageUrl && (
                <div className="flex-shrink-0">
                  <img
                    src={config.productImageUrl || "/placeholder.svg"}
                    alt="Product"
                    className="w-[100px] h-[100px] object-contain rounded"
                  />
                </div>
              )}
              <div className="flex justify-between items-center flex-1">
                <div className="text-left">
                  <div className="text-xs text-gray-500 mb-1">
                    {countryConfigs[config.country]?.language.oldPriceLabel || "Preţul vechi"}
                  </div>
                  <div className="text-gray-500 line-through text-base">
                    {config.oldPrice} {config.currency}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-gray-500 mb-1">
                    {countryConfigs[config.country]?.language.newPriceLabel || "Preţul nou"}
                  </div>
                  <div className="text-xl font-bold" style={{ color: config.primaryColor }}>
                    {config.newPrice} {config.currency}*
                  </div>
                </div>
              </div>
            </div>

            <div className="mb-4 space-y-1 text-sm text-gray-600">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span
                    dangerouslySetInnerHTML={{
                      __html: (
                        countryConfigs[config.country]?.language.socialProofPeople ||
                        "Acum pe site sunt {count} persoane"
                      ).replace("{count}", `<strong>${config.socialProofPeople || 29}</strong>`),
                    }}
                  />
                </div>
                <span className="text-green-500">● online</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>
                    <strong>{config.socialProofSales}</strong>{" "}
                    {countryConfigs[config.country]?.language.socialProofSales || "vânzări în ultima oră"}
                  </span>
                </div>
                <span className="text-green-500">● online</span>
              </div>
            </div>

            {/* Form */}
            <div className="space-y-3">
              <input
                type="text"
                placeholder={config.namePlaceholder}
                className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:border-blue-500"
              />
              <input
                type="tel"
                placeholder={config.phonePlaceholder}
                className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:border-blue-500"
              />
              <button
                type="button"
                className={`${getButtonWidthClass()} ${getButtonSizeClass()} ${getButtonBorderRadiusClass()} text-white font-bold uppercase`}
                style={{ backgroundColor: config.buttonColor }}
              >
                {config.ctaText}
              </button>
            </div>

            {/* Security Note */}
            <div className="text-center mt-4">
              <div className="text-sm text-gray-600">
                {config.belowButtonEmoji} <span>{config.belowButtonText}</span>
              </div>
              <div className="text-xs text-gray-500 mt-1">{config.disclaimerText}</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
