"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Download, Trash2, Code2, FileCode, CheckCircle2, AlertCircle, Eraser, Sparkles, Loader2 } from "lucide-react"
import { Separator } from "@/components/ui/separator"

export function FormReplacer() {
  const [originalHtml, setOriginalHtml] = useState("")
  const [replacementForm, setReplacementForm] = useState("")
  const [cleanedHtml, setCleanedHtml] = useState("")
  const [formsFound, setFormsFound] = useState(0)
  const [isRemoving, setIsRemoving] = useState(false)
  const [isInserting, setIsInserting] = useState(false)

  const identifyAndRemoveForms = () => {
    if (!originalHtml.trim()) {
      alert("Por favor, cole o HTML da página primeiro!")
      return
    }

    setIsRemoving(true)

    try {
      let cleaned = originalHtml
      let count = 0

      // Conta quantos forms existem
      const formMatches = cleaned.match(/<form[\s\S]*?<\/form>/gi)
      count = formMatches ? formMatches.length : 0

      // Remove todos os formulários
      cleaned = cleaned.replace(/<form[\s\S]*?<\/form>/gi, "")

      // Remove modais e popups comuns
      cleaned = cleaned.replace(
        /<div[^>]*class=["'][^"']*(modal|popup|overlay|lightbox|fancybox)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
        "",
      )

      // Remove overlays fixos
      cleaned = cleaned.replace(/<div[^>]*style=["'][^"']*position:\s*fixed[^"']*["'][^>]*>[\s\S]*?<\/div>/gi, "")

      setCleanedHtml(cleaned)
      setFormsFound(count)
      alert(`✅ ${count} formulário(s) removido(s) com sucesso!`)
    } catch (error) {
      console.error("[v0] Erro ao remover forms:", error)
      alert("❌ Erro ao processar. Tente novamente.")
    } finally {
      setIsRemoving(false)
    }
  }

  const insertFormWithAI = async () => {
    const htmlToUse = cleanedHtml || originalHtml

    if (!htmlToUse.trim()) {
      alert("Por favor, adicione o HTML da página primeiro!")
      return
    }

    if (!replacementForm.trim()) {
      alert("Por favor, cole o código do seu formulário!")
      return
    }

    setIsInserting(true)

    try {
      const response = await fetch("/api/ai/insert-form", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          pageHtml: htmlToUse,
          formHtml: replacementForm,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Erro ao inserir formulário")
      }

      const data = await response.json()
      setCleanedHtml(data.finalHtml)
      alert("✅ Formulário inserido com sucesso pela IA!")
    } catch (error) {
      console.error("[v0] Erro ao inserir com IA:", error)
      alert(error instanceof Error ? error.message : "❌ Erro ao processar com IA. Tente novamente.")
    } finally {
      setIsInserting(false)
    }
  }

  const downloadHtml = () => {
    if (!cleanedHtml) {
      alert("Processe o HTML primeiro!")
      return
    }

    const blob = new Blob([cleanedHtml], { type: "text/html" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "pagina-processada.html"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const clearAll = () => {
    setOriginalHtml("")
    setReplacementForm("")
    setCleanedHtml("")
    setFormsFound(0)
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <Card className="border-purple-500/30 bg-slate-900/40 backdrop-blur-xl">
        <CardHeader className="p-4 sm:p-6">
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg text-slate-100">
            <Code2 className="w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
            <span className="text-sm sm:text-base">Substituidor de Formulários</span>
          </CardTitle>
          <p className="text-xs sm:text-sm text-slate-400 mt-2">
            Remova formulários de páginas clonadas e insira o seu de forma inteligente com IA
          </p>
        </CardHeader>
      </Card>

      {/* Passo 1: HTML Original */}
      <Card className="h-fit bg-slate-900/40 backdrop-blur-xl border-slate-700/50">
        <CardHeader className="p-4 sm:p-6">
          <CardTitle className="flex items-center gap-2 text-sm sm:text-base text-slate-100">
            <FileCode className="w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
            Passo 1: Cole o HTML da Página
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
          <div className="space-y-2">
            <Label htmlFor="originalHtml" className="text-sm font-medium text-slate-300">
              HTML Completo da Página
            </Label>
            <Textarea
              id="originalHtml"
              value={originalHtml}
              onChange={(e) => setOriginalHtml(e.target.value)}
              placeholder="Cole aqui o código HTML completo da página que você quer clonar..."
              rows={8}
              className="font-mono text-xs sm:text-sm resize-none bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>

          <Button
            onClick={identifyAndRemoveForms}
            disabled={isRemoving || !originalHtml.trim()}
            className="w-full bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 text-white shadow-lg shadow-red-500/25"
          >
            {isRemoving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Removendo Formulários...
              </>
            ) : (
              <>
                <Eraser className="w-4 h-4 mr-2" />
                Identificar e Remover Formulários
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <Separator className="bg-slate-700/50" />

      {/* Passo 2: Seu Formulário */}
      <Card className="h-fit bg-slate-900/40 backdrop-blur-xl border-slate-700/50">
        <CardHeader className="p-4 sm:p-6">
          <CardTitle className="flex items-center gap-2 text-sm sm:text-base text-slate-100">
            <Code2 className="w-4 h-4 sm:w-5 sm:h-5 text-green-400" />
            Passo 2: Cole Seu Formulário
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
          <div className="space-y-2">
            <Label htmlFor="replacementForm" className="text-sm font-medium text-slate-300">
              Código do Seu Formulário (HTML)
            </Label>
            <Textarea
              id="replacementForm"
              value={replacementForm}
              onChange={(e) => setReplacementForm(e.target.value)}
              placeholder="Cole aqui o código HTML do seu formulário (gerado pela CashOnForm)..."
              rows={8}
              className="font-mono text-xs sm:text-sm resize-none bg-slate-800/50 border-slate-600/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>

          <Button
            onClick={insertFormWithAI}
            disabled={isInserting || !replacementForm.trim()}
            className="w-full bg-gradient-to-r from-purple-600 via-pink-600 to-purple-700 hover:from-purple-700 hover:via-pink-700 hover:to-purple-800 text-white shadow-lg shadow-purple-500/25"
          >
            {isInserting ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Inserindo com IA...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Inserir Formulário com IA
              </>
            )}
          </Button>

          <div className="flex items-start gap-2 text-xs text-slate-400">
            <AlertCircle className="w-3 h-3 mt-0.5 flex-shrink-0 text-purple-400" />
            <span>A IA ajustará seu formulário para encaixar perfeitamente na página sem quebrar o layout</span>
          </div>
        </CardContent>
      </Card>

      <Separator className="bg-slate-700/50" />

      {/* Resultado */}
      {cleanedHtml && (
        <Card className="border-green-500/30 bg-green-950/30 backdrop-blur-xl">
          <CardHeader className="p-4 sm:p-6">
            <CardTitle className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-sm sm:text-base">
              <span className="flex items-center gap-2 text-green-400">
                <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5" />
                HTML Processado
              </span>
              {formsFound > 0 && (
                <span className="text-xs font-normal text-green-300 bg-green-900/30 px-3 py-1 rounded-full border border-green-500/30">
                  {formsFound} formulário(s) removido(s)
                </span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
            <div className="space-y-2">
              <Label htmlFor="cleanedHtml" className="text-sm font-medium text-slate-300">
                Resultado Final
              </Label>
              <Textarea
                id="cleanedHtml"
                value={cleanedHtml}
                readOnly
                rows={8}
                className="font-mono text-xs sm:text-sm bg-slate-950 border-slate-700/50 text-slate-100 resize-none"
              />
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <Button
                onClick={downloadHtml}
                className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white shadow-lg shadow-green-500/25"
              >
                <Download className="w-4 h-4 mr-2" />
                Download HTML
              </Button>
              <Button
                onClick={clearAll}
                variant="outline"
                className="flex-1 bg-red-500/10 border-red-500/30 text-red-400 hover:bg-red-500/20 hover:text-red-300"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Limpar Tudo
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
