"use client"

import React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Save, Loader2 } from "lucide-react"
import type { FormConfig } from "@/types/form-config"

interface SaveProjectDialogProps {
  config: FormConfig
  onSaveSuccess?: () => void
  children?: React.ReactNode
}

export function SaveProjectDialog({ config, onSaveSuccess, children }: SaveProjectDialogProps) {
  const [projectName, setProjectName] = useState("")
  const [isOpen, setIsOpen] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState("")

  const handleSave = async () => {
    if (!projectName.trim()) {
      setError("Por favor, insira um nome para o projeto")
      return
    }

    setIsSaving(true)
    setError("")

    try {
      const response = await fetch("/api/forms/save", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          projectName: projectName.trim(),
          formConfig: config,
        }),
      })

      const result = await response.json()

      if (result.success) {
        setProjectName("")
        setIsOpen(false)
        onSaveSuccess?.()
      } else {
        setError(result.error || "Erro ao salvar projeto")
      }
    } catch (error) {
      console.error("Erro ao salvar projeto:", error)
      setError("Erro ao salvar projeto. Tente novamente.")
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children || (
          <Button className="bg-green-500 hover:bg-green-600 text-white">
            <Save className="w-4 h-4 mr-2" />
            Salvar Projeto
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Salvar Projeto</DialogTitle>
          <DialogDescription>Dê um nome ao seu projeto para salvá-lo e acessá-lo depois.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="project-name">Nome do Projeto</Label>
            <Input
              id="project-name"
              placeholder="Ex: Formulário de Vendas - Produto X"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !isSaving) {
                  handleSave()
                }
              }}
            />
            {error && <p className="text-sm text-red-500">{error}</p>}
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => setIsOpen(false)} disabled={isSaving}>
            Cancelar
          </Button>
          <Button type="button" onClick={handleSave} disabled={isSaving} className="bg-green-500 hover:bg-green-600">
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Salvando...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Salvar
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
