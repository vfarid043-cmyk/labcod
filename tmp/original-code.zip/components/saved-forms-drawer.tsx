"use client"

import React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { FolderOpen, Trash2, Download, Calendar } from 'lucide-react'
import type { FormConfig } from "@/types/form-config"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { generateFormHTML, generateThankYouPage, generateSendOrderPHP } from "@/lib/code-generators"

interface SavedForm {
  id: string
  project_name: string
  form_config: FormConfig
  created_at: string
  updated_at: string
}

interface SavedFormsDrawerProps {
  onLoadForm: (config: FormConfig) => void
  children?: React.ReactNode
}

export function SavedFormsDrawer({ onLoadForm, children }: SavedFormsDrawerProps) {
  const [savedForms, setSavedForms] = useState<SavedForm[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [isOpen, setIsOpen] = useState(false)

  const fetchSavedForms = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/forms/list")
      const result = await response.json()

      if (result.success) {
        setSavedForms(result.data)
      }
    } catch (error) {
      console.error("Erro ao buscar formulários:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (isOpen) {
      fetchSavedForms()
    }
  }, [isOpen])

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/forms/delete?id=${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setSavedForms(savedForms.filter((form) => form.id !== id))
        setDeleteId(null)
      }
    } catch (error) {
      console.error("Erro ao deletar formulário:", error)
    }
  }

  const handleLoad = (form: SavedForm) => {
    onLoadForm(form.form_config)
    setIsOpen(false)
  }

  const handleDownload = async (form: SavedForm) => {
    try {
      const config = form.form_config

      // Gerar os 3 arquivos
      const htmlContent = generateFormHTML(config)
      const thankYouContent = generateThankYouPage(config)
      const phpContent = generateSendOrderPHP(config)

      // Importar JSZip dinamicamente
      const JSZip = (await import("jszip")).default
      const zip = new JSZip()

      // Adicionar arquivos ao ZIP
      zip.file("index.html", htmlContent)
      zip.file("thank-you.html", thankYouContent)

      const phpFileName =
        config.platform === "ADCOMBO"
          ? "sendorder.php"
          : config.platform === "NETVORK" || config.platform === "WEBVORK" || config.platform === "TERRA_LEADS"
            ? "order.php"
            : config.platform === "LIMONAD"
              ? "lemon.php"
              : config.platform === "TRAFFIC_LIGHT"
                ? "send-lead.php"
                : "handler.php"
      zip.file(phpFileName, phpContent)

      // Gerar o ZIP
      const zipBlob = await zip.generateAsync({ type: "blob" })

      // Criar link de download
      const url = URL.createObjectURL(zipBlob)
      const link = document.createElement("a")
      link.href = url
      link.download = `${form.project_name.replace(/[^a-z0-9]/gi, "_").toLowerCase()}_form.zip`
      link.click()
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Erro ao gerar arquivos:", error)
      alert("Erro ao gerar os arquivos. Tente novamente.")
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
  <>
  <Sheet open={isOpen} onOpenChange={setIsOpen}>
  <SheetTrigger asChild>
  {children || (
    <Button
    variant="outline"
    className="bg-white/90 backdrop-blur-sm border-purple-200 hover:bg-purple-50 hover:border-purple-300"
    >
    <FolderOpen className="w-4 h-4 mr-2" />
    Meus Projetos
    </Button>
  )}
  </SheetTrigger>
        <SheetContent side="right" className="w-full sm:max-w-xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="text-2xl">Meus Projetos Salvos</SheetTitle>
            <SheetDescription>Gerencie seus formulários salvos. Carregue, baixe ou exclua projetos.</SheetDescription>
          </SheetHeader>

          <div className="mt-6 space-y-4">
            {isLoading ? (
              <div className="text-center py-8 text-gray-500">Carregando...</div>
            ) : savedForms.length === 0 ? (
              <div className="text-center py-8">
                <FolderOpen className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">Nenhum projeto salvo ainda.</p>
                <p className="text-sm text-gray-400 mt-2">
                  Salve seu primeiro projeto usando o botão "Salvar Projeto".
                </p>
              </div>
            ) : (
              savedForms.map((form) => (
                <Card key={form.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-lg">{form.project_name}</CardTitle>
                    <CardDescription className="flex items-center gap-2 text-xs">
                      <Calendar className="w-3 h-3" />
                      {formatDate(form.created_at)}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-2">
                      <Button onClick={() => handleLoad(form)} className="flex-1 bg-purple-500 hover:bg-purple-600">
                        Carregar
                      </Button>
                      <Button
                        onClick={() => handleDownload(form)}
                        variant="outline"
                        className="border-green-500 text-green-600 hover:bg-green-50"
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button
                        onClick={() => setDeleteId(form.id)}
                        variant="outline"
                        className="border-red-500 text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </SheetContent>
      </Sheet>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este projeto? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteId && handleDelete(deleteId)}
              className="bg-red-500 hover:bg-red-600"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
