import type { FormConfig } from "@/types/form-config"
import { countryConfigs } from "./country-configs"
import { generateCpagettiPHP as generateCpagettiPHPImport, generateCpagettiFormHTML } from "./cpagetti-generators"
import { generateShakesProFormHTML } from "./shakes-pro-generators"

function formatSocialProofPeople(text: string | undefined, count: number, fallback: string): string {
  if (!text) return fallback.replace("{count}", String(count))
  if (text.includes("{count}")) {
    return text.replace("{count}", String(count))
  }
  // Legacy format without {count} - append the count
  return `${text} ${count}`
}

function generateSimpleThankYouPage(config: FormConfig): string {
  return `<!doctype html>
<html lang="${config.country.toLowerCase()}">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Mulțumim pentru comandă!</title>
  <style>
    :root{
      --bg:${config.backgroundColor}; --card:#fff; --border:#e9ecef; --green:#28a745;
      --primary:${config.primaryColor}; --text-dark:#212529;
    }
    *{box-sizing:border-box}
    html,body{margin:0; height:100%;}
    body{background:var(--bg); color:var(--text-dark); font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif; display:flex; align-items:center; justify-content:center; min-height:100vh;}
    .container{max-width:400px; margin:20px; padding:40px 30px; background:var(--card); border-radius:12px; box-shadow:0 4px 20px rgba(0,0,0,0.1); text-align:center;}
    .success-icon{width:80px; height:80px; background:var(--green); border-radius:50%; margin:0 auto 30px; display:flex; align-items:center; justify-content:center; font-size:40px; color:white;}
    h1{margin:0 0 20px; font-size:24px; font-weight:600; color:var(--text-dark);}
    p{margin:0 0 15px; color:#6c757d; line-height:1.5;}
    .order-details{background:#f8f9fa; padding:20px; border-radius:8px; margin:20px 0; text-align:left;}
    .order-details h3{margin:0 0 15px; font-size:16px; color:var(--text-dark);}
    .detail-row{display:flex; justify-content:space-between; margin:8px 0; font-size:14px;}
    .detail-label{color:#6c757d;}
    .detail-value{font-weight:600; color:var(--text-dark);}
    .contact-info{margin-top:30px; padding-top:20px; border-top:1px solid #e9ecef; font-size:14px; color:#6c757d;}
  </style>
</head>
<body>
  <div class="container">
    <div class="success-icon">✓</div>
    <h1>Mulțumim pentru comandă!</h1>
    <p>Comanda dumneavoastră a fost înregistrată cu succes. Veți fi contactat în curând de către unul dintre reprezentanții noștri pentru confirmarea detaliilor.</p>
    
    <div class="order-details">
      <h3>Detalii comandă:</h3>
      <div class="detail-row">
        <span class="detail-label">Produs:</span>
        <span class="detail-value">${config.headline}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Preț:</span>
        <span class="detail-value">${config.newPrice} ${config.currency}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Reducere:</span>
        <span class="detail-value">-${config.discount}%</span>
      </div>
    </div>
    
    <p><strong>Important:</strong> Vă rugăm să vă păstrați telefonul la îndemână. Veți fi contactat în următoarele 24 de ore pentru confirmarea comenzii.</p>
    
    <div class="contact-info">
      <p><strong>Aveți întrebări?</strong><br>
      Contactați-ne la: support@${config.domain}</p>
    </div>
  </div>
</body>
</html>`
}

export function generateFormHTML(config: FormConfig): string {
  const countryConfig = countryConfigs[config.country]

  if (config.platform === "ADCOMBO") {
    return generateAdComboFormHTML(config, countryConfig)
  }

  if (config.platform === "NETVORK") {
    return generateNetvorkFormHTML(config, countryConfig)
  }

  if (config.platform === "WEBVORK") {
    return generateWebvorkFormHTML(config, countryConfig)
  }

  if (config.platform === "LIMONAD") {
    return generateLimonadFormHTML(config, countryConfig)
  }

  if (config.platform === "TRAFFIC_LIGHT") {
    return generateTrafficLightFormHTML(config, countryConfig)
  }

  if (config.platform === "TERRA_LEADS") {
    return generateTerraLeadsFormHTML(config, countryConfig)
  }

  // ADDED SHAKES_PRO PLATFORM SUPPORT
  if (config.platform === "SHAKES_PRO") {
    // Call Shakes.pro generator
    return generateShakesProFormHTML(config, countryConfig)
  }

  // Added Cpagetti platform support
  if (config.platform === "CPAGETTI") {
    return generateCpagettiFormHTML(config, countryConfig)
  }

  return generateDrCashFormHTML(config, countryConfig)
}

function generateAdComboFormHTML(config: FormConfig, countryConfig: any): string {
  // Função para obter classes de tamanho do botão
  const getButtonSizeStyles = () => {
    switch (config.buttonSize) {
      case "small":
        return "height: 40px; font-size: 14px; padding: 8px 16px;"
      case "medium":
        return "height: 50px; font-size: 16px; padding: 12px 24px;"
      case "large":
        return "height: 60px; font-size: 18px; padding: 16px 32px;"
      case "xl":
        return "height: 70px; font-size: 20px; padding: 20px 40px;"
      default:
        return "height: 50px; font-size: 16px; padding: 12px 24px;"
    }
  }

  // Função para obter largura do botão
  const getButtonWidthStyles = () => {
    switch (config.buttonWidth) {
      case "full":
        return "width: 100%;"
      case "auto":
        return "width: auto; margin: 0 auto; display: block;"
      case "80%":
        return "width: 80%; margin: 0 auto; display: block;"
      case "60%":
        return "width: 60%; margin: 0 auto; display: block;"
      default:
        return "width: 100%;"
    }
  }

  // Função para obter border radius do botão
  const getButtonBorderRadius = () => {
    switch (config.buttonBorderRadius) {
      case "none":
        return "border-radius: 0px;"
      case "sm":
        return "border-radius: 4px;"
      case "md":
        return "border-radius: 8px;"
      case "lg":
        return "border-radius: 12px;"
      case "xl":
        return "border-radius: 16px;"
      case "full":
        return "border-radius: 50px;"
      default:
        return "border-radius: 8px;"
    }
  }

  // Função para obter altura do formulário
  const getFormHeightStyles = () => {
    switch (config.formHeight) {
      case "compact":
        return "min-height: 500px;"
      case "comfortable":
        return "min-height: 600px;"
      case "spacious":
        return "min-height: 700px;"
      case "auto":
      default:
        return "min-height: auto;"
    }
  }

  const productImageHTML =
    config.showProductImage && config.productImageUrl
      ? config.productImagePosition === "top"
        ? `
      <div class="product-image-container" style="text-align: center; margin: 20px 0;">
        <img src="${config.productImageUrl}" alt="Produto" class="product-image" 
             style="max-width: 200px; height: auto; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);"
             onerror="this.style.display='none';">
      </div>`
        : ""
      : ""

  return `<!DOCTYPE html>
<html lang="${config.country?.toLowerCase() || "pt"}">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${config.headline || "Oferta Especial"}</title>
  <style>
    :root{
      --bg: ${config.backgroundColor || "#f8f9fa"};
      --card: ${config.formBackgroundColor || "#fff"};
      --border: #e9ecef;
      --green: #28a745;
      --green-d: #1e7e34;
      --primary: ${config.primaryColor || "#dc3545"};
      --button-bg: ${config.buttonColor || "#dc3545"};
      --button-bg-hover: color-mix(in srgb, ${config.buttonColor || "#dc3545"} 90%, black);
      --countdown-color: ${config.countdownColor || config.primaryColor || "#dc3545"};
      --muted: #6c757d;
      --input-bg: #fff;
      --input-bd: #ced4da;
      --text-dark: #212529;
      --text-light: #6c757d;
      --frame-max-width: ${config.formWidth || "380"}px;
      --frame-max-width-responsive: ${config.formMaxWidth || "95%"};
      --input-h: 44px;
      --btn-h: 50px;
      --fs-base: 15px;
    }
    
    * { box-sizing: border-box; }
    html, body { margin: 0; }
    
    body {
      background: var(--bg);
      color: var(--text-dark);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      font-size: var(--fs-base);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px 0;
    }
    
    .frame {
      width: 100%;
      max-width: var(--frame-max-width);
      margin: 16px auto;
      padding: 0;
      background: transparent;
      ${getFormHeightStyles()}
    }
    
    @media (max-width: ${Number.parseInt(config.formWidth || "380") + 40}px) {
      .frame {
        max-width: var(--frame-max-width-responsive);
        margin: 10px auto;
        padding: 0 10px;
      }
    }
    
    .card {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 20px;
      position: relative;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      ${getFormHeightStyles()}
    }
    
    .header {
      text-align: center;
      margin: 10px 0 20px;
      padding-top: 10px;
    }
    
    .header h2 {
      margin: 0;
      font-weight: 600;
      font-size: 22px;
      color: var(--text-dark);
      line-height: 1.3;
    }
    
    ${
      config.showCountdown
        ? `
    .timer {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 8px;
      margin: 15px 0 20px;
      font-weight: 600;
      font-size: 14px;
    }
    
    .timer-box {
      background: var(--countdown-color);
      color: #fff;
      padding: 8px 10px;
      border-radius: 6px;
      min-width: 35px;
      text-align: center;
      font-weight: 700;
      font-size: 16px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    }
    `
        : ""
    }
    
    /* Updated product image positioning to match preview exactly for ADCOMBO */
    .product-image-top {
      display: flex;
      justify-content: center;
      margin: 20px 0;
    }
    .product-image-top img {
      max-width: 200px;
      max-height: 200px;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    
    .price-container {
      margin: 20px 0;
      padding: 0 10px;
    }
    .price-container.with-side-image {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    .price-side-image {
      width: 100px;
      height: 100px;
      object-fit: contain;
      border-radius: 6px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      flex-shrink: 0;
    }
    .price-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex: 1;
    }
    
    .price-old .label,
    .price-new .label {
      color: var(--muted);
      font-size: 12px;
      margin-bottom: 4px;
      font-weight: 500;
    }
    
    .price-old .amount {
      color: var(--muted);
      text-decoration: line-through;
      font-size: 16px;
      font-weight: 500;
    }
    
    .price-new .amount {
      color: var(--primary);
      font-weight: 700;
      font-size: 24px;
    }
    
    .social-proof {
      margin: 20px 0;
      font-size: 12px;
      color: var(--muted);
    }
    
    .social-item {
      display: flex;
      align-items: center;
      margin: 6px 0;
    }
    
    .social-icon {
      width: 12px;
      height: 12px;
      margin-right: 8px;
      border-radius: 50%;
    }
    
    .icon-people { background: #007bff; }
    .icon-time { background: #28a745; }
    
    .social-number {
      color: var(--text-dark);
      font-weight: 600;
    }
    
    .online-dot {
      color: #28a745;
      margin-left: auto;
      animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
      0% { opacity: 1; }
      50% { opacity: 0.5; }
      100% { opacity: 1; }
    }
    
    .form-group {
      margin: 15px 0;
    }
    
    input[type="text"],
    input[type="tel"] {
      width: 100%;
      height: var(--input-h);
      padding: 12px 16px;
      background: var(--input-bg);
      border: 1px solid var(--input-bd);
      border-radius: 8px;
      font-size: 15px;
      outline: none;
      color: var(--text-dark);
      transition: all 0.3s ease;
    }
    
    input::placeholder {
      color: #adb5bd;
    }
    
    input:focus {
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(${
        config.primaryColor
          ? config.primaryColor
              .replace("#", "")
              .match(/.{2}/g)
              ?.map((hex) => Number.parseInt(hex, 16))
              .join(", ")
          : "220, 53, 69"
      }, 0.1);
    }
    
    /* Updated button styles for single button layout */
    .btn {
      border: none;
      background: var(--button-bg);
      color: #fff;
      font-weight: 700;
      cursor: pointer;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(0,0,0,0.2);
      margin: 20px 0 15px;
      ${getButtonBorderRadius()}
      ${getButtonSizeStyles()}
    }
    
    .btn:hover {
      background: var(--button-bg-hover);
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(0,0,0,0.3);
    }
    
    .btn:active {
      transform: translateY(0);
    }
    
    .btn:disabled {
      background: #ccc;
      cursor: not-allowed;
      transform: none;
    }
    
    .footer-note {
      text-align: center;
      margin: 15px 0 8px;
      font-size: 13px;
    }
    
    .footer-text {
      color: var(--muted);
      font-weight: 500;
    }
    
    .footer-disclaimer {
      color: var(--muted);
      font-size: 11px;
      text-align: center;
      margin-top: 10px;
      line-height: 1.4;
    }
    
    #statusMsg {
      min-height: 14px;
      color: var(--primary);
      font-weight: 600;
      font-size: 12px;
    }
    
    /* Animações suaves */
    .card {
      animation: slideInUp 0.6s ease-out;
    }
    
    @keyframes slideInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    /* Responsividade aprimorada */
    @media (max-width: 480px) {
      .card {
        padding: 16px;
      }
      
      .header h2 {
        font-size: 20px;
      }
      
      .price-new .amount {
        font-size: 22px;
      }
      
      .timer-box {
        padding: 6px 8px;
        font-size: 14px;
        min-width: 30px;
      }
      
      .price-container.with-side-image {
        gap: 10px;
      }
      
      .price-side-image {
        width: 80px;
        height: 80px;
      }
    }
  </style>
</head>
<body>
  <div class="frame">
    <div class="card">
      <div class="header">
        <h2>${config.headline || "TITULO OFERTA AQUI"}</h2>
      </div>
      
      ${
        config.showCountdown
          ? `
      <div class="timer">
        <span class="timer-box" id="hours">${String(config.countdownHours || 3).padStart(2, "0")}</span>
        <span class="timer-box" id="minutes">${String(config.countdownMinutes || 58).padStart(2, "0")}</span>
        <span class="timer-box" id="seconds">${String(config.countdownSeconds || 23).padStart(2, "0")}</span>
      </div>
      `
          : ""
      }
      
      <!-- Product image positioned exactly like preview -->
      ${
        config.showProductImage && config.productImageUrl && config.productImagePosition === "top"
          ? `
      <div class="product-image-top">
        <img src="${config.productImageUrl}" alt="Product" onerror="this.style.display='none';">
      </div>
      `
          : ""
      }
      
      <div class="price-container${config.showProductImage && config.productImageUrl && config.productImagePosition === "left" ? " with-side-image" : ""}">
        ${
          config.showProductImage && config.productImageUrl && config.productImagePosition === "left"
            ? `
        <img src="${config.productImageUrl}" alt="Product" class="price-side-image" onerror="this.style.display='none';">
        `
            : ""
        }
        <div class="price-content">
          <div class="price-old">
            <div class="label">${countryConfig?.language?.oldPriceLabel || config.oldPriceLabel || "Preţul vechi"}</div>
            <div class="amount">${config.oldPrice || "298"} ${config.currency || "RON"}</div>
          </div>
          <div class="price-new">
            <div class="label">${countryConfig?.language?.newPriceLabel || config.newPriceLabel || "Preţul nou"}</div>
            <div class="amount">${config.newPrice || "149"} ${config.currency || "RON"}*</div>
          </div>
        </div>
      </div>

      <div class="social-proof">
        <div class="social-item">
          <div class="social-icon icon-people"></div>
          <span>${(countryConfig?.language?.socialProofPeople || config.socialProofText || "Acum pe site sunt {count} persoane").replace("{count}", `<span class="social-number">${config.socialProofPeople || 29}</span>`)}</span>
          <span class="online-dot">● online</span>
        </div>
        <div class="social-item">
          <div class="social-icon icon-time"></div>
          <span><span class="social-number">${config.socialProofSales || 16}</span> ${countryConfig?.language?.socialProofSales || config.socialProofSalesText || "vânzări în ultima oră"}</span>
          <span class="online-dot">● online</span>
        </div>
      </div>

      <form action="https://${config.domain || "SEU DOMINIO AQUI"}/sendorder.php" method="post">
        <div class="form-group">
          <input name="name" type="text" placeholder="${config.namePlaceholder || "Numele"}" required/>
        </div>

        <div class="form-group">
          <input class="only_number" name="phone" type="text" placeholder="${config.phonePlaceholder || "+40 123 456 789"}" required/>
        </div>

        <input type='hidden' name='country_code' value='${config.country || "CODIGO PAIS AQUI"}'>
        <input type='hidden' name='offer_id' value='${config.offerId || "OFFER ID AQUI"}'>
        <input type='hidden' name='base_url' value='https://${config.domain || "SEU DOMINIO AQUI"}'>
        <input type='hidden' name='price' value='${config.newPrice || config.price || "PREÇO AQUI"}'>
        <input type='hidden' name='success_page' value='https://${config.domain || "SEU DOMINIO AQUI"}/success.html'>

        <button class="btn submit-form" type="submit" style="${getButtonWidthStyles()} ${getButtonSizeStyles()} ${getButtonBorderRadius()}">${config.ctaText || "COMANDAȚI CU REDUCERE"}</button>

        <div class="footer-note">
          ${config.belowButtonEmoji || "🔒"} <span class="footer-text">${config.belowButtonText || config.securityText || "Dados 100% seguros"}</span>
        </div>

        <div class="footer-disclaimer">
          ${config.disclaimerText || "* Funcționează asupra mărturiilor în limitele unui canal de distribuție"}
        </div>

        <div id="statusMsg" class="footer-disclaimer" style="margin-top:8px;"></div>
      </form>
    </div>
  </div>
  
  <script>
    ${
      config.showCountdown
        ? `
    function startCountdown() {
      const hoursEl = document.getElementById('hours');
      const minutesEl = document.getElementById('minutes');
      const secondsEl = document.getElementById('seconds');
      
      if (!hoursEl || !minutesEl || !secondsEl) return;
      
      let totalSeconds = ${config.countdownHours || 3} * 3600 + ${config.countdownMinutes || 58} * 60 + ${config.countdownSeconds || 23};
      
      function updateDisplay() {
        if (totalSeconds <= 0) {
          hoursEl.textContent = '00';
          minutesEl.textContent = '00';
          secondsEl.textContent = '00';
          return;
        }
        
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
        
        hoursEl.textContent = String(hours).padStart(2, '0');
        minutesEl.textContent = String(minutes).padStart(2, '0');
        secondsEl.textContent = String(seconds).padStart(2, '0');
        
        totalSeconds--;
        setTimeout(updateDisplay, 1000);
      }
      
      updateDisplay();
    }
    
    document.addEventListener('DOMContentLoaded', startCountdown);
    `
        : ""
    }
    
    // Validação e formatação do formulário
    document.querySelector('form').addEventListener('submit', function(e) {
      const nameInput = document.querySelector('input[name="name"]');
      const phoneInput = document.querySelector('input[name="phone"]');
      
      // Validação básica
      if (!nameInput.value.trim()) {
        e.preventDefault();
        alert('Por favor, preencha seu nome.');
        nameInput.focus();
        return;
      }
      
      if (!phoneInput.value.trim()) {
        e.preventDefault();
        alert('Por favor, preencha seu telefone.');
        phoneInput.focus();
        return;
      }
      
      // Feedback visual
      document.getElementById('statusMsg').textContent = 'Processando...';
      document.querySelectorAll('.btn').forEach(btn => btn.disabled = true);
    });
    
    // Formatação de telefone em tempo real
    document.querySelector('input[name="phone"]') && document.querySelector('input[name="phone"]').addEventListener('input', function(e) {
      let value = e.target.value.replace(/\\D/g, '');
      
      // Formatação baseada no país
      if ('${config.country}' === 'BR' && value.length <= 11) {
        if (value.length <= 10) {
          value = value.replace(/(\\d{2})(\\d{4})(\\d{4})/,'($1) $2-$3');
        } else {
          value = value.replace(/(\\d{2})(\\d{5})(\\d{4})/,'($1) $2-$3');
        }
      } else if ('${config.country}' === 'MX' && value.length <= 10) {
        value = value.replace(/(\\d{3})(\\d{3})(\\d{4})/,'$1 $2 $3');
      }
      
      e.target.value = value;
    });
  </script>
</body>
</html>`
}

function generateNetvorkFormHTML(config: FormConfig, countryConfig: any): string {
  const productImageHTML =
    config.showProductImage && config.productImageUrl
      ? config.productImagePosition === "top"
        ? `
      <div class="product-image-container" style="text-align: center; margin: 20px 0;">
        <img src="${config.productImageUrl}" alt="Produto" class="product-image" 
             style="max-width: 200px; height: auto; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);"
             onerror="this.style.display='none';">
      </div>`
        : ""
      : ""

  return `<!doctype html>
<html lang="${config.country?.toLowerCase() || "pt"}">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${config.headline || "TITULO OFERTA AQUI"}</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    :root{
      --bg:${config.backgroundColor || "#f8f9fa"}; --card:${config.formBackgroundColor || "#fff"}; --border:#e9ecef; --green:#28a745; 
      --red:${config.primaryColor || "#dc3545"}; --muted:#6c757d; --input-bg:#fff; --input-bd:#ced4da;
      --text-dark:#212529; --text-light:#6c757d;
    }
    *{box-sizing:border-box}
    html,body{margin:0}
    body{background:var(--bg); color:var(--text-dark); font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
    .frame{width:100%; max-width: ${config.formWidth || "380"}px; margin:20px auto; padding:0; background:transparent;}
    .card{background:var(--card); border:1px solid var(--border); border-radius:12px; padding:20px; position:relative; box-shadow:0 2px 10px rgba(0,0,0,0.1);}
    .header{text-align:center; margin:10px 0 20px; padding-top:10px;}
    .header h2{margin:0; font-weight:600; font-size:20px; color:var(--text-dark);}
    .timer{display:flex; justify-content:center; align-items:center; gap:8px; margin:15px 0 20px; font-weight:600; font-size:14px;}
    .timer-box{background:${config.countdownColor || "#dc3545"}; color:#fff; padding:8px 10px; border-radius:4px; min-width:35px; text-align:center; font-weight:700; font-size:16px;}
    
    /* Updated product image positioning to match preview for NETVORK */
    .product-image-top{display:flex; justify-content:center; margin:20px 0;}
    .product-image-top img{max-width:200px; max-height:200px; object-fit:contain; border-radius:8px; box-shadow:0 4px 15px rgba(0,0,0,0.1);}
    
    .price-container{margin:20px 0; padding:0 10px;}
    .price-container.with-side-image{display:flex; align-items:center; gap:15px;}
    .price-side-image{width:100px; height:100px; object-fit:contain; border-radius:6px; box-shadow:0 2px 8px rgba(0,0,0,0.1); flex-shrink:0;}
    .price-content{display:flex; justify-content:space-between; align-items:center; flex:1;}
    
    .price-old .label, .price-new .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-old .amount{color:var(--muted); text-decoration:line-through; font-size:16px;}
    .price-new .amount{color:var(--text-dark); font-weight:700; font-size:24px;}
    .social-proof{margin:20px 0; font-size:12px; color:var(--muted);}
    .social-item{display:flex; align-items:center; margin:4px 0;}
    .social-icon{width:12px; height:12px; margin-right:6px; border-radius:50%;}
    .icon-people{ background:#007bff; }
    .icon-time{ background:#28a745; }
    .social-number{ color:var(--text-dark); font-weight:600; }
    .online-dot{color:#28a745; margin-left:auto; animation: pulse 2s infinite;}
    @keyframes pulse {0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; }}
    .form-group{margin:15px 0;}
    input[type="text"], input[type="tel"], .form-select {width:100%; height:50px; padding:12px 16px; background:var(--input-bg); border:1px solid var(--input-bd); border-radius:6px; font-size:16px; outline:none; color:var(--muted);}
    input::placeholder{ color:#adb5bd; }
    input:focus, .form-select:focus { border-color:#80bdff; box-shadow:0 0 0 0.2rem rgba(0,123,255,.25); }
    .btn{width:100%; height:50px; margin:20px 0 15px; border:none; border-radius:25px; background:${config.buttonColor || "#dc3545"}; color:#fff; font-size:16px; font-weight:700; cursor:pointer; text-transform:uppercase; letter-spacing:0.5px;}
    .btn:hover{ background:color-mix(in srgb, ${config.buttonColor || "#dc3545"} 90%, black); }
    .btn:active{ transform:translateY(1px); }
    .footer-note{text-align:center; margin:15px 0 5px;}
    .footer-text{color:var(--muted); font-size:11px; line-height:1.4;}
    .footer-disclaimer{color:var(--muted); font-size:10px; text-align:center; margin-top:10px; line-height:1.3;}
    @media (max-width: 340px){.card{ padding:15px; }.price-container{ padding:0 5px; }.price-container.with-side-image{ gap:10px; }.price-side-image{ width:80px; height:80px; }}
  </style>
</head>
<body>

  <div class="frame">
    <div class="card">

      <div class="header">
        <h2>${config.headline || "TITULO OFERTA AQUI"}</h2>
      </div>
      
      ${
        config.showCountdown
          ? `
      <div class="timer">
        <span class="timer-box" id="hours">${String(config.countdownHours || 3).padStart(2, "0")}</span>
        <span class="timer-box" id="minutes">${String(config.countdownMinutes || 58).padStart(2, "0")}</span>
        <span class="timer-box" id="seconds">${String(config.countdownSeconds || 23).padStart(2, "0")}</span>
      </div>
      `
          : ""
      }
      
      <!-- Product image positioned exactly like preview -->
      ${
        config.showProductImage && config.productImageUrl && config.productImagePosition === "top"
          ? `
      <div class="product-image-top">
        <img src="${config.productImageUrl}" alt="Product" onerror="this.style.display='none';">
      </div>
      `
          : ""
      }
      
      <div class="price-container${config.showProductImage && config.productImageUrl && config.productImagePosition === "left" ? " with-side-image" : ""}">
        ${
          config.showProductImage && config.productImageUrl && config.productImagePosition === "left"
            ? `
        <img src="${config.productImageUrl}" alt="Product" class="price-side-image" onerror="this.style.display='none';">
        `
            : ""
        }
        <div class="price-content">
          <div class="price-old">
            <div class="label">${countryConfig?.language?.oldPriceLabel || "Preço Antigo"}</div>
            <div class="amount">${config.oldPrice || "298"} ${config.currency || "R$"}</div>
          </div>
          <div class="price-new">
            <div class="label">${countryConfig?.language?.newPriceLabel || "Preço Novo"}</div>
            <div class="amount">${config.newPrice || "149"} ${config.currency || "R$"}*</div>
          </div>
        </div>
      </div>

      <div class="social-proof">
        <div class="social-item">
          <div class="social-icon icon-people"></div>
          <span>${(countryConfig?.language?.socialProofPeople || config.socialProofText || "Pessoas online {count}").replace("{count}", `<span class="social-number">${config.socialProofPeople || 29}</span>`)}</span>
          <span class="online-dot">● online</span>
        </div>
        <div class="social-item">
          <div class="social-icon icon-time"></div>
          <span><span class="social-number">${config.socialProofSales || 16}</span> ${countryConfig?.language?.socialProofSales || config.socialProofSalesText || "vendas na última hora"}</span>
          <span class="online-dot">● online</span>
        </div>
      </div>

      <form action="https://${config.domain || "SEU-DOMINIO-AQUI"}/order.php" method="POST" autocomplete="on">
        
        <div class="form-group">
          <input required type="text" name="name" placeholder="${config.namePlaceholder || "Seu nome completo"}" />
        </div>

        <div class="form-group">
          <input type="tel" name="phone" placeholder="${config.phonePlaceholder || "+40 123 456 789"}" minlength="5" required />
        </div>
        
        <div class="form-group">
          <select class="form-select" name="country" required>
            <option value="${config.country || "BR"}" selected>${countryConfig?.name || "Brasil"}</option>
            <option value="US">🇺🇸 United States</option>
          </select>
        </div>

        <input type="hidden" name="offer_id" value="${config.offerId || "OFFER_ID_AQUI"}">
        <input type="hidden" name="lang" value="${config.country?.toLowerCase() || "pt"}">
        <input type="hidden" name="utm_source" value="">
        <input type="hidden" name="utm_medium" value="">
        <input type="hidden" name="utm_campaign" value="DOR">
        <input type="hidden" name="utm_content" value="Google">
        <input type="hidden" name="utm_term" value="">
        
        <button type="submit" class="btn">
          <i class="fas fa-check-circle"></i> ${config.ctaText || "QUERO APROVEITAR"}
        </button>

        <div class="footer-note">
          ${config.belowButtonEmoji || "🔒"} <span class="footer-text">${config.belowButtonText || config.securityText || "Dados 100% seguros"}</span>
        </div>

        <div class="footer-disclaimer">
          ${config.disclaimerText || "Oferta por tempo limitado"}
        </div>

        <div id="statusMsg" class="footer-disclaimer" style="margin-top:8px;"></div>
      </form>
    </div>
  </div>
  
  <script>
    document.addEventListener('DOMContentLoaded', function() {
        const card = document.querySelector('.card');
        card.style.opacity = '0';
        card.style.transform = 'translateY(15px)';
        setTimeout(() => {
            card.style.transition = 'all 0.4s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100);

        const inputs = document.querySelectorAll('input[required], select[required]');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                if (this.value.trim() === '') {
                    this.style.borderColor = '#f44336';
                } else {
                    this.style.borderColor = '#80bdff';
                }
            });
        });

        ${
          config.showCountdown
            ? `
        (function startCountdown(){
            const hoursEl = document.getElementById('hours'), minutesEl = document.getElementById('minutes'), secondsEl = document.getElementById('seconds');
            if (!hoursEl || !minutesEl || !secondsEl) return;
            let totalSeconds = ${config.countdownHours || 3} * 3600 + ${config.countdownMinutes || 58} * 60 + ${config.countdownSeconds || 23};
            function updateDisplay() {
                if (totalSeconds <= 0) {
                    hoursEl.textContent = '00';
                    minutesEl.textContent = '00';
                    secondsEl.textContent = '00';
                    return;
                }
                const hours = Math.floor(totalSeconds / 3600);
                const minutes = Math.floor((totalSeconds % 3600) / 60);
                const seconds = totalSeconds % 60;
                hoursEl.textContent = String(hours).padStart(2, '0');
                minutesEl.textContent = String(minutes).padStart(2, '0');
                secondsEl.textContent = String(seconds).padStart(2, '0');
                totalSeconds--;
                setTimeout(updateDisplay, 1000);
            }
            updateDisplay();
        })();
        `
            : ""
        }
    });
  </script>
</body>
</html>`
}

function generateWebvorkFormHTML(config: FormConfig, countryConfig: any): string {
  const thankYouTranslations = countryConfig?.language?.thankYouPage

  return `<!doctype html>
<html lang="${config.country?.toLowerCase() || "pt"}">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${config.headline || "Oferta Especial"}</title>
  <style>
    :root{--bg:${config.backgroundColor || "#f8f9fa"}; --card:${config.formBackgroundColor || "#fff"}; --border:#e9ecef; --green:#28a745; --green-d:#1e7e34;--red:${config.primaryColor || "#dc3545"};--red-d:color-mix(in srgb, ${config.primaryColor || "#dc3545"} 90%, black); --muted:#6c757d; --input-bg:#fff; --input-bd:#ced4da;--text-dark:#212529;--text-light:#6c757d;}
    *{box-sizing:border-box}
    body{background:var(--bg); color:var(--text-dark); font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
    .frame{width:100%; max-width:${config.formWidth || "380"}px; margin:20px auto; padding:0; background:transparent;}
    .card{background:var(--card); border:1px solid var(--border); border-radius:12px; padding:20px; position:relative; box-shadow:0 2px 10px rgba(0,0,0,0.1);}
    .header{text-align:center; margin:10px 0 20px; padding-top:10px;}
    .header h2{margin:0; font-weight:600; font-size:20px; color:var(--text-dark);}
    .timer{display:flex; justify-content:center; align-items:center; gap:8px; margin:15px 0 20px; font-weight:600; font-size:14px;}
    .timer-box{background:${config.countdownColor || config.primaryColor || "#dc3545"}; color:#fff; padding:8px 10px; border-radius:4px; min-width:35px; text-align:center; font-weight:700; font-size:16px;}
    .price-container{margin:20px 0; padding:0 10px;}
    .price-container.with-side-image{display:flex; align-items:center; gap:15px;}
    .price-side-image{width:100px; height:100px; object-fit:contain; border-radius:6px; box-shadow:0 2px 8px rgba(0,0,0,0.1); flex-shrink:0;}
    .price-content{display:flex; justify-content:space-between; align-items:center; flex:1;}
    .price-old .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-old .amount{color:var(--muted); text-decoration:line-through; font-size:16px;}
    .price-new .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-new .amount{color:var(--text-dark); font-weight:700; font-size:24px;}
    .social-proof{margin:20px 0; font-size:12px; color:var(--muted);}
    .social-item{display:flex; align-items:center; margin:4px 0;}
    .social-icon{width:12px; height:12px; margin-right:6px; border-radius:50%;}
    .icon-people{background:#007bff;}
    .icon-time{background:#28a745;}
    .social-number{color:var(--text-dark); font-weight:600;}
    .online-dot{color:#28a745; margin-left:auto; animation:pulse 2s infinite;}
    @keyframes pulse{0%{opacity:1;}50%{opacity:0.5;}100%{opacity:1;}}
    .form-group{margin:15px 0;}
    input[type="text"],input[type="tel"]{width:100%; height:50px; padding:12px 16px; background:var(--input-bg); border:1px solid var(--input-bd); border-radius:6px; font-size:16px; outline:none; color:var(--muted);}
    input::placeholder{color:#adb5bd;}
    input:focus{border-color:#80bdff; box-shadow:0 0 0 0.2rem rgba(0,123,255,.25);}
    .btn{width:100%; height:50px; margin:20px 0 15px; border:none; border-radius:25px; background:${config.buttonColor || "#dc3545"}; color:#fff; font-size:16px; font-weight:700; cursor:pointer; text-transform:uppercase; letter-spacing:0.5px;}
    .btn:hover{background:color-mix(in srgb, ${config.buttonColor || "#dc3545"} 90%, black);}
    .btn:active{transform:translateY(1px);}
    .footer-note{text-align:center; margin:15px 0 5px;}
    .footer-text{color:var(--muted); font-size:11px; line-height:1.4;}
    .footer-disclaimer{color:var(--muted); font-size:10px; text-align:center; margin-top:10px; line-height:1.3;}
    .product-image-top{display:flex; justify-content:center; margin:20px 0;}
    .product-image-top img{max-width:200px; max-height:200px; object-fit:contain; border-radius:8px; box-shadow:0 4px 15px rgba(0,0,0,0.1);}
    @media(max-width:340px){.card{padding:15px;}.price-container{padding:0 5px;}}
  </style>
</head>
<body>

  <div class="frame">
    <div class="card">
      <div class="header">
        <h2>${config.headline || "Oferta Especial"}</h2>
      </div>
      ${
        config.showCountdown
          ? `
      <div class="timer">
        <span class="timer-box" id="hours">${String(config.countdownHours || 3).padStart(2, "0")}</span>
        <span class="timer-box" id="minutes">${String(config.countdownMinutes || 58).padStart(2, "0")}</span>
        <span class="timer-box" id="seconds">${String(config.countdownSeconds || 23).padStart(2, "0")}</span>
      </div>
      `
          : ""
      }
      ${
        config.showProductImage && config.productImageUrl && config.productImagePosition === "top"
          ? `
      <div class="product-image-top">
        <img src="${config.productImageUrl}" alt="Product" onerror="this.style.display='none';">
      </div>
      `
          : ""
      }
      <div class="price-container${config.showProductImage && config.productImageUrl && config.productImagePosition === "left" ? " with-side-image" : ""}">
        ${
          config.showProductImage && config.productImageUrl && config.productImagePosition === "left"
            ? `
        <img src="${config.productImageUrl}" alt="Product" class="price-side-image" onerror="this.style.display='none';">
        `
            : ""
        }
        <div class="price-content">
          <div class="price-old">
            <div class="label">${countryConfig?.language?.oldPriceLabel || thankYouTranslations?.priceLabel || "Preço Antigo"}</div>
            <div class="amount">${config.oldPrice || "298"} ${config.currency || "R$"}</div>
          </div>
          <div class="price-new">
            <div class="label">${countryConfig?.language?.newPriceLabel || thankYouTranslations?.priceLabel || "Preço Novo"}</div>
            <div class="amount">${config.newPrice || "149"} ${config.currency || "R$"}*</div>
          </div>
        </div>
      </div>
      <div class="social-proof">
        <div class="social-item">
          <div class="social-icon icon-people"></div>
          <span>${(countryConfig?.language?.socialProofPeople || config.socialProofText || "Pessoas online {count}").replace("{count}", `<span class="social-number">${config.socialProofPeople || 29}</span>`)}</span>
          <span class="online-dot">● online</span>
        </div>
        <div class="social-item">
          <div class="social-icon icon-time"></div>
          <span><span class="social-number">${config.socialProofSales || 16}</span> ${countryConfig?.language?.socialProofSales || config.socialProofSalesText || "vendas na última hora"}</span>
          <span class="online-dot">● online</span>
        </div>
      </div>
      
      <form class="orderForm" id="orderForm" action="/lemon.php" method="post">
        
        <div class="form-group">
          <input id="name" name="name" type="text" placeholder="${config.namePlaceholder || "Seu nome"}" required>
        </div>
        <div class="form-group">
          <input id="phone" name="phone" type="tel" inputmode="tel" placeholder="${config.phonePlaceholder || "+40 123 456 789"}" required>
        </div>
        
        <input type="hidden" name="utmcampaign" value="">
        <input type="hidden" name="utmcontent" value="">
        <input type="hidden" name="utmmedium" value="">
        <input type="hidden" name="utmsource" value="">
        <input type="hidden" name="utmterm" value="">
        <input type="hidden" name="clickid" value="">
        <input type="hidden" name="fbpxl" value="">
        
        <button type="submit" class="btn" id="submitBtn">${config.ctaText || "QUERO APROVEITAR"}</button>

        <div class="footer-note">
          ${config.belowButtonEmoji || "🔒"} <span class="footer-text">${config.belowButtonText || config.securityText || "Dados 100% seguros"}</span>
        </div>
        <div class="footer-disclaimer">
          ${config.disclaimerText || "Oferta por tempo limitado"}
        </div>
      </form>
    </div>
  </div>
  
  <script>
    // Script para preencher os campos ocultos da Limonad a partir da URL
    (function fillSubsFromURL(){
      const url = new URL(window.location.href);
      ['utmcampaign', 'utmcontent', 'utmmedium', 'utmsource', 'utmterm', 'clickid', 'fbpxl'].forEach(k=>{
        const v = url.searchParams.get(k);
        if (v) {
          const el = document.querySelector(\`input[name="\${k}"]\`);
          if (el) el.value = v;
        }
      });
    })();

    ${
      config.showCountdown
        ? `// Script do contador regressivo
    (function startCountdown(){
      const hoursEl = document.getElementById('hours');
      const minutesEl = document.getElementById('minutes');
      const secondsEl = document.getElementById('seconds');
      
      let remaining = ${config.countdownHours || 3}*3600 + ${config.countdownMinutes || 58}*60 + ${config.countdownSeconds || 23}; 
      
      const tick = () => {
        const h = Math.floor(remaining/3600);
        const m = Math.floor((remaining%3600)/60);
        const s = remaining%60;
        
        hoursEl.textContent = String(h).padStart(2,'0');
        minutesEl.textContent = String(m).padStart(2,'0');
        secondsEl.textContent = String(s).padStart(2,'0');
        
        if (remaining<=0){ return; }
        remaining--; 
        setTimeout(tick,1000);
      };
      tick();
    })();`
        : ""
    }
  </script>
</body>
</html>`
}

function generateLimonadFormHTML(config: FormConfig, countryConfig: any): string {
  const translations = countryConfig?.language || {}

  return `<!doctype html>
<html lang="${config.country?.toLowerCase() || "pt"}">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${config.headline || "Oferta Especial"}</title>
  
  <style>
    /* Estilos do formulário Limonad */
    :root{--bg:${config.backgroundColor || "#f8f9fa"}; --card:${config.formBackgroundColor || "#fff"}; --border:#e9ecef; --green:#28a745; --primary:${config.primaryColor || "#dc3545"}; --muted:#6c757d; --input-bg:#fff; --input-bd:#ced4da; --text-dark:#212529; --text-light:#6c757d;}
    *{box-sizing:border-box}
    html,body{margin:0}
    body{background:var(--bg); color:var(--text-dark); font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
    .frame{width:100%; max-width: ${config.formWidth || "380"}px; margin:20px auto; padding:0; background:transparent;}
    .card{background:var(--card); border:1px solid var(--border); border-radius:12px; padding:20px; position:relative; box-shadow:0 2px 10px rgba(0,0,0,0.1);}
    .header{text-align:center; margin:10px 0 20px; padding-top:10px;}
    .header h2{margin:0; font-weight:600; font-size:20px; color:var(--text-dark);}
    .timer{display:flex; justify-content:center; align-items:center; gap:8px; margin:15px 0 20px; font-weight:600; font-size:14px;}
    .timer-box{background:${config.countdownColor || config.primaryColor || "#dc3545"}; color:#fff; padding:8px 10px; border-radius:4px; min-width:35px; text-align:center; font-weight:700; font-size:16px;}
    .price-container{margin:20px 0; padding:0 10px;}
    .price-content{display:flex; justify-content:space-between; align-items:center; flex:1;}
    .price-old{text-align:left;}
    .price-old .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-old .amount{color:var(--muted); text-decoration:line-through; font-size:16px;}
    .price-new{text-align:right;}
    .price-new .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-new .amount{color:var(--text-dark); font-weight:700; font-size:24px;}
    .social-proof{margin:20px 0; font-size:12px; color:var(--muted);}
    .social-item{display:flex; align-items:center; margin:4px 0;}
    .social-icon{width:12px; height:12px; margin-right:6px; border-radius:50%;}
    .icon-people{ background:#007bff; }
    .icon-time{ background:#28a745; }
    .social-number{ color:var(--text-dark); font-weight:600; }
    .online-dot{color:#28a745; margin-left:auto; animation: pulse 2s infinite;}
    @keyframes pulse {0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; }}
    .form-group{margin:15px 0;}
    input[type="text"], input[type="tel"]{width:100%; height:50px; padding:12px 16px; background:var(--input-bg); border:1px solid var(--input-bd); border-radius:6px; font-size:16px; outline:none; color:var(--muted);}
    input::placeholder{ color:#adb5bd; }
    input:focus{ border-color:#80bdff; box-shadow:0 0 0 0.2rem rgba(0,123,255,.25); }
    .btn{width:100%; height:50px; margin:20px 0 15px; border:none; border-radius:25px; background:${config.buttonColor || "#dc3545"}; color:#fff; font-size:16px; font-weight:700; cursor:pointer; text-transform:uppercase; letter-spacing:0.5px;}
    .btn:hover{ background:color-mix(in srgb, ${config.buttonColor || "#dc3545"} 90%, black); }
    .btn:active{ transform:translateY(1px); }
    .footer-note{text-align:center; margin:15px 0 5px;}
    .footer-text{color:var(--muted); font-size:11px; line-height:1.4;}
    .footer-disclaimer{color:var(--muted); font-size:10px; text-align:center; margin-top:10px; line-height:1.3;}
    @media (max-width: 340px){.card{ padding:15px; } .price-container{ padding:0 5px; }}
  </style>
</head>
<body>

  <div class="frame">
    <div class="card">

      <div class="header">
        <h2>${config.headline || "Oferta Especial"}</h2>
      </div>

      ${
        config.showCountdown
          ? `<div class="timer">
        <span class="timer-box" id="hours">${String(config.countdownHours || 3).padStart(2, "0")}</span>
        <span class="timer-box" id="minutes">${String(config.countdownMinutes || 58).padStart(2, "0")}</span>
        <span class="timer-box" id="seconds">${String(config.countdownSeconds || 23).padStart(2, "0")}</span>
      </div>`
          : ""
      }
      
      <div class="price-container">
        <div class="price-content">
          <div class="price-old">
            <div class="label">${translations.oldPriceLabel || "Preço Normal"}</div>
            <div class="amount">${config.oldPrice || "298"} ${config.currency || "R$"}</div>
          </div>
          <div class="price-new">
            <div class="label">${translations.newPriceLabel || "Hoje Apenas"}</div>
            <div class="amount">${config.newPrice || "149"} ${config.currency || "R$"}*</div>
          </div>
        </div>
      </div>

      <div class="social-proof">
        <div class="social-item">
          <div class="social-icon icon-people"></div>
          <span>${(countryConfig?.language?.socialProofPeople || config.socialProofText || "Pessoas online {count}").replace("{count}", `<span class="social-number">${config.socialProofPeople || 47}</span>`)}</span>
          <span class="online-dot">● online</span>
        </div>
        <div class="social-item">
          <div class="social-icon icon-time"></div>
          <span>${translations.socialProofSales || "Na última hora compraram"} <span class="social-number">${config.socialProofSales || 12}</span></span>
          <span class="online-dot">● online</span>
        </div>
      </div>

      <form class="orderForm" id="form-limonad" action="/lemon.php" method="post">
        
        <div class="form-group">
          <input id="name" name="name" type="text" placeholder="${config.namePlaceholder || "Nome completo"}" required>
        </div>

        <div class="form-group">
          <input id="phone" name="phone" type="tel" inputmode="tel" placeholder="${config.phonePlaceholder || "+55 (11) 99999-9999"}" required>
        </div>

        <input type="hidden" name="utmcampaign" value="">
        <input type="hidden" name="utmcontent" value="">
        <input type="hidden" name="utmmedium" value="">
        <input type="hidden" name="utmsource" value="">
        <input type="hidden" name="utmterm" value="">
        <input type="hidden" name="clickid" value="">
        <input type="hidden" name="fbpxl" value="">

        <button type="submit" class="btn" id="submitBtn">${config.ctaText || "PEDIR AGORA"}</button>

        <div class="footer-note">
          ${config.belowButtonEmoji || "🔒"} <span class="footer-text">${config.securityText || "Seus dados estão 100% seguros"}</span>
        </div>

        <div class="footer-disclaimer">
          ${config.disclaimerText || "*Promoção válida apenas hoje"}
        </div>
      </form>
    </div>
  </div>

  <script>
    // Script para preencher os campos ocultos da Limonad a partir da URL
    (function fillSubsFromURL(){
      const url = new URL(window.location.href);
      ['utmcampaign', 'utmcontent', 'utmmedium', 'utmsource', 'utmterm', 'clickid', 'fbpxl'].forEach(k=>{
        const v = url.searchParams.get(k);
        if (v) {
          const el = document.querySelector(\`input[name="\${k}"]\`);
          if (el) el.value = v;
        }
      });
    })();

    ${
      config.showCountdown
        ? `// Script do contador regressivo
    (function startCountdown(){
      const hoursEl = document.getElementById('hours');
      const minutesEl = document.getElementById('minutes');
      const secondsEl = document.getElementById('seconds');
      
      let remaining = ${config.countdownHours || 3}*3600 + ${config.countdownMinutes || 58}*60 + ${config.countdownSeconds || 23}; 
      
      const tick = () => {
        const h = Math.floor(remaining/3600);
        const m = Math.floor((remaining%3600)/60);
        const s = remaining%60;
        
        hoursEl.textContent = String(h).padStart(2,'0');
        minutesEl.textContent = String(m).padStart(2,'0');
        secondsEl.textContent = String(s).padStart(2,'0');
        
        if (remaining<=0){ return; }
        remaining--; 
        setTimeout(tick,1000);
      };
      tick();
    })();`
        : ""
    }
  </script>
</body>
</html>`
}

function generateTrafficLightFormHTML(config: FormConfig, countryConfig: any): string {
  const translations = countryConfig?.language || {}

  return `<!doctype html>
<html lang="${config.country?.toLowerCase() || "pt"}">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${config.headline || "Oferta Especial"}</title>
  <style>
    /* Estilos do formulário Dr.Cash */
    :root{--bg:${config.backgroundColor || "#f8f9fa"}; --card:${config.formBackgroundColor || "#fff"}; --border:#e9ecef; --green:#28a745; --primary:${config.primaryColor || "#dc3545"}; --muted:#6c757d; --input-bg:#fff; --input-bd:#ced4da; --text-dark:#212529; --text-light:#6c757d;}
    *{box-sizing:border-box}
    html,body{margin:0}
    body{background:var(--bg); color:var(--text-dark); font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
    .frame{width:100%; max-width: ${config.formWidth || "380"}px; margin:20px auto; padding:0; background:transparent;}
    .card{background:var(--card); border:1px solid var(--border); border-radius:12px; padding:20px; position:relative; box-shadow:0 2px 10px rgba(0,0,0,0.1);}
    .header{text-align:center; margin:10px 0 20px; padding-top:10px;}
    .header h2{margin:0; font-weight:600; font-size:20px; color:var(--text-dark);}
    .timer{display:flex; justify-content:center; align-items:center; gap:8px; margin:15px 0 20px; font-weight:600; font-size:14px;}
    .timer-box{background:${config.primaryColor || "#dc3545"}; color:#fff; padding:8px 10px; border-radius:4px; min-width:35px; text-align:center; font-weight:700; font-size:16px;}
    .price-container{margin:20px 0; padding:0 10px;}
    .price-content{display:flex; justify-content:space-between; align-items:center; flex:1;}
    .price-old{text-align:left;}
    .price-old .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-old .amount{color:var(--muted); text-decoration:line-through; font-size:16px;}
    .price-new{text-align:right;}
    .price-new .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-new .amount{color:var(--text-dark); font-weight:700; font-size:24px;}
    .social-proof{margin:20px 0; font-size:12px; color:var(--muted);}
    .social-item{display:flex; align-items:center; margin:4px 0;}
    .social-icon{width:12px; height:12px; margin-right:6px; border-radius:50%;}
    .icon-people{ background:#007bff; }
    .icon-time{ background:#28a745; }
    .social-number{ color:var(--text-dark); font-weight:600; }
    .online-dot{color:#28a745; margin-left:auto; animation: pulse 2s infinite;}
    @keyframes pulse {0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; }}
    .form-group{margin:15px 0;}
    input[type="text"], input[type="tel"]{width:100%; height:50px; padding:12px 16px; background:var(--input-bg); border:1px solid var(--input-bd); border-radius:6px; font-size:16px; outline:none; color:var(--muted);}
    input::placeholder{ color:#adb5bd; }
    input:focus{ border-color:#80bdff; box-shadow:0 0 0 0.2rem rgba(0,123,255,.25); }
    .btn{width:100%; height:50px; margin:20px 0 15px; border:none; border-radius:25px; background:${config.buttonColor || "#dc3545"}; color:#fff; font-size:16px; font-weight:700; cursor:pointer; text-transform:uppercase; letter-spacing:0.5px;}
    .btn:hover{ background:color-mix(in srgb, ${config.buttonColor || "#dc3545"} 90%, black); }
    .btn:active{ transform:translateY(1px); }
    .footer-note{text-align:center; margin:15px 0 5px;}
    .footer-text{color:var(--muted); font-size:11px; line-height:1.4;}
    .footer-disclaimer{color:var(--muted); font-size:10px; text-align:center; margin-top:10px; line-height:1.3;}
    @media (max-width: 340px){.card{ padding:15px; } .price-container{ padding:0 5px; }}
  </style>
</head>
<body>

  <div class="frame">
    <div class="card">

      <div class="header"><h2>${config.headline || "Oferta Especial"}</h2></div>
      ${
        config.showCountdown
          ? `<div class="timer">
        <span class="timer-box" id="hours">${String(config.countdownHours || 3).padStart(2, "0")}</span>
        <span class="timer-box" id="minutes">${String(config.countdownMinutes || 58).padStart(2, "0")}</span>
        <span class="timer-box" id="seconds">${String(config.countdownSeconds || 23).padStart(2, "0")}</span>
      </div>`
          : ""
      }
      <div class="price-container">
        <div class="price-content">
          <div class="price-old">
            <div class="label">${translations.oldPriceLabel || "Prețul vechi"}</div>
            <div class="amount">${config.oldPrice || "298"} ${config.currency || "RON"}</div>
          </div>
          <div class="price-new">
            <div class="label">${translations.newPriceLabel || "Prețul nou"}</div>
            <div class="amount">${config.newPrice || "149"} ${config.currency || "RON"}*</div>
          </div>
        </div>
      </div>
      <div class="social-proof">
        <div class="social-item">
          <div class="social-icon icon-people"></div>
          <span>${(countryConfig?.language?.socialProofPeople || config.socialProofText || "Acum pe site sunt {count} persoane").replace("{count}", `<span class="social-number">${config.socialProofPeople || 29}</span>`)}</span>
          <span class="online-dot">● online</span>
        </div>
        <div class="social-item">
          <div class="social-icon icon-time"></div>
          <span>${config.socialProofSales} ${countryConfig?.language?.socialProofSales || config.socialProofSalesText || "vânzări în ultima oră"}</span>
          <span class="online-dot">● online</span>
        </div>
      </div>

      <form class="orderForm" id="orderForm" action="https://${config.domain || "seudominio.com"}/send-lead.php" method="POST">
        
        <div class="form-group">
          <input id="name" name="name" type="text" placeholder="${config.namePlaceholder || "Nume complet"}" required maxlength="100">
        </div>

        <div class="form-group">
          <input id="phone" name="phone" type="tel" inputmode="tel" placeholder="${config.phonePlaceholder || "+55 (11) 99999-9999"}" required maxlength="20">
        </div>

        <input type="hidden" name="offer_id" value="${config.offerId || "1"}">
        
        <button type="submit" class="btn" id="submitBtn">${config.ctaText || "PEDIR AGORA"}</button>

        <div class="footer-note">${config.belowButtonEmoji || "🔒"} <span class="footer-text">${config.securityText || "Datele dvs. sunt protejate!"}</span></div>
        <div class="footer-disclaimer">${config.disclaimerText || "* Funcționează asupra mărturiilor în limitele unui canal de distribuție"}</div>
      </form>
    </div>
  </div>

  ${
    config.showCountdown
      ? `<script>
    // Script do contador regressivo (do design Dr.Cash)
    (function startCountdown(){
      const el = {
        h: document.getElementById('hours'),
        m: document.getElementById('minutes'),
        s: document.getElementById('seconds')
      };
      if (!el.h || !el.m || !el.s) return;
      let remaining = ${config.countdownHours || 3}*3600 + ${config.countdownMinutes || 58}*60 + ${config.countdownSeconds || 23}; 
      const tick = () => {
        if (remaining <= 0) return;
        const h = Math.floor(remaining/3600);
        const m = Math.floor((remaining%3600)/60);
        const s = remaining%60;
        el.h.textContent = String(h).padStart(2,'0');
        el.m.textContent = String(m).padStart(2,'0');
        el.s.textContent = String(s).padStart(2,'0');
        remaining--; 
        setTimeout(tick,1000);
      };
      tick();
    })();
  </script>`
      : ""
  }
</body>
</html>`
}

function generateTerraLeadsFormHTML(config: FormConfig, countryConfig: any): string {
  const translations = countryConfig?.language || {}

  return `<!doctype html>
<html lang="${config.country?.toLowerCase() || "pt"}">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${config.headline || "Doar hoje"}</title>
  <style>
    /* Estilos do formulário Dr.Cash */
    :root{--bg:${config.backgroundColor || "#f8f9fa"}; --card:${config.formBackgroundColor || "#fff"}; --border:#e9ecef; --green:#28a745; --primary:${config.primaryColor || "#dc3545"}; --muted:#6c757d; --input-bg:#fff; --input-bd:#ced4da; --text-dark:#212529; --text-light:#6c757d;}
    *{box-sizing:border-box}
    html,body{margin:0}
    body{background:var(--bg); color:var(--text-dark); font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
    .frame{width:100%; max-width: ${config.formWidth || "380"}px; margin:20px auto; padding:0; background:transparent;}
    .card{background:var(--card); border:1px solid var(--border); border-radius:12px; padding:20px; position:relative; box-shadow:0 2px 10px rgba(0,0,0,0.1);}
    .header{text-align:center; margin:10px 0 20px; padding-top:10px;}
    .header h2{margin:0; font-weight:600; font-size:20px; color:var(--text-dark);}
    .timer{display:flex; justify-content:center; align-items:center; gap:8px; margin:15px 0 20px; font-weight:600; font-size:14px;}
    .timer-box{background:${config.primaryColor || "#dc3545"}; color:#fff; padding:8px 10px; border-radius:4px; min-width:35px; text-align:center; font-weight:700; font-size:16px;}
    .price-container{margin:20px 0; padding:0 10px;}
    .price-content{display:flex; justify-content:space-between; align-items:center; flex:1;}
    .price-old{text-align:left;}
    .price-old .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-old .amount{color:var(--muted); text-decoration:line-through; font-size:16px;}
    .price-new{text-align:right;}
    .price-new .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-new .amount{color:var(--text-dark); font-weight:700; font-size:24px;}
    .social-proof{margin:20px 0; font-size:12px; color:var(--muted);}
    .social-item{display:flex; align-items:center; margin:4px 0;}
    .social-icon{width:12px; height:12px; margin-right:6px; border-radius:50%;}
    .icon-people{ background:#007bff; }
    .icon-time{ background:#28a745; }
    .social-number{ color:var(--text-dark); font-weight:600; }
    .online-dot{color:#28a745; margin-left:auto; animation: pulse 2s infinite;}
    @keyframes pulse {0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; }}
    .form-group{margin:15px 0;}
    input[type="text"], input[type="tel"]{width:100%; height:50px; padding:12px 16px; background:var(--input-bg); border:1px solid var(--input-bd); border-radius:6px; font-size:16px; outline:none; color:var(--muted);}
    input::placeholder{ color:#adb5bd; }
    input:focus{ border-color:#80bdff; box-shadow:0 0 0 0.2rem rgba(0,123,255,.25); }
    .btn{width:100%; height:50px; margin:20px 0 15px; border:none; border-radius:25px; background:${config.buttonColor || "#dc3545"}; color:#fff; font-size:16px; font-weight:700; cursor:pointer; text-transform:uppercase; letter-spacing:0.5px;}
    .btn:hover{ background:color-mix(in srgb, ${config.buttonColor || "#dc3545"} 90%, black); }
    .btn:active{ transform:translateY(1px); }
    .footer-note{text-align:center; margin:15px 0 5px;}
    .footer-text{color:var(--muted); font-size:11px; line-height:1.4;}
    .footer-disclaimer{color:var(--muted); font-size:10px; text-align:center; margin-top:10px; line-height:1.3;}
    @media (max-width: 340px){.card{ padding:15px; } .price-container{ padding:0 5px; }}
  </style>
</head>
<body>

  <div class="frame">
    <div class="card">

      <div class="header"><h2>${config.headline || "Oferta Especial"}</h2></div>
      ${
        config.showCountdown
          ? `<div class="timer">
        <span class="timer-box" id="hours">${String(config.countdownHours || 3).padStart(2, "0")}</span>
        <span class="timer-box" id="minutes">${String(config.countdownMinutes || 58).padStart(2, "0")}</span>
        <span class="timer-box" id="seconds">${String(config.countdownSeconds || 23).padStart(2, "0")}</span>
      </div>`
          : ""
      }
      <div class="price-container">
        <div class="price-content">
          <div class="price-old">
            <div class="label">${translations.oldPriceLabel || "Prețul vechi"}</div>
            <div class="amount">${config.oldPrice || "298"} ${config.currency || "RON"}</div>
          </div>
          <div class="price-new">
            <div class="label">${translations.newPriceLabel || "Prețul nou"}</div>
            <div class="amount">${config.newPrice || "149"} ${config.currency || "RON"}*</div>
          </div>
        </div>
      </div>
      <div class="social-proof">
        <div class="social-item">
          <div class="social-icon icon-people"></div>
          <span>${(countryConfig?.language?.socialProofPeople || config.socialProofText || "Acum pe site sunt {count} persoane").replace("{count}", `<span class="social-number">${config.socialProofPeople || 29}</span>`)}</span>
          <span class="online-dot">● online</span>
        </div>
        <div class="social-item">
          <div class="social-icon icon-time"></div>
          <span>${config.socialProofSales} ${countryConfig?.language?.socialProofSales || config.socialProofSalesText || "vânzări în ultima oră"}</span>
          <span class="online-dot">● online</span>
        </div>
      </div>
      
      <form class="orderForm" id="orderForm" action="/order.php" method="POST">
        
        <div class="form-group">
          <input id="name" name="name" type="text" placeholder="${config.namePlaceholder || "Nume complet"}" required>
        </div>

        <div class="form-group">
          <input id="phone" name="phone" type="tel" inputmode="tel" placeholder="${config.phonePlaceholder || "+40 123 456 789"}" required>
        </div>

        <input type="hidden" name="offer_id" value="${config.offerId || "SEUOFFERIDAQUI"}">
        <input type="hidden" name="country" value="${config.country || "BR"}">
        <input type="hidden" name="user_agent" id="user_agent" value="">
        <input type="hidden" name="referer" id="referer" value="">
        <input type="hidden" name="utm_source" id="utm_source" value="">
        <input type="hidden" name="utm_medium" id="utm_medium" value="">
        <input type="hidden" name="utm_campaign" id="utm_campaign" value="">
        <input type="hidden" name="utm_content" id="utm_content" value="">
        <input type="hidden" name="utm_term" id="utm_term" value="">
        <input type="hidden" name="sub_id" id="sub_id" value="">
        <input type="hidden" name="sub_id_1" id="sub_id_1" value="">
        <input type="hidden" name="sub_id_2" id="sub_id_2" value="">
        <input type="hidden" name="sub_id_3" id="sub_id_3" value="">
        <input type="hidden" name="sub_id_4" id="sub_id_4" value="">
        
        <button type="submit" class="btn" id="submitBtn">${config.ctaText || "COMANDAȚI CU REDUCERE"}</button>

        <div class="footer-note">${config.belowButtonEmoji || "🔒"} <span class="footer-text">${config.securityText || "Datele dvs. sunt protejate!"}</span></div>
        <div class="footer-disclaimer">${config.disclaimerText || "* Funcționează asupra mărturiilor în limitele unui canal de distribuție"}</div>
      </form>
    </div>
  </div>

  <script>
    // Preenche campos ocultos de rastreamento
    (function fillHiddenFields() {
      try {
        document.getElementById('user_agent').value = navigator.userAgent;
        document.getElementById('referer').value = document.referrer;
        
        const urlParams = new URLSearchParams(window.location.search);
        document.getElementById('utm_source').value = urlParams.get('utm_source') || '';
        document.getElementById('utm_medium').value = urlParams.get('utm_medium') || '';
        document.getElementById('utm_campaign').value = urlParams.get('utm_campaign') || '';
        document.getElementById('utm_content').value = urlParams.get('utm_content') || '';
        document.getElementById('utm_term').value = urlParams.get('utm_term') || '';
        document.getElementById('sub_id').value = urlParams.get('sub_id') || '';
        document.getElementById('sub_id_1').value = urlParams.get('sub_id_1') || '';
        document.getElementById('sub_id_2').value = urlParams.get('sub_id_2') || '';
        document.getElementById('sub_id_3').value = urlParams.get('sub_id_3') || '';
        document.getElementById('sub_id_4').value = urlParams.get('sub_id_4') || '';
      } catch(e) {
        console.error("Erro ao preencher campos ocultos:", e);
      }
    })();
    
    ${
      config.showCountdown
        ? `// Script do contador regressivo
    (function startCountdown(){
      const el = {
        h: document.getElementById('hours'),
        m: document.getElementById('minutes'),
        s: document.getElementById('seconds')
      };
      if (!el.h || !el.m || !el.s) return;
      let remaining = ${config.countdownHours || 3}*3600 + ${config.countdownMinutes || 58}*60 + ${config.countdownSeconds || 23}; 
      const tick = () => {
        if (remaining <= 0) return;
        const h = Math.floor(remaining/3600);
        const m = Math.floor((remaining%3600)/60);
        const s = remaining%60;
        el.h.textContent = String(h).padStart(2,'0');
        el.m.textContent = String(m).padStart(2,'0');
        el.s.textContent = String(s).padStart(2,'0');
        remaining--; 
        setTimeout(tick,1000);
      };
      tick();
    })();`
        : ""
    }
  </script>
</body>
</html>`
}

function generateDrCashFormHTML(config: FormConfig, countryConfig: any): string {
  return `<!doctype html>
<html lang="pl">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${config.headline}</title>
  <style>
    /* ===== Mobile-first base ===== */
    :root{
      --bg:${config.backgroundColor}; --card:${config.formBackgroundColor || "#fff"}; --border:#e9ecef; --green:#28a745; --green-d:#1e7e34;
      --primary:${config.primaryColor}; --red-d:color-mix(in srgb, ${config.primaryColor} 90%, black); --muted:#6c757d; --input-bg:#fff; --input-bd:#ced4da;
      --text-dark:#212529; --text-light:#6c757d;
    }
    *{box-sizing:border-box}
    html,body{margin:0}
    body{background:var(--bg); color:var(--text-dark); font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}

    /* Main container */
    .frame{
      width:100%; max-width: ${config.formWidth}px;
      margin:20px auto; padding:0; background:transparent;
    }
    .card{
      background:var(--card); border:1px solid var(--border); border-radius:12px; 
      padding:20px; position:relative; box-shadow:0 2px 10px rgba(0,0,0,0.1);
    }

    /* Header */
    .header{ text-align:center; margin:10px 0 20px; padding-top:10px; }
    .header h2{ margin:0; font-weight:600; font-size:20px; color:var(--text-dark); }

    /* Countdown timer */
    .timer{
      display:flex; justify-content:center; align-items:center; gap:8px;
      margin:15px 0 20px; font-weight:600; font-size:14px;
    }
    .timer-box{
      background:${config.countdownColor}; color:#fff; padding:8px 10px; border-radius:4px;
      min-width:35px; text-align:center; font-weight:700; font-size:16px;
    }

    /* Updated product image positioning to match preview */
    .product-image-top{
      display:flex; justify-content:center; margin:20px 0;
    }
    .product-image-top img{
      max-width:200px; max-height:200px; object-fit:contain; border-radius:8px;
      box-shadow:0 4px 15px rgba(0,0,0,0.1);
    }

    /* Price container with side image support */
    .price-container{
      margin:20px 0; padding:0 10px;
    }
    .price-container.with-side-image{
      display:flex; align-items:center; gap:15px;
    }
    .price-side-image{
      width:100px; height:100px; object-fit:contain; border-radius:6px;
      box-shadow:0 2px 8px rgba(0,0,0,0.1); flex-shrink:0;
    }
    .price-content{
      display:flex; justify-content:space-between; align-items:center; flex:1;
    }
    .price-old{
      text-align:left;
    }
    .price-old .label{
      color:var(--muted); font-size:12px; margin-bottom:2px;
    }
    .price-old .amount{
      color:var(--muted); text-decoration:line-through; font-size:16px;
    }
    .price-new{
      text-align:right;
    }
    .price-new .label{
      color:var(--muted); font-size:12px; margin-bottom:2px;
    }
    .price-new .amount{
      color:var(--text-dark); font-weight:700; font-size:24px;
    }

    /* Social proof */
    .social-proof{
      margin:20px 0; font-size:12px; color:var(--muted);
    }
    .social-item{
      display:flex; align-items:center; margin:4px 0;
    }
    .social-icon{
      width:12px; height:12px; margin-right:6px; border-radius:50%;
    }
    .icon-people{ background:#007bff; }
    .icon-time{ background:#28a745; }
    .social-number{ color:var(--text-dark); font-weight:600; }
    .online-dot{
      color:#28a745; margin-left:auto;
      animation: pulse 2s infinite;
    }
    @keyframes pulse {
      0% { opacity: 1; }
      50% { opacity: 0.5; }
      100% { opacity: 1; }
    }

    /* Form elements */
    .form-group{
      margin:15px 0;
    }
    input[type="text"], input[type="tel"]{
      width:100%; height:50px; padding:12px 16px;
      background:var(--input-bg); border:1px solid var(--input-bd); border-radius:6px;
      font-size:16px; outline:none; color:var(--muted);
    }
    input::placeholder{ color:#adb5bd; }
    input:focus{ border-color:#80bdff; box-shadow:0 0 0 0.2rem rgba(0,123,255,.25); }

    /* CTA button */
    .btn{
      width:100%; height:50px; margin:20px 0 15px;
      border:none; border-radius:25px;
      background:${config.buttonColor}; color:#fff;
      font-size:16px; font-weight:700; cursor:pointer;
      text-transform:uppercase; letter-spacing:0.5px;
    }
    .btn:hover{ background:color-mix(in srgb, ${config.buttonColor} 90%, black); }
    .btn:active{ transform:translateY(1px); }

    /* Footer note */
    .footer-note{
      text-align:center; margin:15px 0 5px;
    }
    .footer-icon{
      display:inline-block; width:16px; height:16px; 
      background:#ffc107; border-radius:50%; margin-right:6px;
    }
    .footer-text{
      color:var(--muted); font-size:11px; line-height:1.4;
    }
    .footer-disclaimer{
      color:var(--muted); font-size:10px; text-align:center; 
      margin-top:10px; line-height:1.3;
    }

    /* Responsive adjustments */
    @media (max-width: 340px){
      .card{ padding:15px; }
      .price-container{ padding:0 5px; }
      .price-container.with-side-image{ gap:10px; }
      .price-side-image{ width:80px; height:80px; }
    }
  </style>
</head>
<body>

  <div class="frame">
    <div class="card">

      <!-- Header -->
      <div class="header">
        <h2>${config.headline}</h2>
      </div>

      ${
        config.showCountdown
          ? `
      <!-- Countdown Timer -->
      <div class="timer">
        <span class="timer-box" id="hours">${String(config.countdownHours).padStart(2, "0")}</span>
        <span class="timer-box" id="minutes">${String(config.countdownMinutes).padStart(2, "0")}</span>
        <span class="timer-box" id="seconds">${String(config.countdownSeconds).padStart(2, "0")}</span>
      </div>
      `
          : ""
      }

      <!-- Product image -->
      ${
        config.showProductImage && config.productImageUrl && config.productImagePosition === "top"
          ? `
      <div class="product-image-top">
        <img src="${config.productImageUrl}" alt="Product" onerror="this.style.display='none';">
      </div>
      `
          : ""
      }

      <!-- Prices with side image support -->
      <div class="price-container${config.showProductImage && config.productImageUrl && config.productImagePosition === "left" ? " with-side-image" : ""}">
        ${
          config.showProductImage && config.productImageUrl && config.productImagePosition === "left"
            ? `
        <img src="${config.productImageUrl}" alt="Product" class="price-side-image" onerror="this.style.display='none';">
        `
            : ""
        }
        <div class="price-content">
          <div class="price-old">
            <div class="label">${countryConfig?.language.oldPriceLabel || "Preț vechi"}</div>
            <div class="amount">${config.oldPrice} ${config.currency}</div>
          </div>
          <div class="price-new">
            <div class="label">${countryConfig?.language.newPriceLabel || "Preț nou"}</div>
            <div class="amount">${config.newPrice} ${config.currency}*</div>
          </div>
        </div>
      </div>

      <!-- Social Proof -->
      <div class="social-proof">
        <div class="social-item">
          <div class="social-icon icon-people"></div>
          <span>${(countryConfig?.language?.socialProofPeople || config.socialProofText || "Acum pe site sunt {count} persoane").replace("{count}", `<span class="social-number">${config.socialProofPeople}</span>`)}</span>
          <span class="online-dot">● online</span>
        </div>
        <div class="social-item">
          <div class="social-icon icon-time"></div>
          <span>${config.socialProofSales} ${countryConfig?.language.socialProofSales || "vânzări în ultima oră"}</span>
          <span class="online-dot">● online</span>
        </div>
      </div>

      <!-- Form -->
      <form class="orderForm" id="orderForm">
        <div class="form-group">
          <input id="name" name="name" type="text" placeholder="${config.namePlaceholder}" required>
        </div>

        <div class="form-group">
          <input id="phone" name="phone" type="tel" inputmode="tel" 
               placeholder="${config.phonePlaceholder}" required>
        </div>

        <!-- Hidden tracking fields -->
        <input type="hidden" name="sub1">
        <input type="hidden" name="sub2">
        <input type="hidden" name="sub3">
        <input type="hidden" name="sub4">
        <input type="hidden" name="sub5">

        <button type="submit" class="btn" id="submitBtn">${config.ctaText}</button>

        <!-- Footer -->
        <div class="footer-note">
          ${config.belowButtonEmoji} <span class="footer-text">${config.belowButtonText}</span>
        </div>

        <div class="footer-disclaimer">
          ${config.disclaimerText}
        </div>

        <div id="statusMsg" class="footer-disclaimer" style="margin-top:8px;"></div>
      </form>

    </div>
  </div>

  <!-- dr.cash front-end script -->
  <script src="https://snippet.infothroat.com/dist/api/lead-1.1.0.min.js"></script>
  <script>
    /* Your credentials */
    const API_TOKEN   = "${config.apiKey}";
    const STREAM_CODE = "${config.offerId}";
    const THANKS_PAGE = "/thank-you.html";

    // Autofill subs from URL
    (function fillSubsFromURL(){
      const url = new URL(window.location.href);
      ['sub1','sub2','sub3','sub4','sub5'].forEach(k=>{
        const v = url.searchParams.get(k);
        if (v) {
          const el = document.querySelector(\`input[name="\${k}"]\`);
          if (el) el.value = v;
        }
      });
    })();

    // Phone helper for different countries
    document.getElementById('orderForm').addEventListener('submit', function(){
      const phone = document.getElementById('phone');
      let raw = phone.value.trim();
      const digits = raw.replace(/\\D/g,'');
      
      // Format based on country
      if ('${config.country}' === 'PL' && !raw.startsWith('+48') && digits.length === 9) {
        raw = '+48 ' + digits.replace(/(\\d{3})(\\d{3})(\\d{3})/,'$1 $2 $3');
      } else if ('${config.country}' === 'RO' && !raw.startsWith('+40') && digits.length === 9) {
        raw = '+40 ' + digits.replace(/(\\d{3})(\\d{3})(\\d{3})/,'$1 $2 $3');
      }
      
      phone.value = raw;
    });

    ${
      config.showCountdown
        ? `
    // Enhanced countdown with hours:minutes:seconds
    (function startCountdown(){
      const hoursEl = document.getElementById('hours');
      const minutesEl = document.getElementById('minutes');
      const secondsEl = document.getElementById('seconds');
      const btn = document.getElementById('submitBtn');
      
      let remaining = ${config.countdownHours}*3600 + ${config.countdownMinutes}*60 + ${config.countdownSeconds}; // Start from config values
      
      const tick = () => {
        const h = Math.floor(remaining/3600);
        const m = Math.floor((remaining%3600)/60);
        const s = remaining%60;
        
        hoursEl.textContent = String(h).padStart(2,'0');
        minutesEl.textContent = String(m).padStart(2,'0');
        secondsEl.textContent = String(s).padStart(2,'0');
        
        if (remaining<=0){ 
          btn.textContent = "Oferta prawie wygasła – zamów teraz"; 
          return; 
        }
        remaining--; 
        setTimeout(tick,1000);
      };
      tick();
    })();
    `
        : ""
    }

    // Initialize dr.cash submission
    drlead.init({
      params: { token: API_TOKEN, stream_code: STREAM_CODE, thanks_page: THANKS_PAGE },
      subs: {
        sub1: document.querySelector('input[name="sub1"]').value,
        sub2: document.querySelector('input[name="sub2"]').value,
        sub3: document.querySelector('input[name="sub3"]').value,
        sub4: document.querySelector('input[name="sub4"]').value,
        sub5: document.querySelector('input[name="sub5"]').value
      },
      onSuccess: function(){ 
        document.getElementById('statusMsg').textContent = "Wysłano! Przekierowanie…"; 
      },
      onError: function(err){
        document.getElementById('statusMsg').textContent = "Nie udało się wysłać. Sprawdź dane i spróbuj ponownie.";
        console.error("dr.cash error:", err);
      }
    });
  </script>
</body>
</html>`
}



export function generateThankYouPage(config: FormConfig): string {
  if (!config.thankYou.enabled) {
    return generateSimpleThankYouPage(config)
  }

  const countryConfig = countryConfigs[config.country]
  const thankYouTranslations = countryConfig?.language?.thankYouPage

  const pageTitle = config.thankYou.title || thankYouTranslations?.title || "Obrigado pela sua compra!"
  const pageMessage =
    config.thankYou.message || thankYouTranslations?.message || "Sua compra foi processada com sucesso..."
  const buttonText = config.thankYou.buttonText || thankYouTranslations?.buttonText || "Voltar ao Site"
  const finalText =
    config.thankYou.finalText ||
    thankYouTranslations?.finalText ||
    "Importante: Mantenha seu telefone por perto. Entraremos em contato em até 24 horas para confirmar sua compra."
  const upsellTitle = config.thankYou.upsellTitle || thankYouTranslations?.upsellTitle || "Oferta Especial!"
  const upsellMessage =
    config.thankYou.upsellMessage || thankYouTranslations?.upsellMessage || "Aproveite esta oferta exclusiva..."
  const upsellButtonText =
    config.thankYou.upsellButtonText || thankYouTranslations?.upsellButtonText || "QUERO APROVEITAR"

  const imageUrl = config.thankYou.imageUrl?.trim()
  const hasValidImage =
    imageUrl &&
    (imageUrl.startsWith("http://") ||
      imageUrl.startsWith("https://") ||
      imageUrl.startsWith("/") ||
      imageUrl.startsWith("data:"))

  const upsellImageUrl = config.thankYou.upsellImageUrl?.trim()
  const hasValidUpsellImage =
    upsellImageUrl &&
    (upsellImageUrl.startsWith("http://") ||
      upsellImageUrl.startsWith("https://") ||
      upsellImageUrl.startsWith("/") ||
      upsellImageUrl.startsWith("data:"))

  const buttonSizeStyles = {
    small: "padding: 12px 24px; font-size: 14px;",
    medium: "padding: 15px 30px; font-size: 16px;",
    large: "padding: 18px 40px; font-size: 18px;",
  }

  const htmlLang = countryConfig?.code.toLowerCase() || "pt-br"

  return `<!DOCTYPE html>
<html lang="${htmlLang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${pageTitle}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: ${config.thankYou.backgroundColor};
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .thank-you-container {
            background-color: ${config.thankYou.containerColor};
            padding: 40px 30px;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            max-width: 600px;
            width: 90%;
            margin: 20px;
        }
        .success-icon {
            width: 80px;
            height: 80px;
            background: ${config.thankYou.titleColor};
            border-radius: 50%;
            margin: 0 auto 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            color: white;
        }
        .thank-you-container h1 {
            color: ${config.thankYou.titleColor};
            margin: 0 0 20px;
            font-size: 28px;
            font-weight: 600;
        }
        .thank-you-container p {
            font-size: 16px;
            color: ${config.thankYou.messageColor};
            line-height: 1.6;
            margin: 0 0 20px;
        }
        .main-button {
            display: inline-block;
            background-color: ${config.thankYou.buttonColor};
            color: ${config.thankYou.buttonTextColor};
            ${buttonSizeStyles[config.thankYou.buttonSize as keyof typeof buttonSizeStyles] || buttonSizeStyles.medium}
            text-decoration: none;
            border-radius: 8px;
            margin: 20px 0;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .main-button:hover {
            background-color: color-mix(in srgb, ${config.thankYou.buttonColor} 90%, black);
            transform: translateY(-2px);
        }
        .product-image {
            max-width: 200px;
            height: auto;
            margin: 20px 0;
            border-radius: 8px;
            display: block;
            margin-left: auto;
            margin-right: auto;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        .product-image-error {
            max-width: 200px;
            height: 150px;
            margin: 20px auto;
            border-radius: 8px;
            background: #f8f9fa;
            border: 2px dashed #dee2e6;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            font-size: 14px;
            flex-direction: column;
            gap: 8px;
        }
        .order-details {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 30px 0;
            text-align: left;
        }
        .order-details h3 {
            margin: 0 0 15px;
            font-size: 18px;
            color: #333;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin: 10px 0;
            font-size: 14px;
        }
        .detail-label {
            color: #666;
        }
        .detail-value {
            font-weight: 600;
            color: #333;
        }
        
        .upsell-container {
            background: ${config.thankYou.upsellBackgroundColor || "linear-gradient(135deg, #ff6b35, #f7931e)"};
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin: 30px 0;
            position: relative;
            overflow: hidden;
            animation: slideInUp 0.8s ease-out;
        }
        .upsell-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }
        .upsell-content {
            position: relative;
            z-index: 2;
        }
        .upsell-title {
            font-size: 24px;
            font-weight: bold;
            margin: 0 0 15px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .upsell-message {
            font-size: 16px;
            margin: 0 0 20px;
            line-height: 1.5;
        }
        .upsell-price {
            font-size: 32px;
            font-weight: bold;
            margin: 15px 0;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .upsell-button {
            display: inline-block;
            background-color: ${config.thankYou.upsellButtonColor};
            color: white;
            padding: 18px 40px;
            text-decoration: none;
            border-radius: 50px;
            font-weight: bold;
            font-size: 18px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            animation: pulse 2s infinite;
        }
        .upsell-button:hover {
            background-color: color-mix(in srgb, ${config.thankYou.upsellButtonColor} 90%, black);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.3);
        }
        
        .upsell-image {
            max-width: 150px;
            height: auto;
            margin: 15px 0;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .upsell-image-error {
            max-width: 150px;
            height: 100px;
            margin: 15px auto;
            border-radius: 8px;
            background: rgba(255,255,255,0.2);
            border: 2px dashed rgba(255,255,255,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            color: rgba(255,255,255,0.8);
            font-size: 12px;
            flex-direction: column;
            gap: 5px;
        }
        
        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .contact-info {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
            font-size: 14px;
            color: #666;
            white-space: pre-line;
        }
        
        @media (max-width: 600px) {
            .thank-you-container {
                padding: 30px 20px;
            }
            .upsell-container {
                padding: 25px 20px;
            }
            .upsell-title {
                font-size: 20px;
            }
            .upsell-price {
                font-size: 28px;
            }
        }
    </style>
</head>
<body>
    <div class="thank-you-container">
        <div class="success-icon">✓</div>
        <h1>${pageTitle}</h1>
        <p>${pageMessage}</p>
        
        ${
          config.thankYou.showImage
            ? hasValidImage
              ? `<img src="${imageUrl}" alt="Produto" class="product-image" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                 <div class="product-image-error" style="display: none;">
                   <span>📷</span>
                   <span>Imagem não encontrada</span>
                 </div>`
              : `<div class="product-image-error">
                   <span>📷</span>
                   <span>URL da imagem inválida</span>
                   <small style="font-size: 12px; opacity: 0.7;">Verifique se a URL começa com http:// ou https://</small>
                 </div>`
            : ""
        }
        
        <div class="order-details">
            <h3>${thankYouTranslations?.orderDetailsTitle || "Detalhes da Compra"}:</h3>
            <div class="detail-row">
                <span class="detail-label">${thankYouTranslations?.productLabel || "Produto"}:</span>
                <span class="detail-value">${config.headline}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">${thankYouTranslations?.priceLabel || "Preço"}:</span>
                <span class="detail-value">${config.newPrice} ${config.currency}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">${thankYouTranslations?.discountLabel || "Desconto"}:</span>
                <span class="detail-value">-${config.discount}%</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">${thankYouTranslations?.statusLabel || "Status"}:</span>
                <span class="detail-value" style="color: #28a745;">✓ ${thankYouTranslations?.statusConfirmed || "Confirmado"}</span>
            </div>
        </div>
        
        ${
          config.thankYou.showUpsell
            ? `
        <div class="upsell-container">
            <div class="upsell-content">
                <div class="upsell-title">${upsellTitle}</div>
                <div class="upsell-message">${upsellMessage}</div>
                
                ${
                  config.thankYou.showUpsellImage
                    ? hasValidUpsellImage
                      ? `<img src="${upsellImageUrl}" alt="Produto Upsell" class="upsell-image" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                         <div class="upsell-image-error" style="display: none;">
                           <span>📷</span>
                           <span>Imagem não encontrada</span>
                         </div>`
                      : `<div class="upsell-image-error">
                           <span>📷</span>
                           <span>URL inválida</span>
                         </div>`
                    : ""
                }
                
                <div class="upsell-price">${config.thankYou.upsellPrice}</div>
                <a href="${config.thankYou.upsellButtonUrl}" class="upsell-button">${upsellButtonText}</a>
            </div>
        </div>
        `
            : ""
        }
        
        <a href="${config.thankYou.buttonUrl}" class="main-button">${buttonText}</a>
        
        <div class="contact-info">
            ${finalText}
        </div>
    </div>
</body>
</html>`
}

export function generateSendOrderPHP(config: FormConfig): string {
  if (config.platform === "ADCOMBO") {
    return generateADCOMBOSendOrderPHP(config)
  } else if (config.platform === "NETVORK") {
    return generateNETVORKSendOrderPHP(config)
  } else if (config.platform === "WEBVORK") {
    return generateWebvorkPHP(config)
  } else if (config.platform === "LIMONAD") {
    return generateLimonadPHP(config)
  } else if (config.platform === "TRAFFIC_LIGHT") {
    return generateTrafficLightPHP(config)
  } else if (config.platform === "TERRA_LEADS") {
    return generateTerraLeadsPHP(config)
  } else if (config.platform === "SHAKES_PRO") {
    // Call Shakes.pro PHP generator
    return generateShakesProSendOrderPHP(config)
  } else if (config.platform === "CPAGETTI") {
    return generateCpagettiPHPImport(config)
  }

  return generateDrCashSendOrderPHP(config)
}

// Function to generate ADCOMBO send order PHP
function generateADCOMBOSendOrderPHP(config: FormConfig): string {
  return `<?php
const API_URL = "https://api.adcombo.com/api/v2/order/create/";
const API_KEY = "${config.apiKey || "YOUR_API_KEY_HERE"}";
$args = [
    'api_key' => '${config.apiKey || "YOUR_API_KEY_HERE"}',
    'name' => $_POST['name'],
    'phone' => $_POST['phone'],
    'offer_id' => $_POST['offer_id'],
    'country_code' => $_POST['country_code'],
    'price' => $_POST['price'],
    'base_url' => $_POST['base_url'],
    'ip' => $_SERVER['REMOTE_ADDR'],
    ];
$url = API_URL.'?'.http_build_query($args);
$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true
));
$res = curl_exec($curl);
curl_close($curl);
$res = json_decode($res, true);
if ($res['code'] == 'ok') {
    header('Location:'.$_POST['success_page']);
    echo $res['msg'] . ": " . $res['order_id'];
    
} else {
    echo $res['error'];
}

?>`
}

// Function to generate NETVORK send order PHP
function generateNETVORKSendOrderPHP(config: FormConfig): string {
  return `<?php

const TOKEN = '${config.apiKey || "SUA API KEY AQUI"}'; // SEU TOKEN
const ENDPOINT_1 = 'https://api.netvork.net/v1/new-lead';
const ENDPOINT_2 = 'https://api2.netvork.net/v1/new-lead';

function getIp()
{
    if (!empty(\$_SERVER['HTTP_CLIENT_IP'])) {
        return \$_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty(\$_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $arIp = explode(',', \$_SERVER['HTTP_X_FORWARDED_FOR']);
        return $arIp[0];
    } elseif (!empty(\$_SERVER['REMOTE_ADDR'])) {
        return \$_SERVER['REMOTE_ADDR'];
    }
    return '';
}

function checkUserAgent()
{
    if (
        empty(\$_SERVER['HTTP_USER_AGENT'])
        || !preg_match('/Windows|Mac|Linux|Android|iPad|iPhone/i', \$_SERVER['HTTP_USER_AGENT'])
    ) {
        die();
    }
}

function apinetvorkV1NewLead($data)
{
    $endpoints = [
        ENDPOINT_1,
        ENDPOINT_2
    ];
    foreach ($endpoints as $endpoint) {
        $ch = curl_init($endpoint);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true); // Use true para produção!
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded'
        ]);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response !== false && $http_code == 200) {
            $json = json_decode($response, true);
            if (isset($json['status'])) {
                return true;
            }
        }
    }
    return false;
}

if (!empty($_POST)) {
    checkUserAgent();

    $data = array(
        'token' => TOKEN,
        'offer_id' => !empty($_POST['offer_id']) ? trim($_POST['offer_id']) : '',
        'name' => !empty($_POST['name']) ? trim($_POST['name']) : '',
        'phone' => !empty($_POST['phone']) ? trim($_POST['phone']) : '',
        'country' => !empty($_POST['country']) ? trim($_POST['country']) : '',
        'lang' => !empty($_POST['lang']) ? trim($_POST['lang']) : '',
        'utm_source' => !empty($_POST['utm_source']) ? trim($_POST['utm_source']) : '',
        'utm_medium' => !empty($_POST['utm_medium']) ? trim($_POST['utm_medium']) : '',
        'utm_campaign' => !empty($_POST['utm_campaign']) ? trim($_POST['utm_campaign']) : '',
        'utm_content' => !empty($_POST['utm_content']) ? trim($_POST['utm_content']) : '',
        'utm_term' => !empty($_POST['utm_term']) ? trim($_POST['utm_term']) : '',
        'ip' => getIp(),
    );

    // Basic validation
    if (empty($data['token']) || empty($data['offer_id']) || empty($data['phone']) || empty($data['country'])) {
        header("Location: error.html"); // Redirect to an error page
        die();
    }

    $count = 3;
    while ($count--) {
        if (apinetvorkV1NewLead($data)) {
            header("Location: success.html");
            die();
        } else {
            sleep(2);
        }
    }
    
    // If all attempts failed
    header("Location: error.html");
    die();
}

// Health check endpoint (optional)
if (isset($_GET['health'])) {
    echo json_encode(['status' => 'ok']);
    exit;
}

?>`
}

// Function to generate WEBVORK send order PHP
function generateWebvorkPHP(config: FormConfig): string {
  return `<?php
const TOKEN = '${config.apiKey || "SUA API AQUI"}';
const ENDPOINT1 = 'https://api.webvork.com/v1/new-lead';
const ENDPOINT2 = 'https://api2.webvork.com/v1/new-lead';

function getIp() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return $_SERVER['HTTP_X_FORWARDED_FOR'];
    return $_SERVER['REMOTE_ADDR'] ?? '';
}

function apiWebvorkV1NewLead($data) {
    $ch = curl_init(ENDPOINT1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);

    if ($result) {
        $r = json_decode($result, true);
        // DEBUG: grava resposta para fins de análise
        file_put_contents('retorno_api.txt', $result);

        if ((isset($r['success']) && $r['success']) ||
           (isset($r['status']) && ($r['status']=='ok' || $r['status']===true))) {
            return true;
        }
    }
    // Só tenta endpoint 2 se o primeiro falhar
    $ch = curl_init(ENDPOINT2);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);

    if ($result) {
        $r = json_decode($result, true);
        // DEBUG: grava resposta do endpoint 2
        file_put_contents('retorno_api.txt', $result);

        if ((isset($r['success']) && $r['success']) ||
           (isset($r['status']) && ($r['status']=='ok' || $r['status']===true))) {
            return true;
        }
    }
    return false;
}

if (!empty($_POST)) {
    $data = [
        'token' => TOKEN,
        'offer_id' => '${config.offerId || "409"}',
        'name' => !empty($_POST['name']) ? trim($_POST['name']) : '',
        'phone' => !empty($_POST['phone']) ? trim($_POST['phone']) : '',
        'country' => !empty($_POST['country']) ? trim($_POST['country']) : '${config.country || "IT"}',
        'lang' => '${config.country?.toLowerCase() || "it"}',
        'utm_source' => $_POST['utm_source'] ?? '',
        'utm_medium' => $_POST['utm_medium'] ?? '',
        'utm_campaign' => $_POST['utm_campaign'] ?? '',
        'utm_content' => $_POST['utm_content'] ?? '',
        'utm_term' => $_POST['utm_term'] ?? '',
        'ip' => getIp()
    ];
    if (apiWebvorkV1NewLead($data)) {
        header("Location: success.html");
        exit;
    } else {
        header("Location: error.html");
        exit;
    }
}

if (isset($_GET['health'])) {
    echo "OK";
}
?>`
}

// Function to generate LIMONAD send order PHP
function generateLimonadPHP(config: FormConfig): string {
  return `<?php
// Versão do script Limonad

const API_URL = 'https://sendmelead.com/api/v3/lead/add';
const OFFER_ID = '${config.offerId || "35571657-ff1d-4ea7-9e34-635d962e3d97"}'; // ID da oferta
const WEBMASTER_TOKEN = '${config.apiKey || "afe1908ddfde27ec69bb846c904613a0"}'; // Seu token Limonad
const COST = 0; // Valor da oferta
const NAME_FIELD = 'name'; // Nome do campo nome
const PHONE_FIELD = 'phone'; // Nome do campo telefone
const urlForNotPost = 'index.php';
const urlForEmptyRequiredFields = 'index.php';
const urlForNotJson = 'index.php';
const urlSuccess = 'success.html'; // Nome da página de obrigado

function writeToLog($data, $response) {
    $log = date("F j, Y, g:i a") . PHP_EOL;
    $log .= "Data: " . print_r($data, true) . PHP_EOL;
    $log .= "Response: " . $response . PHP_EOL . PHP_EOL;
    file_put_contents('limonad_log.txt', $log, FILE_APPEND);
}

function getUserIp() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Checa se os campos obrigatórios estão preenchidos
    if (empty($_POST[NAME_FIELD]) || empty($_POST[PHONE_FIELD])) {
        header('Location: ' . urlForEmptyRequiredFields);
        exit;
    }

    $args = array(
        'name' => $_POST[NAME_FIELD],
        'phone' => $_POST[PHONE_FIELD],
        'offerId' => OFFER_ID,
        'domain' => "http://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"],
        'ip' => getUserIp(),
        'utm_campaign' => key_exists('utmcampaign', $_POST) ? $_POST['utmcampaign'] : null,
        'utm_content' => key_exists('utmcontent', $_POST) ? $_POST['utmcontent'] : null,
        'utm_medium' => key_exists('utmmedium', $_POST) ? $_POST['utmmedium'] : null,
        'utm_source' => key_exists('utmsource', $_POST) ? $_POST['utmsource'] : null,
        'utm_term' => key_exists('utmterm', $_POST) ? $_POST['utmterm'] : null,
        'clickid' => key_exists('clickid', $_POST) ? $_POST['clickid'] : null,
        'fbpxl' => key_exists('fbpxl', $_POST) ? $_POST['fbpxl'] : null,
        'cost' => COST,
    );

    $data = json_encode($args);

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => API_URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data),
            'X-Token: ' . WEBMASTER_TOKEN,
        ),
    ));

    $result = curl_exec($curl);
    curl_close($curl);

    writeToLog($args, $result);

    $result = json_decode($result, true);

    if ($result === null) {
        header('Location: ' . urlForNotJson);
        exit;
    } else {
        // Redireciona para a página de obrigado
        header('Location: ' . urlSuccess);
        exit;
    }
} else {
    header('Location: ' . urlForNotPost);
    exit;
}
?>`
}

// Function to generate TRAFFIC_LIGHT send order PHP
function generateTrafficLightPHP(config: FormConfig): string {
  const apiKey = config.apiKey || "SUA CHAVE API AQUI"
  const country = config.country || "GEO AQUI"
  const domain = config.domain || "buyontheofficiall.shop"

  return `<?php
// send-lead.php
header('Content-Type: application/json');

$apiKey = '${apiKey}'; // Sua chave de API aqui
$apiUrl = 'http://api.cpa.tl/api/lead/send';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data_post = $_POST;

    $data = array(
        'key' => $apiKey,
        'id' => microtime(true),
        'offer_id' => $data_post['offer_id'],
        'name' => $data_post['name'],
        'phone' => $data_post['phone'],
        'country' => '${country}',
        'ip_address' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => $_SERVER['HTTP_USER_AGENT'],
    );

    $options = array(
        'http' => array(
            'header' => "Content-type: application/x-www-form-urlencoded\\r\\n",
            'method' => 'POST',
            'content' => http_build_query($data),
            'ignore_errors' => true,
        )
    );

    $context = stream_context_create($options);
    $result = file_get_contents($apiUrl, false, $context);
    $obj = json_decode($result);

    if (!empty($obj->errmsg)) {
        echo json_encode(['success' => false, 'error' => $obj->errmsg]);
    } else {
        echo json_encode(['success' => true, 'id' => $obj->id]);
        // Redireciona para página de obrigado
        header('Location: https://${domain}/success.html');
        exit;
    }
}
?>`
}

// Function to generate TERRA_LEADS send order PHP
function generateTerraLeadsPHP(config: FormConfig): string {
  const apiKey = config.apiKey || "SUA CHAVE API AQUI"
  const userId = config.userId || "SEU USER ID AQUI"
  const successPage = `https://${config.domain || "SEUDOMINIOAQUI"}/success.html`

  return `<?php
// Ativa o buffer de saída para garantir que o redirect funcione
ob_start();

// =======================================================
// 1. CONFIGURAÇÃO (PREENCHA SEUS DADOS AQUI)
// =======================================================

// Sua Chave API secreta (do seu perfil TerraLeads)
$api_key = '${apiKey}'; 

// Seu ID de Usuário (do seu perfil TerraLeads)
$user_id = '${userId}'; // Deve ser um número (integer)

// Sua página de "Obrigado"
$success_page = '${successPage}';

// URL da API (não mude)
$api_domain = 'https://t-api.org';
$model = 'lead';
$method = 'create';

// =======================================================
// 2. VERIFICAÇÃO E COLETA DE DADOS
// =======================================================

// Apenas executa se for um POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('Acesso não autorizado.');
}

// Função para pegar o IP (funciona com Cloudflare)
function get_ip() {
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
      return $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    if(isset($_SERVER['REMOTE_ADDR'])) {
      return $_SERVER['REMOTE_ADDR'];
    }
    return '127.0.0.1';
}

// =======================================================
// 3. MONTAGEM DOS DADOS (JSON)
// =======================================================

// Monta o array 'data' interno, conforme a documentação
$data_payload = [
    'name' => $_POST['name'] ?? 'Cliente',
    'phone' => $_POST['phone'] ?? '',
    'offer_id' => (int)($_POST['offer_id'] ?? 0),
    'country' => $_POST['country'] ?? 'BR', // Padrão 'BR' se não for enviado
    'user_agent' => $_POST['user_agent'] ?? $_SERVER['HTTP_USER_AGENT'],
    'referer' => $_POST['referer'] ?? '',
    'utm_source' => $_POST['utm_source'] ?? null,
    'utm_medium' => $_POST['utm_medium'] ?? null,
    'utm_campaign' => $_POST['utm_campaign'] ?? null,
    'utm_content' => $_POST['utm_content'] ?? null,
    'utm_term' => $_POST['utm_term'] ?? null,
    'sub_id' => $_POST['sub_id'] ?? null,
    'sub_id_1' => $_POST['sub_id_1'] ?? null,
    'sub_id_2' => $_POST['sub_id_2'] ?? null,
    'sub_id_3' => $_POST['sub_id_3'] ?? null,
    'sub_id_4' => $_POST['sub_id_4'] ?? null,
    'ip_address' => get_ip() // Adicionando IP, embora não listado, é padrão
];

// Monta o corpo (body) completo da requisição
$request_body = [
    'user_id' => (int)$user_id,
    'data' => $data_payload
];

// Converte o corpo para JSON
$json_data = json_encode($request_body);

// =======================================================
// 4. AUTENTICAÇÃO E ENVIO (cURL)
// =======================================================

// Cria o check_sum (sha1 do JSON + sua api_key)
$check_sum = sha1($json_data . $api_key);

// Monta a URL final da API com o check_sum
$api_url = $api_domain . '/api/' . $model . '/' . $method . '?check_sum=' . $check_sum;

// Inicia o cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data); // Envia os dados como JSON
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
// Define o cabeçalho como JSON (MUITO IMPORTANTE)
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Content-Length: ' . strlen($json_data)
]);

$result = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);
curl_close($ch);

// =======================================================
// 5. RESPOSTA E REDIRECIONAMENTO
// =======================================================

// Salva um log para depuração
$log = "Data: " . $json_data . "\\n";
$log .= "Resposta API: " . $result . "\\n";
$log .= "HTTP Code: " . $http_code . "\\n";
$log .= "Curl Error: " . $curl_error . "\\n";
$log .= "-----------------\\n";
file_put_contents('terraleads_log.txt', $log, FILE_APPEND);

// Decodifica a resposta
$response = json_decode($result, true);

// Verifica se o lead foi aceito
if ($http_code == 200 && isset($response['status']) && $response['status'] == 'ok') {
    // SUCESSO! Redireciona para a página de obrigado
    header('Location: ' . $success_page);
    ob_end_flush(); // Envia o redirecionamento
    exit;
} else {
    // FALHA! Redireciona de volta para o formulário (ou página de erro)
    // Você pode ver o erro no arquivo 'terraleads_log.txt'
    header('Location: index.html?error=1');
    ob_end_flush(); // Envia o redirecionamento
    exit;
}
?>`
}

// Function to generate SHAKES_PRO send order PHP
function generateShakesProSendOrderPHP(config: FormConfig): string {
  return `<?php
// Placeholder for Shakes.pro send order logic
// This script assumes the form submits to this file and handles the redirect.

header('Content-Type: application/json');

// --- Configuration ---
$domain = '${config.domain || "your-domain.com"}'; // Your domain name
$successPage = 'success.html'; // Your success page URL

// --- Get form data ---
$name = $_POST['name'] ?? '';
$phone = $_POST['phone'] ?? '';
$offerId = $_POST['offer_id'] ?? '';
$country = $_POST['country'] ?? '';
$utmSource = $_POST['utm_source'] ?? '';
$utmMedium = $_POST['utm_medium'] ?? '';
$utmCampaign = $_POST['utm_campaign'] ?? '';

// --- Basic Validation ---
if (empty($name) || empty($phone)) {
    // In a real scenario, you might return an error JSON or redirect to an error page
    header("Location: error.html"); 
    exit;
}

// --- Logging (Optional) ---
$logData = [
    'name' => $name,
    'phone' => $phone,
    'offer_id' => $offerId,
    'country' => $country,
    'utm_source' => $utmSource,
    'utm_medium' => $utmMedium,
    'utm_campaign' => $utmCampaign,
    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'N/A',
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'N/A',
    'timestamp' => date('Y-m-d H:i:s')
];
// file_put_contents('shakespro_orders.log', json_encode($logData) . PHP_EOL, FILE_APPEND);

// --- Redirect to success page ---
header("Location: " . $successPage);
exit;

?>`
}

// Function to generate Dr.Cash send order PHP
function generateDrCashSendOrderPHP(config: FormConfig): string {
  return `<?php
// Keep this file as a fallback or for additional server-side processing

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Configuration
$config = [
    'platform' => '${config.platform}',
    'api_key' => '${config.apiKey}',
    'offer_id' => '${config.offerId}',
    'domain' => '${config.domain}',
    'country' => '${config.country}',
    'redirect_url' => 'thank-you.html'
];

// Validate required fields
if (empty($_POST['name']) || empty($_POST['phone'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Name and phone are required']);
    exit;
}

// Sanitize input data
$data = [
    'name' => trim(htmlspecialchars($_POST['name'])),
    'phone' => trim(htmlspecialchars($_POST['phone'])),
    'sub1' => isset($_POST['sub1']) ? trim($_POST['sub1']) : '',
    'sub2' => isset($_POST['sub2']) ? trim($_POST['sub2']) : '',
    'sub3' => isset($_POST['sub3']) ? trim($_POST['sub3']) : '',
    'sub4' => isset($_POST['sub4']) ? trim($_POST['sub4']) : '',
    'sub5' => isset($_POST['sub5']) ? trim($_POST['sub5']) : '',
    'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
    'timestamp' => date('Y-m-d H:i:s')
];

// Log the order for backup/analytics
function logOrder($data) {
    $logFile = 'orders.log';
    $logEntry = date('Y-m-d H:i:s') . ' - ' . json_encode($data) . PHP_EOL;
    file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
}

// Process the order
try {
    // Log the order for backup
    logOrder($data);
    
    // Since dr.cash handles the main submission, this is just for logging
    // Redirect to thank you page
    header('Location: ' . $config['redirect_url']);
    exit;
    
} catch (Exception $e) {
    // Log error but still redirect
    error_log('Order processing error: ' . $e->getMessage());
    header('Location: ' . $config['redirect_url']);
    exit;
}
?>`
}
