import type { FormConfig } from "@/types/form-config"

// ============================================================
// CPAGETTI FORM HTML GENERATOR
// ============================================================
export function generateCpagettiFormHTML(config: FormConfig, countryConfig: any): string {
  const langCode = config.country?.toLowerCase() || "it"

  // Countdown script
  const countdownScript = config.showCountdown
    ? `
    // Contador Regressivo
    (function startCountdown(){
      const el = {
        h: document.getElementById('hours'),
        m: document.getElementById('minutes'),
        s: document.getElementById('seconds')
      };
      if (!el.h || !el.m || !el.s) return;
      let remaining = ${config.countdownHours || 3}*3600 + ${config.countdownMinutes || 58}*60 + ${config.countdownSeconds || 23}; 
      const tick = () => {
        if (remaining <= 0) return;
        const h = Math.floor(remaining/3600);
        const m = Math.floor((remaining%3600)/60);
        const s = remaining%60;
        el.h.textContent = String(h).padStart(2,'0');
        el.m.textContent = String(m).padStart(2,'0');
        el.s.textContent = String(s).padStart(2,'0');
        remaining--; 
        setTimeout(tick,1000);
      };
      tick();
    })();`
    : ""

  return `<!doctype html>
<html lang="${langCode}">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${config.headline || "Offerta Speciale"}</title>
  <style>
    /* Estilos Dr.Cash / Cpagetti */
    :root{--bg:${config.backgroundColor || "#f8f9fa"}; --card:${config.formBackgroundColor || "#fff"}; --border:#e9ecef; --green:#28a745; --primary:${config.primaryColor || "#dc3545"}; --muted:#6c757d; --input-bg:#fff; --input-bd:#ced4da; --text-dark:#212529; --text-light:#6c757d;}
    *{box-sizing:border-box}
    html,body{margin:0}
    body{background:var(--bg); color:var(--text-dark); font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
    .frame{width:100%; max-width: ${config.formWidth || "380"}px; margin:20px auto; padding:0; background:transparent;}
    .card{background:var(--card); border:1px solid var(--border); border-radius:12px; padding:20px; position:relative; box-shadow:0 2px 10px rgba(0,0,0,0.1);}
    .header{text-align:center; margin:10px 0 20px; padding-top:10px;}
    .header h2{margin:0; font-weight:600; font-size:20px; color:var(--text-dark);}
    .timer{display:flex; justify-content:center; align-items:center; gap:8px; margin:15px 0 20px; font-weight:600; font-size:14px;}
    .timer-box{background:${config.countdownColor || "#dc3545"}; color:#fff; padding:8px 10px; border-radius:4px; min-width:35px; text-align:center; font-weight:700; font-size:16px;}
    .price-container{margin:20px 0; padding:0 10px;}
    .price-content{display:flex; justify-content:space-between; align-items:center; flex:1;}
    .price-old{text-align:left;}
    .price-old .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-old .amount{color:var(--muted); text-decoration:line-through; font-size:16px;}
    .price-new{text-align:right;}
    .price-new .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-new .amount{color:var(--text-dark); font-weight:700; font-size:24px;}
    .social-proof{margin:20px 0; font-size:12px; color:var(--muted);}
    .social-item{display:flex; align-items:center; margin:4px 0;}
    .social-icon{width:12px; height:12px; margin-right:6px; border-radius:50%;}
    .icon-people{ background:#007bff; }
    .icon-time{ background:#28a745; }
    .social-number{ color:var(--text-dark); font-weight:600; }
    .online-dot{color:#28a745; margin-left:auto; animation: pulse 2s infinite;}
    @keyframes pulse {0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; }}
    .form-group{margin:15px 0;}
    input[type="text"], input[type="tel"]{width:100%; height:50px; padding:12px 16px; background:var(--input-bg); border:1px solid var(--input-bd); border-radius:6px; font-size:16px; outline:none; color:var(--muted);}
    input::placeholder{ color:#adb5bd; }
    input:focus{ border-color:#80bdff; box-shadow:0 0 0 0.2rem rgba(0,123,255,.25); }
    .btn{width:100%; height:50px; margin:20px 0 15px; border:none; border-radius:25px; background:${config.buttonColor || "#dc3545"}; color:#fff; font-size:16px; font-weight:700; cursor:pointer; text-transform:uppercase; letter-spacing:0.5px;}
    .btn:hover{ background:color-mix(in srgb, ${config.buttonColor || "#dc3545"} 90%, black); }
    .btn:active{ transform:translateY(1px); }
    .footer-note{text-align:center; margin:15px 0 5px;}
    .footer-text{color:var(--muted); font-size:11px; line-height:1.4;}
    .footer-disclaimer{color:var(--muted); font-size:10px; text-align:center; margin-top:10px; line-height:1.3;}
    @media (max-width: 340px){.card{ padding:15px; } .price-container{ padding:0 5px; }}
  </style>
</head>
<body>

  <div class="frame">
    <div class="card">

      <div class="header"><h2>${config.headline || "Solo oggi"}</h2></div>
      ${
        config.showCountdown
          ? `
      <div class="timer">
        <span class="timer-box" id="hours">${String(config.countdownHours || 3).padStart(2, "0")}</span>
        <span class="timer-box" id="minutes">${String(config.countdownMinutes || 58).padStart(2, "0")}</span>
        <span class="timer-box" id="seconds">${String(config.countdownSeconds || 23).padStart(2, "0")}</span>
      </div>`
          : ""
      }
      
      <div class="price-container">
        <div class="price-content">
          <div class="price-old">
            <div class="label">${countryConfig?.language?.oldPriceLabel || config.oldPriceLabel || "Prezzo vecchio"}</div>
            <div class="amount">${config.oldPrice || "78"} ${config.currency || "EUR"}</div>
          </div>
          <div class="price-new">
            <div class="label">${countryConfig?.language?.newPriceLabel || config.newPriceLabel || "Prezzo nuovo"}</div>
            <div class="amount">${config.newPrice || "39"} ${config.currency || "EUR"}*</div>
          </div>
        </div>
      </div>

      <div class="social-proof">
        <div class="social-item">
          <div class="social-icon icon-people"></div>
          <span>${(countryConfig?.language?.socialProofPeople || "29 persone stanno vedendo").replace("{count}", String(config.socialProofPeople || 29))}</span>
          <span class="online-dot">● online</span>
        </div>
        <div class="social-item">
          <div class="social-icon icon-time"></div>
          <span>${(countryConfig?.language?.socialProofSales || "16 vendite nell'ultima ora").replace("{count}", String(config.socialProofSales || 16))}</span>
          <span class="online-dot">● online</span>
        </div>
      </div>

      <form class="orderForm" id="orderForm" action="order.php" method="POST">
        
        <div class="form-group">
          <input id="name" name="name" type="text" placeholder="${countryConfig?.language?.namePlaceholder || config.namePlaceholder || "Nome e Cognome"}" required>
        </div>

        <div class="form-group">
          <input id="phone" name="phone" type="tel" inputmode="tel" placeholder="${countryConfig?.language?.phonePlaceholder || config.phonePlaceholder || "Telefono (+39...)"}" required>
        </div>

        <input type="hidden" name="sub1" value="site_oficial">

        <button type="submit" class="btn" id="submitBtn">${countryConfig?.language?.buttonText || config.ctaText || "ORDINA CON SCONTO"}</button>

        <div class="footer-note">${config.belowButtonEmoji || "🔒"} <span class="footer-text">${countryConfig?.language?.securityText || config.securityText || "Dati protetti al 100%"}</span></div>
        <div class="footer-disclaimer">${countryConfig?.language?.disclaimerText || config.disclaimerText || "* Offerta valida fino a esaurimento scorte"}</div>
      </form>
    </div>
  </div>

  <script>
    ${countdownScript}
  </script>
</body>
</html>`
}

// ============================================================
// CPAGETTI PHP GENERATOR
// ============================================================
export function generateCpagettiPHP(config: FormConfig): string {
  const apiKey = config.apiKey || "SUA_API_KEY_AQUI"
  const offerId = config.offerId || "OFFER_ID_AQUI"
  const country = config.country || "IT"
  const lang = config.country || "IT"
  const successPage = "success.html"

  return `<?php
// order.php - Integração Cpagetti (PRODUÇÃO)
// Desativa exibição de erros na tela para o cliente não ver códigos estranhos
ini_set('display_errors', 0);
error_reporting(0);

// Inicia buffer para garantir redirecionamento
ob_start();

// ========================================================
// 1. CONFIGURAÇÃO (PREENCHA AQUI)
// ========================================================
$apiKey  = '${apiKey}'; 
$offerId = '${offerId}';                            
$country = '${country}';                               
$lang    = '${lang}';                               
$successPage = '${successPage}'; // Página de obrigado
// ========================================================

$apiUrl = 'http://api.cpagetti.com/order/register';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    function get_ip() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return $_SERVER['HTTP_X_FORWARDED_FOR'];
        return $_SERVER['REMOTE_ADDR'];
    }

    // Coleta dados do formulário
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $sub1 = isset($_POST['sub1']) ? trim($_POST['sub1']) : '';

    // Monta o array de dados para a API
    $data = [
        'api_key'   => $apiKey,   
        '@/api_key' => $apiKey,   // Envia chave dupla por garantia
        'name'      => $name,
        'phone'     => $phone,
        'offer_id'  => $offerId,
        'country'   => $country,
        'lang'      => $lang,
        'ip'        => get_ip(),
        'sub1'      => $sub1
    ];

    // Headers
    $headers = [
        "User-Agent: " . ($_SERVER['HTTP_USER_AGENT'] ?? 'Mozilla/5.0'),
        "Connection: keep-alive"
    ];

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $apiUrl);
    curl_setopt($curl, CURLOPT_POST, true);
    // Usa http_build_query para garantir que a Cpagetti aceite os dados
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data)); 
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);

    $responseBody = curl_exec($curl);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    // Processa a resposta
    $json = json_decode($responseBody);

    if ($json && isset($json->success) && $json->success == true) {
        // SUCESSO: Redireciona para a página de obrigado
        header("Location: " . $successPage);
        ob_end_flush();
        exit;
    } else {
        // FALHA: Redireciona de volta para o formulário com erro
        // (Você pode adicionar ?error=1 na URL para mostrar aviso no HTML)
        header("Location: index.html?error=api_fail");
        ob_end_flush();
        exit;
    }
} else {
    // Se tentarem acessar direto sem POST, manda pro index
    header("Location: index.html");
    ob_end_flush();
    exit;
}
?>` 
}
