import type { FormConfig } from "@/types/form-config"
import { countryConfigs } from "./country-configs"

// ============================================================
// SHAKES.PRO FORM HTML GENERATOR - TEMPLATE EXATO
// ============================================================
export function generateShakesProFormHTML(config: FormConfig, countryConfig: any): string {
  const domain = config.domain || "engagehuboff.site"
  const offerId = config.offerId || "18974"
  const geoCode = config.country || "BR"
  const langCode = config.country?.toLowerCase() || "pt"
  const country = countryConfigs[config.country || "BR"]

  // Get translations from country config
  const headline = config.headline || country?.language?.headline || "Oferta Especial"
  const labelOldPrice = country?.language?.oldPriceLabel || "Preț vechi"
  const labelNewPrice = country?.language?.newPriceLabel || "Preț nou"
  const oldPrice = config.oldPrice || `298 ${country?.currency || "RON"}`
  const newPrice = config.newPrice || `149 ${country?.currency || "RON"}`
  
  const socialProofPeopleText = country?.language?.socialProofPeople || "Acum pe site sunt {count} persoane"
  const socialProof1 = socialProofPeopleText.replace("{count}", String(config.socialProofPeople || 29))
  
  const socialProof2 = country?.language?.socialProofRecent || "16 vânzări în ultima oră"
  
  const placeholderName = country?.language?.namePlaceholder || config.namePlaceholder || "Numele"
  const placeholderPhone = country?.language?.phonePlaceholder || config.phonePlaceholder || "+40 123 456 789"
  const buttonText = country?.language?.buttonText || config.ctaText || "COMANDAȚI CU REDUCERE"
  const securityText = country?.language?.securityText || config.securityText || "Dados 100% seguros"
  const disclaimerText = country?.language?.disclaimerText || config.disclaimerText || "* Funcționează asupra mărturiilor în limitele unui canal de distribuție"
  
  // Countdown color with fallback
  const countdownColor = config.countdownColor || "#dc3545"
  const buttonColor = config.buttonColor || "#dc3545"
  
  // Countdown values
  const countdownHours = config.countdownHours || 3
  const countdownMinutes = config.countdownMinutes || 58
  const countdownSeconds = config.countdownSeconds || 23

  return `<!doctype html>
<html lang="${langCode}">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${headline}</title>
  <style>
    /* Estilos do formulário Dr.Cash */
    :root{--bg:#f8f9fa; --card:#fff; --border:#e9ecef; --green:#28a745; --primary:#dc3545; --muted:#6c757d; --input-bg:#fff; --input-bd:#ced4da; --text-dark:#212529; --text-light:#6c757d;}
    *{box-sizing:border-box}
    html,body{margin:0}
    body{background:var(--bg); color:var(--text-dark); font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
    .frame{width:100%; max-width: 380px; margin:20px auto; padding:0; background:transparent;}
    .card{background:var(--card); border:1px solid var(--border); border-radius:12px; padding:20px; position:relative; box-shadow:0 2px 10px rgba(0,0,0,0.1);}
    .header{text-align:center; margin:10px 0 20px; padding-top:10px;}
    .header h2{margin:0; font-weight:600; font-size:20px; color:var(--text-dark);}
    .timer{display:flex; justify-content:center; align-items:center; gap:8px; margin:15px 0 20px; font-weight:600; font-size:14px;}
    .timer-box{background:${countdownColor}; color:#fff; padding:8px 10px; border-radius:4px; min-width:35px; text-align:center; font-weight:700; font-size:16px;}
    .price-container{margin:20px 0; padding:0 10px;}
    .price-content{display:flex; justify-content:space-between; align-items:center; flex:1;}
    .price-old{text-align:left;}
    .price-old .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-old .amount{color:var(--muted); text-decoration:line-through; font-size:16px;}
    .price-new{text-align:right;}
    .price-new .label{color:var(--muted); font-size:12px; margin-bottom:2px;}
    .price-new .amount{color:var(--text-dark); font-weight:700; font-size:24px;}
    .social-proof{margin:20px 0; font-size:12px; color:var(--muted);}
    .social-item{display:flex; align-items:center; margin:4px 0;}
    .social-icon{width:12px; height:12px; margin-right:6px; border-radius:50%;}
    .icon-people{ background:#007bff; }
    .icon-time{ background:#28a745; }
    .social-number{ color:var(--text-dark); font-weight:600; }
    .online-dot{color:#28a745; margin-left:auto; animation: pulse 2s infinite;}
    @keyframes pulse {0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; }}
    .form-group{margin:15px 0;}
    input[type="text"], input[type="tel"]{width:100%; height:50px; padding:12px 16px; background:var(--input-bg); border:1px solid var(--input-bd); border-radius:6px; font-size:16px; outline:none; color:var(--muted);}
    input::placeholder{ color:#adb5bd; }
    input:focus{ border-color:#80bdff; box-shadow:0 0 0 0.2rem rgba(0,123,255,.25); }
    .btn{width:100%; height:50px; margin:20px 0 15px; border:none; border-radius:25px; background:${buttonColor}; color:#fff; font-size:16px; font-weight:700; cursor:pointer; text-transform:uppercase; letter-spacing:0.5px;}
    .btn:hover{ background:color-mix(in srgb, ${buttonColor} 90%, black); }
    .btn:active{ transform:translateY(1px); }
    .footer-note{text-align:center; margin:15px 0 5px;}
    .footer-text{color:var(--muted); font-size:11px; line-height:1.4;}
    .footer-disclaimer{color:var(--muted); font-size:10px; text-align:center; margin-top:10px; line-height:1.3;}
    @media (max-width: 340px){.card{ padding:15px; } .price-container{ padding:0 5px; }}
  </style>
</head>
<body>

  <div class="frame">
    <div class="card">

      <div class="header"><h2>${headline}</h2></div>
      
      <div class="timer">
        <span class="timer-box" id="hours">${String(countdownHours).padStart(2, "0")}</span>
        <span class="timer-box" id="minutes">${String(countdownMinutes).padStart(2, "0")}</span>
        <span class="timer-box" id="seconds">${String(countdownSeconds).padStart(2, "0")}</span>
      </div>
      
      <div class="price-container">
        <div class="price-content">
          <div class="price-old">
            <div class="label">${labelOldPrice}</div>
            <div class="amount">${oldPrice}</div>
          </div>
          <div class="price-new">
            <div class="label">${labelNewPrice}</div>
            <div class="amount">${newPrice}*</div>
          </div>
        </div>
      </div>

      <div class="social-proof">
        <div class="social-item">
          <div class="social-icon icon-people"></div>
          <span>${socialProof1}</span>
          <span class="online-dot">● online</span>
        </div>
        <div class="social-item">
          <div class="social-icon icon-time"></div>
          <span>${socialProof2}</span>
          <span class="online-dot">● online</span>
        </div>
      </div>

      <form class="orderForm" id="orderForm" action="https://${domain}/order.php" method="POST">
        
        <div class="form-group">
          <input id="name" name="name" type="text" placeholder="${placeholderName}" required>
        </div>

        <div class="form-group">
          <input id="phone" name="phone" type="tel" inputmode="tel" placeholder="${placeholderPhone}" required>
        </div>

        <input type="hidden" name="offer_id" value="${offerId}">
        
        <input type="hidden" name="country" value="${geoCode}">

        <input type="hidden" name="landing_id" value="">

        <input type="hidden" name="sub1" id="sub1">
        <input type="hidden" name="sub2" id="sub2">
        <input type="hidden" name="sub3" id="sub3">
        <input type="hidden" name="sub4" id="sub4">
        <input type="hidden" name="sub5" id="sub5">

        <button type="submit" class="btn" id="submitBtn">${buttonText}</button>

        <div class="footer-note">
          ${config.belowButtonEmoji || "🔒"} <span class="footer-text">${securityText}</span>
        </div>

        <div class="footer-disclaimer">
          ${disclaimerText}
        </div>
      </form>

    </div>
  </div>

  <script>
    // Preenchimento de UTMs
    (function fillSubsFromURL(){
      const url = new URL(window.location.href);
      ['sub1','sub2','sub3','sub4','sub5'].forEach(k=>{
        const v = url.searchParams.get(k);
        if (v) {
          const el = document.querySelector(\`input[name="\${k}"]\`);
          if (el) el.value = v;
        }
      });
    })();

    // Contador Regressivo
    (function startCountdown(){
      const hoursEl = document.getElementById('hours');
      const minutesEl = document.getElementById('minutes');
      const secondsEl = document.getElementById('seconds');
      
      let remaining = ${countdownHours}*3600 + ${countdownMinutes}*60 + ${countdownSeconds}; 
      
      const tick = () => {
        const h = Math.floor(remaining/3600);
        const m = Math.floor((remaining%3600)/60);
        const s = remaining%60;
        hoursEl.textContent = String(h).padStart(2,'0');
        minutesEl.textContent = String(m).padStart(2,'0');
        secondsEl.textContent = String(s).padStart(2,'0');
        if (remaining<=0) return;
        remaining--; 
        setTimeout(tick,1000);
      };
      tick();
    })();
  </script>
</body>
</html>`
}

// ============================================================
// SHAKES.PRO PHP GENERATOR
// ============================================================
export function generateShakesProPHP(config: FormConfig): string {
  const apiKey = config.apiKey || "SUA_API_KEY_AQUI"
  const domain = config.domain || "engagehuboff.site"
  const successPage = `https://${domain}/success.html`

  return `<?php
// order.php (Template Shakes.pro)

ob_start();

$apiKey = '${apiKey}';
$domain = '${domain}';
$success_page = '${successPage}';

$apiUrl = 'https://shakes.pro/index.php?r=api/order/in';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    function get_ip() {
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) return $_SERVER["HTTP_CF_CONNECTING_IP"];
        if (isset($_SERVER['REMOTE_ADDR'])) return $_SERVER['REMOTE_ADDR'];
        return '127.0.0.1';
    }

    function get_post($key, $default = '') {
        return isset($_POST[$key]) ? htmlspecialchars(trim($_POST[$key])) : $default;
    }

    $data = array(
        'offerId' => get_post('offer_id'),
        'countryCode' => get_post('country'),
        'landingUrl' => isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : $domain,
        'createdAt' => date('Y-m-d H:i:s'),
        'userAgent' => $_SERVER['HTTP_USER_AGENT'],
        'name' => get_post('name'),
        'phone' => get_post('phone'),
        'ip' => get_ip(),
        'landing_id' => get_post('landing_id'),
        'sub1' => get_post('sub1'),
        'sub2' => get_post('sub2'),
        'sub3' => get_post('sub3'),
        'sub4' => get_post('sub4'),
        'sub5' => get_post('sub5'),
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl . '&key=' . $apiKey);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $result = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $response = json_decode($result, true);

    if ($http_code == 200 && isset($response['status']) && $response['status'] == 'ok') {
        header('Location: ' . $success_page);
        ob_end_flush();
        exit;
    } else {
        header('Location: index.html?error=1');
        ob_end_flush();
        exit;
    }
}

ob_end_flush();
?>`
}
