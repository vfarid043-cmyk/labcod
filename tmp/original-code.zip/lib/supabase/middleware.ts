import { NextResponse, type NextRequest } from "next/server"

export async function updateSession(request: NextRequest) {
  // Autenticação desabilitada - acesso livre à ferramenta
  return NextResponse.next({
    request,
  })
}
