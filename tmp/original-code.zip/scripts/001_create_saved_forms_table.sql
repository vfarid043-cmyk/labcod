-- Create saved_forms table to store user form configurations
CREATE TABLE IF NOT EXISTS saved_forms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  project_name TEXT NOT NULL,
  form_config JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index on user_id for faster queries
CREATE INDEX IF NOT EXISTS idx_saved_forms_user_id ON saved_forms(user_id);

-- Create index on created_at for sorting
CREATE INDEX IF NOT EXISTS idx_saved_forms_created_at ON saved_forms(created_at DESC);

-- Enable Row Level Security
ALTER TABLE saved_forms ENABLE ROW LEVEL SECURITY;

-- Create policy: Users can only see their own saved forms
CREATE POLICY "Users can view their own saved forms"
  ON saved_forms
  FOR SELECT
  USING (auth.uid() = user_id);

-- Create policy: Users can insert their own saved forms
CREATE POLICY "Users can insert their own saved forms"
  ON saved_forms
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Create policy: Users can update their own saved forms
CREATE POLICY "Users can update their own saved forms"
  ON saved_forms
  FOR UPDATE
  USING (auth.uid() = user_id);

-- Create policy: Users can delete their own saved forms
CREATE POLICY "Users can delete their own saved forms"
  ON saved_forms
  FOR DELETE
  USING (auth.uid() = user_id);
