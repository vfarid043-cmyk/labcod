// Script para adicionar traduções da página de obrigado para todos os países
// Este script deve ser executado uma vez para atualizar o arquivo country-configs.ts

const translations = {
  // Espanhol (para países de língua espanhola)
  es: {
    title: "¡Gracias por tu compra!",
    message:
      "Tu pedido ha sido procesado exitosamente. Serás contactado pronto por uno de nuestros representantes para confirmar los detalles.",
    buttonText: "Volver al Sitio",
    finalText:
      "Importante: Mantén tu teléfono cerca. Te contactaremos en las próximas 24 horas para confirmar tu pedido.",
    orderDetailsTitle: "Detalles del Pedido",
    productLabel: "Producto",
    priceLabel: "Precio",
    discountLabel: "Descuento",
    statusLabel: "Estado",
    statusConfirmed: "Confirmado",
    contactTitle: "¿Tienes preguntas?",
    upsellTitle: "¡Oferta Especial!",
    upsellMessage: "Aprovecha esta oferta exclusiva...",
    upsellButtonText: "LO QUIERO",
  },
  // Alemão
  de: {
    title: "Vielen Dank für Ihren Kauf!",
    message:
      "Ihre Bestellung wurde erfolgreich bearbeitet. Sie werden in Kürze von einem unserer Vertreter kontaktiert, um die Details zu bestätigen.",
    buttonText: "Zurück zur Website",
    finalText:
      "Wichtig: Halten Sie Ihr Telefon bereit. Wir werden Sie innerhalb von 24 Stunden kontaktieren, um Ihre Bestellung zu bestätigen.",
    orderDetailsTitle: "Bestelldetails",
    productLabel: "Produkt",
    priceLabel: "Preis",
    discountLabel: "Rabatt",
    statusLabel: "Status",
    statusConfirmed: "Bestätigt",
    contactTitle: "Haben Sie Fragen?",
    upsellTitle: "Sonderangebot!",
    upsellMessage: "Nutzen Sie dieses exklusive Angebot...",
    upsellButtonText: "ICH WILL ES",
  },
  // Francês
  fr: {
    title: "Merci pour votre achat!",
    message:
      "Votre commande a été traitée avec succès. Vous serez contacté prochainement par l'un de nos représentants pour confirmer les détails.",
    buttonText: "Retour au Site",
    finalText:
      "Important: Gardez votre téléphone à portée de main. Nous vous contacterons dans les 24 heures pour confirmer votre commande.",
    orderDetailsTitle: "Détails de la Commande",
    productLabel: "Produit",
    priceLabel: "Prix",
    discountLabel: "Réduction",
    statusLabel: "Statut",
    statusConfirmed: "Confirmé",
    contactTitle: "Vous avez des questions?",
    upsellTitle: "Offre Spéciale!",
    upsellMessage: "Profitez de cette offre exclusive...",
    upsellButtonText: "JE LE VEUX",
  },
  // Italiano
  it: {
    title: "Grazie per il tuo acquisto!",
    message:
      "Il tuo ordine è stato elaborato con successo. Sarai contattato a breve da uno dei nostri rappresentanti per confermare i dettagli.",
    buttonText: "Torna al Sito",
    finalText:
      "Importante: Tieni il telefono a portata di mano. Ti contatteremo entro 24 ore per confermare il tuo ordine.",
    orderDetailsTitle: "Dettagli dell'Ordine",
    productLabel: "Prodotto",
    priceLabel: "Prezzo",
    discountLabel: "Sconto",
    statusLabel: "Stato",
    statusConfirmed: "Confermato",
    contactTitle: "Hai domande?",
    upsellTitle: "Offerta Speciale!",
    upsellMessage: "Approfitta di questa offerta esclusiva...",
    upsellButtonText: "LO VOGLIO",
  },
  // Polonês
  pl: {
    title: "Dziękujemy za zakup!",
    message:
      "Twoje zamówienie zostało pomyślnie przetworzone. Wkrótce skontaktuje się z Tobą jeden z naszych przedstawicieli w celu potwierdzenia szczegółów.",
    buttonText: "Powrót do Strony",
    finalText:
      "Ważne: Trzymaj telefon pod ręką. Skontaktujemy się z Tobą w ciągu 24 godzin, aby potwierdzić zamówienie.",
    orderDetailsTitle: "Szczegóły Zamówienia",
    productLabel: "Produkt",
    priceLabel: "Cena",
    discountLabel: "Zniżka",
    statusLabel: "Status",
    statusConfirmed: "Potwierdzony",
    contactTitle: "Masz pytania?",
    upsellTitle: "Oferta Specjalna!",
    upsellMessage: "Skorzystaj z tej ekskluzywnej oferty...",
    upsellButtonText: "CHCĘ TO",
  },
  // Inglês
  en: {
    title: "Thank you for your purchase!",
    message:
      "Your order has been successfully processed. You will be contacted soon by one of our representatives to confirm the details.",
    buttonText: "Back to Site",
    finalText: "Important: Keep your phone nearby. We will contact you within 24 hours to confirm your order.",
    orderDetailsTitle: "Order Details",
    productLabel: "Product",
    priceLabel: "Price",
    discountLabel: "Discount",
    statusLabel: "Status",
    statusConfirmed: "Confirmed",
    contactTitle: "Have questions?",
    upsellTitle: "Special Offer!",
    upsellMessage: "Take advantage of this exclusive offer...",
    upsellButtonText: "I WANT IT",
  },
  // Português
  pt: {
    title: "Obrigado pela sua compra!",
    message:
      "Sua compra foi processada com sucesso. Você será contatado em breve por um de nossos representantes para confirmação dos detalhes.",
    buttonText: "Voltar ao Site",
    finalText:
      "Importante: Mantenha seu telefone por perto. Entraremos em contato em até 24 horas para confirmar sua compra.",
    orderDetailsTitle: "Detalhes da Compra",
    productLabel: "Produto",
    priceLabel: "Preço",
    discountLabel: "Desconto",
    statusLabel: "Status",
    statusConfirmed: "Confirmado",
    contactTitle: "Tem dúvidas?",
    upsellTitle: "Oferta Especial!",
    upsellMessage: "Aproveite esta oferta exclusiva...",
    upsellButtonText: "QUERO APROVEITAR",
  },
}

// Mapeamento de países para idiomas
const countryToLanguage: Record<string, keyof typeof translations> = {
  // Espanhol
  AR: "es",
  BO: "es",
  CL: "es",
  CO: "es",
  CR: "es",
  CU: "es",
  DO: "es",
  EC: "es",
  SV: "es",
  GT: "es",
  HN: "es",
  MX: "es",
  NI: "es",
  PA: "es",
  PY: "es",
  PE: "es",
  ES: "es",
  UY: "es",
  VE: "es",
  // Alemão
  AT: "de",
  DE: "de",
  CH: "de",
  // Francês
  BE: "fr",
  FR: "fr",
  LU: "fr",
  // Italiano
  IT: "it",
  // Polonês
  PL: "pl",
  // Inglês
  IE: "en",
  GB: "en",
  MT: "en",
  // Português
  BR: "pt",
  PT: "pt",
  // Romeno (usa própria tradução)
  RO: "ro",
}

console.log("Traduções disponíveis para todos os países!")
