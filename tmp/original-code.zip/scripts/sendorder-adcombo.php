<?php
const API_URL = "https://api.adcombo.com/api/v2/order/create/";
const API_KEY = "87771250e0bcba1da62cb5c0e8459956";
$args = [
    'api_key' => '87771250e0bcba1da62cb5c0e8459956',
    'name' => $_POST['name'],
    'phone' => $_POST['phone'],
    'offer_id' => $_POST['offer_id'],
    'country_code' => $_POST['country_code'],
    'price' => $_POST['price'],
    'base_url' => $_POST['base_url'],
    'ip' => $_SERVER['REMOTE_ADDR'],
    'referrer' => $_SERVER["HTTP_REFERER"],
    ];
$url = API_URL.'?'.http_build_query($args);
$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true
));
$res = curl_exec($curl);
curl_close($curl);
$res = json_decode($res, true);
if ($res['code'] == 'ok') {
    header('Location:'.$_POST['success_page']);
    echo $res['msg'] . ": " . $res['order_id'];
    
} else {
    echo $res['error'];
}

?>
