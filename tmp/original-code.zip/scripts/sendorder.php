<?php
/**
 * Universal Order Handler for AdCombo Integration
 * Updated to use the working AdCombo functionality
 */

// Security Headers and CORS
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow all origins for testing
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed. Only POST requests are accepted.']);
    exit;
}

const API_URL = "https://api.adcombo.com/api/v2/order/create/";

// Get API key from POST data or use default
$api_key = isset($_POST['api_key']) ? $_POST['api_key'] : '87771250e0bcba1da62cb5c0e8459956';

$args = [
    'api_key' => $api_key,
    'name' => $_POST['name'] ?? '',
    'phone' => $_POST['phone'] ?? '',
    'offer_id' => $_POST['offer_id'] ?? '',
    'country_code' => $_POST['country_code'] ?? '',
    'price' => $_POST['price'] ?? '',
    'base_url' => $_POST['base_url'] ?? '',
    'ip' => $_SERVER['REMOTE_ADDR'],
    'referrer' => $_SERVER["HTTP_REFERER"] ?? '',
];

// Validate required fields
$required = ['name', 'phone', 'offer_id', 'country_code'];
$missing = [];

foreach ($required as $field) {
    if (empty($args[$field])) {
        $missing[] = $field;
    }
}

if (!empty($missing)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Missing required fields: ' . implode(', ', $missing)
    ]);
    exit;
}

$url = API_URL.'?'.http_build_query($args);
$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true
));
$res = curl_exec($curl);
curl_close($curl);
$res = json_decode($res, true);

if ($res['code'] == 'ok') {
    // If success_page is provided, redirect there
    if (!empty($_POST['success_page'])) {
        header('Location:'.$_POST['success_page']);
        exit;
    }
    
    // Otherwise return JSON response
    echo json_encode([
        'success' => true,
        'message' => $res['msg'],
        'order_id' => $res['order_id']
    ]);
    
} else {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $res['error'] ?? 'Unknown error occurred'
    ]);
}
?>
