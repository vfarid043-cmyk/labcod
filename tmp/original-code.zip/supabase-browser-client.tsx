import { createBrowserClient as createSupabaseBrowserClient } from "@supabase/ssr"

export function createBrowserClient(supabaseUrl: string, supabaseKey: string) {
  return createSupabaseBrowserClient(supabaseUrl, supabaseKey)
}
