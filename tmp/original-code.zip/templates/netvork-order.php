<?php

const TOKEN = 'SUA API KEY AQUI'; // SEU TOKEN
const ENDPOINT_1 = 'https://api.netvork.net/v1/new-lead';
const ENDPOINT_2 = 'https://api2.netvork.net/v1/new-lead';

if (!empty($_POST)) {
    $data = array(
        'token' => TOKEN,
        'offer_id' => !empty($_POST['offer_id']) ? trim($_POST['offer_id']) : '',
        'name' => !empty($_POST['name']) ? trim($_POST['name']) : '',
        'phone' => !empty($_POST['phone']) ? trim($_POST['phone']) : '',
        'country' => !empty($_POST['country']) ? trim($_POST['country']) : '',
        'lang' => !empty($_POST['lang']) ? trim($_POST['lang']) : '',
        'utm_source' => !empty($_POST['utm_source']) ? trim($_POST['utm_source']) : '',
        'utm_medium' => !empty($_POST['utm_medium']) ? trim($_POST['utm_medium']) : '',
        'utm_campaign' => !empty($_POST['utm_campaign']) ? trim($_POST['utm_campaign']) : '',
        'utm_content' => !empty($_POST['utm_content']) ? trim($_POST['utm_content']) : '',
        'utm_term' => !empty($_POST['utm_term']) ? trim($_POST['utm_term']) : '',
        'ip' => getIp(),
    );

    $count = 3;
    while ($count--) {
        if (apinetvorkV1NewLead($data)) {
            break;
        } else {
            sleep(2);
        }
    }

    header("Location: success.html");
    die();
}

healthCheck();

function healthCheck()
{
    checkUserAgent();
    echo '<h3>Health check</h3>';

    if ('SUA API KEY AQUI' == TOKEN) {
        echo 'Token OK! <br>';
    } else {
        echo 'Error: TOKEN problem <br>';
    }

    try {
        $data = array(
            'token' => TOKEN,
            'offer_id' => 1,
            'ip' => getIp(),
            'name' => 'Test',
            'phone' => '+12345',
            'country' => 'IT',
            'lang' => 'it',
        );

        $response = sendToApiCurl($data);

        if ($response) {
            echo 'API test sent, result: ' . $response . '<br>';
        } else {
            echo 'Error: Failed to send request <br>';
        }
    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage() . '<br>';
    }
}

function checkUserAgent()
{
    if (
        empty($_SERVER['HTTP_USER_AGENT'])
        || !preg_match('#Windows|Mac|Linux|Android|iPad|iPhone#i', $_SERVER['HTTP_USER_AGENT'])
    ) {
        die();
    }
}

function apinetvorkV1NewLead($data)
{
    checkData($data);

    $response = sendToApiCurl($data);
    $json = json_decode($response, true);

    if (isset($json['status'])) {
        return true;
    }
    return false;
}

function sendToApiCurl($data)
{
    $endpoints = [
        ENDPOINT_1,
        ENDPOINT_2
    ];
    foreach ($endpoints as $endpoint) {
        $ch = curl_init($endpoint);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true); // Use true para produção!
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded'
        ]);
        curl_setopt($ch, CURLOPT_VERBOSE, true); // Ativa debug detalhado

        $response = curl_exec($ch);
        $error = curl_error($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response !== false && $http_code == 200) {
            return $response;
        }
    }
    return false;
}

function checkData($data)
{
    if (empty($_SERVER['HTTP_REFERER'])) {
        $referer = '/';
    } elseif (strpos($_SERVER['HTTP_REFERER'], 'order.php') !== false) {
        $referer = '/';
    } else {
        $referer = $_SERVER['HTTP_REFERER'];
    }

    if (empty($data['token'])) {
        header("Location: " . $referer . "?error=token_empty");
        die();
    }

    if (empty($data['offer_id'])) {
        header("Location: " . $referer . "?error=offer");
        die();
    }

    if (empty($data['phone'])) {
        header("Location: " . $referer . "?error=phone");
        die();
    }

    if (empty($data['country'])) {
        header("Location: " . $referer . "?error=country");
        die();
    }
}

function getIp()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $arIp = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = $arIp[0];
    } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
        $ip = $_SERVER['REMOTE_ADDR'];
    } else {
        $ip = '';
    }
    return $ip;
}

?>
