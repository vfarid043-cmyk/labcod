export interface FormConfig {
  platform: string
  apiKey: string
  offerId: string
  domain: string
  userId?: string // Added userId for plataforma Terra Leads
  country: string
  headline: string
  oldPrice: string
  newPrice: string
  currency: string
  discount: string
  ctaText: string
  namePlaceholder: string
  phonePlaceholder: string
  availabilityText: string
  securityText: string
  disclaimerText: string
  formWidth: string
  formMaxWidth: string
  formHeight: string
  formBackgroundColor?: string
  buttonBorderRadius?: string // Added button border radius control
  buttonSize: string
  buttonWidth: string
  primaryColor: string
  buttonColor: string
  backgroundColor: string
  showProductImage: boolean
  productImageUrl: string
  productImagePosition: "top" | "side" // 'top' = above price, 'side' = next to price
  showCountdown: boolean
  countdownHours: number
  countdownMinutes: number
  countdownSeconds: number
  countdownColor: string
  socialProofPeople: number
  socialProofSales: number
  belowButtonText: string
  belowButtonEmoji: string
  thankYou: {
    enabled: boolean
    title: string
    message: string
    buttonText: string
    buttonUrl: string
    backgroundColor: string
    containerColor: string
    titleColor: string
    messageColor: string
    buttonColor: string
    buttonTextColor: string
    buttonSize: string
    countdownColor: string
    showImage: boolean
    imageUrl: string
    showUpsell: boolean
    upsellTitle: string
    upsellMessage: string
    upsellButtonText: string
    upsellButtonUrl: string
    upsellPrice: string
    upsellButtonColor: string
    upsellBackgroundColor: string
    showUpsellImage: boolean
    upsellImageUrl: string
    finalText: string
  }
}

export interface CountryConfig {
  code: string
  name: string
  currency: string
  phonePrefix: string
  phoneFormat: string
  phoneExample: string
  nationalLength: number
  defaultColor: string
  language: {
    headline: string
    oldPriceLabel: string
    newPriceLabel: string
    namePlaceholder: string
    availabilityText: string
    ctaText: string
    securityText: string
    disclaimerText: string
    socialProofPeople: string
    socialProofSales: string
    thankYouPage: {
      title: string
      message: string
      buttonText: string
      finalText: string
      orderDetailsTitle: string
      productLabel: string
      priceLabel: string
      discountLabel: string
      statusLabel: string
      statusConfirmed: string
      contactTitle: string
      upsellTitle: string
      upsellMessage: string
      upsellButtonText: string
    }
  }
}
